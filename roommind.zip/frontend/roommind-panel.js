(function(){var e=Object.defineProperty,t=(e,t)=>()=>(e&&(t=e(e=0)),t),n=(t,n)=>{let r={};for(var i in t)e(r,i,{get:t[i],enumerable:!0});return n||e(r,Symbol.toStringTag,{value:`Module`}),r},r,i,a,o,s,c,l,u,d,f=t((()=>{r=globalThis,i=r.ShadowRoot&&(r.ShadyCSS===void 0||r.ShadyCSS.nativeShadow)&&`adoptedStyleSheets`in Document.prototype&&`replace`in CSSStyleSheet.prototype,a=Symbol(),o=new WeakMap,s=class{constructor(e,t,n){if(this._$cssResult$=!0,n!==a)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o,t=this.t;if(i&&e===void 0){let n=t!==void 0&&t.length===1;n&&(e=o.get(t)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),n&&o.set(t,e))}return e}toString(){return this.cssText}},c=e=>new s(typeof e==`string`?e:e+``,void 0,a),l=(e,...t)=>new s(e.length===1?e[0]:t.reduce((t,n,r)=>t+(e=>{if(!0===e._$cssResult$)return e.cssText;if(typeof e==`number`)return e;throw Error(`Value passed to 'css' function must be a 'css' function result: `+e+`. Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.`)})(n)+e[r+1],e[0]),e,a),u=(e,t)=>{if(i)e.adoptedStyleSheets=t.map(e=>e instanceof CSSStyleSheet?e:e.styleSheet);else for(let n of t){let t=document.createElement(`style`),i=r.litNonce;i!==void 0&&t.setAttribute(`nonce`,i),t.textContent=n.cssText,e.appendChild(t)}},d=i?e=>e:e=>e instanceof CSSStyleSheet?(e=>{let t=``;for(let n of e.cssRules)t+=n.cssText;return c(t)})(e):e})),p,ee,te,ne,re,ie,ae,oe,se,ce,le,ue,de,fe,pe,me=t((()=>{f(),{is:p,defineProperty:ee,getOwnPropertyDescriptor:te,getOwnPropertyNames:ne,getOwnPropertySymbols:re,getPrototypeOf:ie}=Object,ae=globalThis,oe=ae.trustedTypes,se=oe?oe.emptyScript:``,ce=ae.reactiveElementPolyfillSupport,le=(e,t)=>e,ue={toAttribute(e,t){switch(t){case Boolean:e=e?se:null;break;case Object:case Array:e=e==null?e:JSON.stringify(e)}return e},fromAttribute(e,t){let n=e;switch(t){case Boolean:n=e!==null;break;case Number:n=e===null?null:Number(e);break;case Object:case Array:try{n=JSON.parse(e)}catch{n=null}}return n}},de=(e,t)=>!p(e,t),fe={attribute:!0,type:String,converter:ue,reflect:!1,useDefault:!1,hasChanged:de},Symbol.metadata??=Symbol(`metadata`),ae.litPropertyMetadata??=new WeakMap,pe=class extends HTMLElement{static addInitializer(e){this._$Ei(),(this.l??=[]).push(e)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(e,t=fe){if(t.state&&(t.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(e)&&((t=Object.create(t)).wrapped=!0),this.elementProperties.set(e,t),!t.noAccessor){let n=Symbol(),r=this.getPropertyDescriptor(e,n,t);r!==void 0&&ee(this.prototype,e,r)}}static getPropertyDescriptor(e,t,n){let{get:r,set:i}=te(this.prototype,e)??{get(){return this[t]},set(e){this[t]=e}};return{get:r,set(t){let a=r?.call(this);i?.call(this,t),this.requestUpdate(e,a,n)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)??fe}static _$Ei(){if(this.hasOwnProperty(le(`elementProperties`)))return;let e=ie(this);e.finalize(),e.l!==void 0&&(this.l=[...e.l]),this.elementProperties=new Map(e.elementProperties)}static finalize(){if(this.hasOwnProperty(le(`finalized`)))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(le(`properties`))){let e=this.properties,t=[...ne(e),...re(e)];for(let n of t)this.createProperty(n,e[n])}let e=this[Symbol.metadata];if(e!==null){let t=litPropertyMetadata.get(e);if(t!==void 0)for(let[e,n]of t)this.elementProperties.set(e,n)}this._$Eh=new Map;for(let[e,t]of this.elementProperties){let n=this._$Eu(e,t);n!==void 0&&this._$Eh.set(n,e)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(e){let t=[];if(Array.isArray(e)){let n=new Set(e.flat(1/0).reverse());for(let e of n)t.unshift(d(e))}else e!==void 0&&t.push(d(e));return t}static _$Eu(e,t){let n=t.attribute;return!1===n?void 0:typeof n==`string`?n:typeof e==`string`?e.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(e=>e(this))}addController(e){(this._$EO??=new Set).add(e),this.renderRoot!==void 0&&this.isConnected&&e.hostConnected?.()}removeController(e){this._$EO?.delete(e)}_$E_(){let e=new Map,t=this.constructor.elementProperties;for(let n of t.keys())this.hasOwnProperty(n)&&(e.set(n,this[n]),delete this[n]);e.size>0&&(this._$Ep=e)}createRenderRoot(){let e=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return u(e,this.constructor.elementStyles),e}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(e=>e.hostConnected?.())}enableUpdating(e){}disconnectedCallback(){this._$EO?.forEach(e=>e.hostDisconnected?.())}attributeChangedCallback(e,t,n){this._$AK(e,n)}_$ET(e,t){let n=this.constructor.elementProperties.get(e),r=this.constructor._$Eu(e,n);if(r!==void 0&&!0===n.reflect){let i=(n.converter?.toAttribute===void 0?ue:n.converter).toAttribute(t,n.type);this._$Em=e,i==null?this.removeAttribute(r):this.setAttribute(r,i),this._$Em=null}}_$AK(e,t){let n=this.constructor,r=n._$Eh.get(e);if(r!==void 0&&this._$Em!==r){let e=n.getPropertyOptions(r),i=typeof e.converter==`function`?{fromAttribute:e.converter}:e.converter?.fromAttribute===void 0?ue:e.converter;this._$Em=r;let a=i.fromAttribute(t,e.type);this[r]=a??this._$Ej?.get(r)??a,this._$Em=null}}requestUpdate(e,t,n,r=!1,i){if(e!==void 0){let a=this.constructor;if(!1===r&&(i=this[e]),n??=a.getPropertyOptions(e),!((n.hasChanged??de)(i,t)||n.useDefault&&n.reflect&&i===this._$Ej?.get(e)&&!this.hasAttribute(a._$Eu(e,n))))return;this.C(e,t,n)}!1===this.isUpdatePending&&(this._$ES=this._$EP())}C(e,t,{useDefault:n,reflect:r,wrapped:i},a){n&&!(this._$Ej??=new Map).has(e)&&(this._$Ej.set(e,a??t??this[e]),!0!==i||a!==void 0)||(this._$AL.has(e)||(this.hasUpdated||n||(t=void 0),this._$AL.set(e,t)),!0===r&&this._$Em!==e&&(this._$Eq??=new Set).add(e))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(e){Promise.reject(e)}let e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(let[e,t]of this._$Ep)this[e]=t;this._$Ep=void 0}let e=this.constructor.elementProperties;if(e.size>0)for(let[t,n]of e){let{wrapped:e}=n,r=this[t];!0!==e||this._$AL.has(t)||r===void 0||this.C(t,void 0,n,r)}}let e=!1,t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),this._$EO?.forEach(e=>e.hostUpdate?.()),this.update(t)):this._$EM()}catch(t){throw e=!1,this._$EM(),t}e&&this._$AE(t)}willUpdate(e){}_$AE(e){this._$EO?.forEach(e=>e.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(e){return!0}update(e){this._$Eq&&=this._$Eq.forEach(e=>this._$ET(e,this[e])),this._$EM()}updated(e){}firstUpdated(e){}},pe.elementStyles=[],pe.shadowRootOptions={mode:`open`},pe[le(`elementProperties`)]=new Map,pe[le(`finalized`)]=new Map,ce?.({ReactiveElement:pe}),(ae.reactiveElementVersions??=[]).push(`2.1.2`)}));function he(e,t){if(!Oe(e)||!e.hasOwnProperty(`raw`))throw Error(`invalid template strings array`);return be===void 0?t:be.createHTML(t)}function ge(e,t,n=e,r){if(t===ze)return t;let i=r===void 0?n._$Cl:n._$Co?.[r],a=De(t)?void 0:t._$litDirective$;return i?.constructor!==a&&(i?._$AO?.(!1),a===void 0?i=void 0:(i=new a(e),i._$AT(e,n,r)),r===void 0?n._$Cl=i:(n._$Co??=[])[r]=i),i!==void 0&&(t=ge(e,i._$AS(e,t.values),i,r)),t}var _e,ve,ye,be,xe,Se,Ce,we,Te,Ee,De,Oe,ke,Ae,je,Me,Ne,Pe,Fe,Ie,Le,Re,m,ze,h,Be,Ve,He,Ue,We,Ge,Ke,qe,Je,Ye,Xe,Ze,Qe,$e=t((()=>{_e=globalThis,ve=e=>e,ye=_e.trustedTypes,be=ye?ye.createPolicy(`lit-html`,{createHTML:e=>e}):void 0,xe=`$lit$`,Se=`lit$${Math.random().toFixed(9).slice(2)}$`,Ce=`?`+Se,we=`<${Ce}>`,Te=document,Ee=()=>Te.createComment(``),De=e=>e===null||typeof e!=`object`&&typeof e!=`function`,Oe=Array.isArray,ke=e=>Oe(e)||typeof e?.[Symbol.iterator]==`function`,Ae=`[ 	
\f\r]`,je=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,Me=/-->/g,Ne=/>/g,Pe=RegExp(`>|${Ae}(?:([^\\s"'>=/]+)(${Ae}*=${Ae}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,`g`),Fe=/'/g,Ie=/"/g,Le=/^(?:script|style|textarea|title)$/i,Re=e=>(t,...n)=>({_$litType$:e,strings:t,values:n}),m=Re(1),Re(2),Re(3),ze=Symbol.for(`lit-noChange`),h=Symbol.for(`lit-nothing`),Be=new WeakMap,Ve=Te.createTreeWalker(Te,129),He=(e,t)=>{let n=e.length-1,r=[],i,a=t===2?`<svg>`:t===3?`<math>`:``,o=je;for(let t=0;t<n;t++){let n=e[t],s,c,l=-1,u=0;for(;u<n.length&&(o.lastIndex=u,c=o.exec(n),c!==null);)u=o.lastIndex,o===je?c[1]===`!--`?o=Me:c[1]===void 0?c[2]===void 0?c[3]!==void 0&&(o=Pe):(Le.test(c[2])&&(i=RegExp(`</`+c[2],`g`)),o=Pe):o=Ne:o===Pe?c[0]===`>`?(o=i??je,l=-1):c[1]===void 0?l=-2:(l=o.lastIndex-c[2].length,s=c[1],o=c[3]===void 0?Pe:c[3]===`"`?Ie:Fe):o===Ie||o===Fe?o=Pe:o===Me||o===Ne?o=je:(o=Pe,i=void 0);let d=o===Pe&&e[t+1].startsWith(`/>`)?` `:``;a+=o===je?n+we:l>=0?(r.push(s),n.slice(0,l)+xe+n.slice(l)+Se+d):n+Se+(l===-2?t:d)}return[he(e,a+(e[n]||`<?>`)+(t===2?`</svg>`:t===3?`</math>`:``)),r]},Ue=class e{constructor({strings:t,_$litType$:n},r){let i;this.parts=[];let a=0,o=0,s=t.length-1,c=this.parts,[l,u]=He(t,n);if(this.el=e.createElement(l,r),Ve.currentNode=this.el.content,n===2||n===3){let e=this.el.content.firstChild;e.replaceWith(...e.childNodes)}for(;(i=Ve.nextNode())!==null&&c.length<s;){if(i.nodeType===1){if(i.hasAttributes())for(let e of i.getAttributeNames())if(e.endsWith(xe)){let t=u[o++],n=i.getAttribute(e).split(Se),r=/([.?@])?(.*)/.exec(t);c.push({type:1,index:a,name:r[2],strings:n,ctor:r[1]===`.`?qe:r[1]===`?`?Je:r[1]===`@`?Ye:Ke}),i.removeAttribute(e)}else e.startsWith(Se)&&(c.push({type:6,index:a}),i.removeAttribute(e));if(Le.test(i.tagName)){let e=i.textContent.split(Se),t=e.length-1;if(t>0){i.textContent=ye?ye.emptyScript:``;for(let n=0;n<t;n++)i.append(e[n],Ee()),Ve.nextNode(),c.push({type:2,index:++a});i.append(e[t],Ee())}}}else if(i.nodeType===8)if(i.data===Ce)c.push({type:2,index:a});else{let e=-1;for(;(e=i.data.indexOf(Se,e+1))!==-1;)c.push({type:7,index:a}),e+=Se.length-1}a++}}static createElement(e,t){let n=Te.createElement(`template`);return n.innerHTML=e,n}},We=class{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){let{el:{content:t},parts:n}=this._$AD,r=(e?.creationScope??Te).importNode(t,!0);Ve.currentNode=r;let i=Ve.nextNode(),a=0,o=0,s=n[0];for(;s!==void 0;){if(a===s.index){let t;s.type===2?t=new Ge(i,i.nextSibling,this,e):s.type===1?t=new s.ctor(i,s.name,s.strings,this,e):s.type===6&&(t=new Xe(i,this,e)),this._$AV.push(t),s=n[++o]}a!==s?.index&&(i=Ve.nextNode(),a++)}return Ve.currentNode=Te,r}p(e){let t=0;for(let n of this._$AV)n!==void 0&&(n.strings===void 0?n._$AI(e[t]):(n._$AI(e,n,t),t+=n.strings.length-2)),t++}},Ge=class e{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(e,t,n,r){this.type=2,this._$AH=h,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=n,this.options=r,this._$Cv=r?.isConnected??!0}get parentNode(){let e=this._$AA.parentNode,t=this._$AM;return t!==void 0&&e?.nodeType===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=ge(this,e,t),De(e)?e===h||e==null||e===``?(this._$AH!==h&&this._$AR(),this._$AH=h):e!==this._$AH&&e!==ze&&this._(e):e._$litType$===void 0?e.nodeType===void 0?ke(e)?this.k(e):this._(e):this.T(e):this.$(e)}O(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}T(e){this._$AH!==e&&(this._$AR(),this._$AH=this.O(e))}_(e){this._$AH!==h&&De(this._$AH)?this._$AA.nextSibling.data=e:this.T(Te.createTextNode(e)),this._$AH=e}$(e){let{values:t,_$litType$:n}=e,r=typeof n==`number`?this._$AC(e):(n.el===void 0&&(n.el=Ue.createElement(he(n.h,n.h[0]),this.options)),n);if(this._$AH?._$AD===r)this._$AH.p(t);else{let e=new We(r,this),n=e.u(this.options);e.p(t),this.T(n),this._$AH=e}}_$AC(e){let t=Be.get(e.strings);return t===void 0&&Be.set(e.strings,t=new Ue(e)),t}k(t){Oe(this._$AH)||(this._$AH=[],this._$AR());let n=this._$AH,r,i=0;for(let a of t)i===n.length?n.push(r=new e(this.O(Ee()),this.O(Ee()),this,this.options)):r=n[i],r._$AI(a),i++;i<n.length&&(this._$AR(r&&r._$AB.nextSibling,i),n.length=i)}_$AR(e=this._$AA.nextSibling,t){for(this._$AP?.(!1,!0,t);e!==this._$AB;){let t=ve(e).nextSibling;ve(e).remove(),e=t}}setConnected(e){this._$AM===void 0&&(this._$Cv=e,this._$AP?.(e))}},Ke=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,n,r,i){this.type=1,this._$AH=h,this._$AN=void 0,this.element=e,this.name=t,this._$AM=r,this.options=i,n.length>2||n[0]!==``||n[1]!==``?(this._$AH=Array(n.length-1).fill(new String),this.strings=n):this._$AH=h}_$AI(e,t=this,n,r){let i=this.strings,a=!1;if(i===void 0)e=ge(this,e,t,0),a=!De(e)||e!==this._$AH&&e!==ze,a&&(this._$AH=e);else{let r=e,o,s;for(e=i[0],o=0;o<i.length-1;o++)s=ge(this,r[n+o],t,o),s===ze&&(s=this._$AH[o]),a||=!De(s)||s!==this._$AH[o],s===h?e=h:e!==h&&(e+=(s??``)+i[o+1]),this._$AH[o]=s}a&&!r&&this.j(e)}j(e){e===h?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??``)}},qe=class extends Ke{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===h?void 0:e}},Je=class extends Ke{constructor(){super(...arguments),this.type=4}j(e){this.element.toggleAttribute(this.name,!!e&&e!==h)}},Ye=class extends Ke{constructor(e,t,n,r,i){super(e,t,n,r,i),this.type=5}_$AI(e,t=this){if((e=ge(this,e,t,0)??h)===ze)return;let n=this._$AH,r=e===h&&n!==h||e.capture!==n.capture||e.once!==n.once||e.passive!==n.passive,i=e!==h&&(n===h||r);r&&this.element.removeEventListener(this.name,this,n),i&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){typeof this._$AH==`function`?this._$AH.call(this.options?.host??this.element,e):this._$AH.handleEvent(e)}},Xe=class{constructor(e,t,n){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=n}get _$AU(){return this._$AM._$AU}_$AI(e){ge(this,e)}},Ze=_e.litHtmlPolyfillSupport,Ze?.(Ue,Ge),(_e.litHtmlVersions??=[]).push(`3.3.2`),Qe=(e,t,n)=>{let r=n?.renderBefore??t,i=r._$litPart$;if(i===void 0){let e=n?.renderBefore??null;r._$litPart$=i=new Ge(t.insertBefore(Ee(),e),e,void 0,n??{})}return i._$AI(e),i}})),et,g,tt,nt=t((()=>{me(),me(),$e(),$e(),et=globalThis,g=class extends pe{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){let e=super.createRenderRoot();return this.renderOptions.renderBefore??=e.firstChild,e}update(e){let t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=Qe(t,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return ze}},g._$litElement$=!0,g.finalized=!0,et.litElementHydrateSupport?.({LitElement:g}),tt=et.litElementPolyfillSupport,tt?.({LitElement:g}),(et.litElementVersions??=[]).push(`4.2.2`)})),rt=t((()=>{})),_=t((()=>{me(),$e(),nt(),rt()})),v,it=t((()=>{v=e=>(t,n)=>{n===void 0?customElements.define(e,t):n.addInitializer(()=>{customElements.define(e,t)})}}));function y(e){return(t,n)=>typeof n==`object`?ot(e,t,n):((e,t,n)=>{let r=t.hasOwnProperty(n);return t.constructor.createProperty(n,e),r?Object.getOwnPropertyDescriptor(t,n):void 0})(e,t,n)}var at,ot,st=t((()=>{me(),at={attribute:!0,type:String,converter:ue,reflect:!1,hasChanged:de},ot=(e=at,t,n)=>{let{kind:r,metadata:i}=n,a=globalThis.litPropertyMetadata.get(i);if(a===void 0&&globalThis.litPropertyMetadata.set(i,a=new Map),r===`setter`&&((e=Object.create(e)).wrapped=!0),a.set(n.name,e),r===`accessor`){let{name:r}=n;return{set(n){let i=t.get.call(this);t.set.call(this,n),this.requestUpdate(r,i,e,!0,n)},init(t){return t!==void 0&&this.C(r,void 0,e,t),t}}}if(r===`setter`){let{name:r}=n;return function(n){let i=this[r];t.call(this,n),this.requestUpdate(r,i,e,!0,n)}}throw Error(`Unsupported decorator location: `+r)}}));function b(e){return y({...e,state:!0,attribute:!1})}var ct=t((()=>{st()})),lt=t((()=>{})),ut,dt=t((()=>{ut=(e,t,n)=>(n.configurable=!0,n.enumerable=!0,Reflect.decorate&&typeof t!=`object`&&Object.defineProperty(e,t,n),n)}));function ft(e,t){return(n,r,i)=>{let a=t=>t.renderRoot?.querySelector(e)??null;if(t){let{get:e,set:t}=typeof r==`object`?n:i??(()=>{let e=Symbol();return{get(){return this[e]},set(t){this[e]=t}}})();return ut(n,r,{get(){let n=e.call(this);return n===void 0&&(n=a(this),(n!==null||this.hasUpdated)&&t.call(this,n)),n}})}return ut(n,r,{get(){return a(this)}})}}var pt=t((()=>{dt()})),mt=t((()=>{})),ht=t((()=>{})),gt=t((()=>{})),_t=t((()=>{})),x=t((()=>{it(),st(),ct(),lt(),pt(),mt(),ht(),gt(),_t()}));_(),x();var vt={"panel.title":`RoomMind`,"panel.subtitle":`Climate management`,"panel.tab.rooms":`Rooms`,"panel.edit":`Edit room`,"panel.tab.settings":`Settings`,"panel.loading":`Loading...`,"panel.no_areas":`No areas configured in Home Assistant.`,"panel.no_areas_hint":`Add areas in HA settings to get started.`,"badge.beta":`Beta`,"badge.beta_hint":`This feature is in beta and may change or be restructured in future updates.`,"common.learn_more":`Learn more`,"panel.stat.rooms":`Rooms`,"panel.stat.heating":`Heating`,"panel.stat.cooling":`Cooling`,"panel.stat.vacation":`Vacation`,"panel.stat.away":`Away`,"panel.stat.mold":`Mold`,"panel.hide_room":`Hide`,"panel.unhide":`Show`,"panel.hidden_rooms":`Hidden rooms`,"panel.floor_other":`Other`,"panel.reorder":`Reorder rooms`,"panel.reorder_done":`Done`,"room.back":`Back to rooms`,"room.section.climate_mode":`Climate Mode`,"room.section.schedule":`Schedule & Temperatures`,"room.section.control_mode":`Control Mode`,"room.section.devices":`Devices`,"room.section.sensors":`Sensors`,"room.section.airflow":`Airflow`,"room.section.windows":`Window Sensors`,"room.control_mode.full_control":`Full Control`,"room.control_mode.managed":`Managed`,"room.control_mode.external_sensor":`External sensor: {sensor}`,"room.control_mode.no_sensor":`No external temperature sensor assigned`,"room.control_mode.mpc_active":`MPC active`,"room.control_mode.mpc_learning":`Learning`,"room.control_mode.device_setpoint":`Device setpoint: {temp}`,"room.control_mode.power":`Power: {power}%`,"room.control_mode.full_control_info":`RoomMind has full control over your climate devices. An external temperature sensor provides the actual room temperature, enabling proportional setpoint calculation. The device setpoint is dynamically adjusted based on MPC power output. The thermal model (EKF) learns your room's behavior for optimal comfort and energy efficiency.`,"room.control_mode.managed_info":`RoomMind sets the target temperature on your device (from schedule, override, or vacation settings), but the device self-regulates using its own internal sensor. No proportional boost, no thermal model learning, and no MPC optimization. For more precise control, assign an external temperature sensor in the Devices section.`,"room.delete":`Delete room`,"room.deleting":`Deleting...`,"room.saving":`Saving...`,"room.saved":`Saved`,"room.error_saving":`Error saving`,"room.confirm_delete":`Remove RoomMind configuration for "{name}"?`,"room.error_save_fallback":`Failed to save configuration`,"room.error_delete_fallback":`Failed to delete configuration`,"room.climate_control_toggle":`Climate control`,"room.climate_control_hint":`When disabled, RoomMind will not control devices in this room`,"room.outdoor_toggle":`Outdoor area`,"room.outdoor_hint":`Disables climate control, mold detection, and model training. Sensor monitoring continues.`,"room.alias.placeholder":`Custom display name`,"room.alias.clear":`Reset to area name`,"override.label":`Temporary Override`,"override.comfort":`Comfort`,"override.eco":`Eco`,"override.custom":`Custom`,"override.target":`Target:`,"override.activate_for":`Activate for:`,"override.error_set":`Failed to set override`,"override.error_clear":`Failed to clear override`,"hero.target":`Target`,"hero.override":`Override`,"hero.remaining":`{time} remaining`,"hero.humidity":`{value}% humidity`,"hero.device_setpoint":`Device set to {value}{unit}`,"hero.heat_source_primary":`Heating: TRV`,"hero.heat_source_secondary":`Heating: AC`,"hero.heat_source_both":`Heating: TRV + AC`,"hero.permanent":`Permanent`,"hero.waiting":`Waiting for sensor data...`,"hero.not_configured":`Not configured yet`,"hero.mpc_learning_paused":`MPC learning paused`,"hero.mpc_learning_paused.outdoor_unavailable":`RoomMind needs an outdoor temperature to learn this room's thermal model. The configured outdoor sensor is unavailable and no weather entity is set as a fallback. Configure either in Settings.`,"card.target":`Target`,"card.waiting":`Waiting for data...`,"card.humidity":`{value}% humidity`,"card.thermostat":`Thermostat`,"card.thermostats":`Thermostats`,"card.ac":`AC`,"card.acs":`ACs`,"card.climate_device":`climate device`,"card.climate_devices":`climate devices`,"card.temp_sensor":`temp sensor`,"card.temp_sensors":`temp sensors`,"card.no_climate":`No climate devices`,"card.outdoor":`Outdoor`,"card.tap_configure":`Tap to configure`,"card.mpc_active":`MPC active`,"card.mpc_learning":`MPC learning`,"card.not_controlled":`Not controlled by RoomMind`,"mode.auto":`Auto`,"mode.auto_desc":`Heats & cools automatically based on target temperature`,"mode.heat_only":`Heat Only`,"mode.heat_only_desc":`Only uses thermostats, ACs stay off`,"mode.cool_only":`Cool Only`,"mode.cool_only_desc":`Only uses ACs, thermostats stay off`,"mode.heating":`Heating`,"mode.cooling":`Cooling`,"mode.fan_only":`Fan only`,"mode.idle":`Standby`,"schedule.add_schedule":`Add schedule`,"schedule.select_schedule":`Select schedule helper`,"schedule.create_helper_hint":`Create new schedule helper in HA settings`,"schedule.selector_label":`Schedule selector entity`,"schedule.selector_value_boolean":`Current: {value}`,"schedule.selector_value_number":`Current value: {value}`,"schedule.selector_warning":`Multiple schedules but no selector set. Only the first will be used.`,"schedule.off_action_label":`Action when schedule is off`,"schedule.off_action_eco":`Use eco temperature`,"schedule.off_action_off":`Turn off devices`,"schedule.state_active":`Active`,"schedule.state_inactive":`Inactive`,"schedule.state_unreachable":`Unreachable`,"schedule.no_schedules":`No schedules configured`,"schedule.done":`Done`,"schedule.view_comfort":`Comfort: {temp}{unit}`,"schedule.view_eco":`Eco: {temp}{unit}`,"schedule.view_selector":`Active schedule selected by: {name}`,"schedule.view_selector_prefix":`Active schedule selected by:`,"schedule.help_header":`How do schedules work?`,"schedule.help_temps_title":`How is the target temperature determined?`,"schedule.help_temps":`The target temperature follows this priority chain:`,"schedule.help_temps_1":`<strong>Manual override</strong> – A temporary boost/eco/custom override always takes highest priority.`,"schedule.help_temps_2":`<strong>Block temperature</strong> – If the active schedule block has a <code>temperature</code> value in its data, that value is used.`,"schedule.help_temps_3":`<strong>Comfort temperature</strong> – If the schedule is "on" but the block has no temperature, the comfort fallback temperature below is used.`,"schedule.help_temps_4":`<strong>Eco temperature</strong> – When the schedule is "off" (outside all time blocks), the eco temperature is used.`,"schedule.help_block_title":`Setting temperature per time block`,"schedule.help_block":`You can set a specific temperature for each time block by adding a <code>temperature</code> value in the schedule's YAML configuration:`,"schedule.help_block_note":`If a block has no <code>temperature</code> data, the comfort fallback temperature is used instead.`,"schedule.help_split_title":`Separate heating/cooling targets per block`,"schedule.help_split":`For auto-mode rooms, you can set separate heating and cooling targets per time block using <code>heat_temperature</code> and <code>cool_temperature</code>:`,"schedule.help_split_note":`If only one is set, the other falls back to the room's comfort temperature. These keys take priority over <code>temperature</code> when present.`,"schedule.help_multi_title":`Multiple schedules`,"schedule.help_multi":`You can add multiple schedules and switch between them using a <strong>selector entity</strong>. This can be an <code>input_boolean</code> (toggles between schedule 1 and 2) or an <code>input_number</code> (selects by number). Without a selector entity, only the first schedule is used.`,"schedule.column_comfort":`Comfort`,"schedule.column_eco":`Eco`,"schedule.row_heat":`Heat`,"schedule.row_cool":`Cool`,"schedule.view_heat":`Heat: {comfort} / {eco}{unit}`,"schedule.view_cool":`Cool: {comfort} / {eco}{unit}`,"schedule.comfort_hint_auto":`Comfort: target when schedule is on. Eco: target when schedule is off. Rows set the target for heating and cooling.`,"schedule.comfort_label":`Fallback comfort temperature`,"schedule.eco_label":`Eco temperature`,"schedule.comfort_hint":`Used when schedule is "on" but no temperature is set in the block`,"schedule.from_schedule":`{temp}{unit} from schedule`,"schedule.from_schedule_split":`{heat}{unit} / {cool}{unit} from schedule`,"schedule.fallback":`{temp}{unit} (fallback)`,"schedule.eco_detail":`{temp}{unit} (eco)`,"devices.climate_entities":`Climate entities`,"devices.temp_sensors":`Temperature sensors`,"devices.primary_sensor":`Primary`,"devices.humidity_sensors":`Humidity sensors`,"devices.no_climate":`No climate entities found in this area.`,"devices.no_temp_sensors":`No temperature sensors found in this area.`,"devices.no_humidity_sensors":`No humidity sensors found in this area.`,"devices.occupancy_sensors":`Occupancy Sensors`,"devices.no_occupancy_sensors":`No occupancy sensors found in this area`,"devices.occupancy_sensor_hint":`Improves thermal model accuracy by tracking room occupancy`,"devices.window_sensors":`Window / door sensors`,"devices.no_window_sensors":`No window/door sensors found in this area.`,"devices.window_open_delay":`Delay before pausing`,"devices.window_close_delay":`Delay before resuming`,"devices.add_entity":`Add entity`,"devices.done":`Done`,"devices.other_area":`Other area`,"devices.type_thermostat":`Thermostat`,"devices.type_ac":`Climate Device`,"devices.type_label":`Type`,"devices.select_to_configure":`Select a device to configure`,"devices.heating_system_type":`Heating System Type`,"devices.heating_system_type_info":`After heating stops, radiators and especially underfloor systems continue to release stored heat. RoomMind accounts for this residual heat to avoid overshooting and improve model accuracy. Underfloor rooms also get longer minimum run times.`,"devices.system_type_none":`Standard (no residual heat)`,"devices.system_type_radiator":`Radiator`,"devices.system_type_underfloor":`Underfloor Heating`,"devices.underfloor_delay_hint":`Underfloor heating has long restart times. A window-open delay of at least 5 minutes is recommended to avoid unnecessary shutoffs.`,"devices.heating_system_type_boost_hint":`Tip: If the heating system has changed, you can accelerate re-learning under Settings.`,"devices.idle_action":`When idle`,"devices.idle_action_off":`Turn off`,"devices.idle_action_fan_only":`Fan only`,"devices.idle_action_setback":`Setback`,"devices.idle_action_low":`Low setpoint (keep awake)`,"devices.idle_action_low_hint":`Lowers the setpoint to the device minimum instead of sending off. Prevents TRVs that hibernate in off mode from losing later commands.`,"devices.idle_fan_mode":`Fan speed`,"devices.idle_fan_mode_keep":`Don't change`,"devices.setpoint_mode":`Setpoint mode`,"devices.setpoint_mode_proportional":`Proportional (valve control)`,"devices.setpoint_mode_direct":`Direct (device regulates)`,"devices.setpoint_mode_hint":`Direct sends the actual room target to the device — best for thermostats and space heaters that regulate themselves. Proportional sends a boosted setpoint toward the device max_temp — best for radiator valves (TRVs).`,"devices.valve_protection_excluded":`Excluded from valve protection`,"devices.valve_protection_exclude_hint":`This entity will not be cycled by valve protection (e.g. virtual boiler entities)`,"devices.info.types_title":`Device types`,"devices.info.types_body":`Thermostat means a radiator thermostat / TRV. Climate Device means an AC, heat pump, or other climate entity used for cooling or forced-air heating. Both are Home Assistant climate entities; the distinction is how RoomMind controls them.`,"devices.info.control_title":`How RoomMind controls them`,"devices.info.control_body":`Setpoint mode only applies to thermostats in Full Control rooms with an external temperature sensor. Use Proportional when RoomMind should drive heating output by sending boosted setpoints. Use Direct when the device should regulate itself around the real target temperature.`,"devices.info.modes_title":`Idle behavior`,"devices.info.modes_body":`When idle only applies to Climate Devices. Turn off powers the device down. Fan only keeps airflow without heating or cooling. Setback keeps the current mode active but moves the target 2°C away from the room target. This setback offset is currently fixed. For Thermostats, Low keeps the TRV active at its minimum setpoint instead of off, useful for battery-powered Zigbee TRVs that sleep when set to off.`,"devices.info.heat_source_title":`Smart source selection`,"devices.info.heat_source_body":`This appears only when a room has both a thermostat/TRV and a Climate Device plus an external temperature sensor. RoomMind can then choose which source should handle heating based on temperature gap and outdoor conditions.`,"airflow.devices":`Airflow devices`,"airflow.no_devices":`No airflow devices configured.`,"airflow.no_candidates":`No fan or airflow-capable climate entities found in this area.`,"airflow.add_entity":`Add airflow entity`,"airflow.role":`Role`,"airflow.role_circulation":`Circulation`,"airflow.role_ventilation":`Ventilation`,"airflow.role_hvac_fan":`HVAC fan`,"airflow.controllable":`Controllable`,"airflow.controllable_hint":`RoomMind may consider this device when building airflow levels.`,"airflow.control_enabled":`Allow control`,"airflow.control_enabled_hint":`When enabled, MPC can command fan speed, fan-only mode, or swing settings.`,"airflow.controllable_short":`Control`,"airflow.control_enabled_short":`Auto`,"airflow.direction":`Direction`,"airflow.direction_forward":`Forward`,"airflow.direction_reverse":`Reverse`,"airflow.preset_mode":`Preset mode`,"airflow.oscillating":`Oscillation`,"airflow.swing_mode":`Swing mode`,"airflow.swing_horizontal_mode":`Horizontal swing`,"airflow.keep":`Keep current`,"airflow.on":`On`,"airflow.off":`Off`,"airflow.plan_level":`MPC level`,"airflow.mix_plan_level":`Mix plan`,"airflow.vent_plan_level":`Vent plan`,"airflow.mix_factor":`Mix factor`,"airflow.vent_factor":`Ventilation factor`,"airflow.ach":`ACH`,"airflow.planned_level":`Planned`,"airflow.actual_level":`Actual`,"airflow.command_applied":`Applied`,"airflow.command_unsupported_fan_only":`No fan-only`,"airflow.command_skipped_off_climate":`Climate off`,"airflow.command_blocked_by_mode":`Skipped`,"airflow.command_failed":`Failed`,"airflow.command_control_disabled":`Control off`,"airflow.unavailable":`Unavailable`,"airflow.info_title":`Observed airflow factors`,"airflow.info_body":`Circulation and HVAC fan devices are treated as mixing factors that can reduce sensor disagreement. Ventilation devices are treated as outdoor-air exchange and influence the thermal prediction.`,"airflow.info_control_title":`Control behavior`,"airflow.info_control_body":`RoomMind only sends fan or climate airflow commands when both Controllable and Allow control are enabled for a device. HVAC fans can start while idle only when the climate entity supports fan-only mode; heating and cooling setpoint control stays in the main device section.`,"hero.window_open":`Window open – paused`,"card.window_open":`Window open`,"room.section.covers":`Covers & Blinds`,"covers.section_title":`Covers & Blinds`,"covers.auto_control":`Automatic blind control`,"covers.auto_control_hint":`RoomMind closes blinds when solar gain is predicted to overheat the room.`,"covers.deploy_threshold":`Deploy threshold`,"covers.deploy_threshold_hint":`Close blinds when predicted temperature exceeds target by this amount.`,"covers.min_position":`Minimum open position`,"covers.min_position_hint":`Blinds will never close further than this (0 = fully closed allowed).`,"covers.override_minutes":`Override pause duration`,"covers.override_minutes_hint":`How long to pause automatic control after manual cover movement. Set to 0 for no pause.`,"covers.no_covers":`No cover entities configured.`,"covers.no_covers_in_area":`No cover entities found in this area.`,"covers.add_cover":`Add cover entity...`,"covers.shading_active":`Shading active`,"covers.auto_paused":`Auto paused (manual override)`,"covers.done":`Done`,"covers.night_close":`Close at night`,"covers.night_close_hint":`Automatically close covers at sunset and open at sunrise.`,"covers.night_close_active":`Night closing active`,"covers.schedule_group_title":`Schedule`,"covers.solar_group_title":`Solar control`,"covers.schedule_section":`Cover schedules`,"covers.schedule_section_hint":`Define time windows for cover control using HA schedule helpers. In Force position mode the schedule's position overrides solar/thermal logic. In Allow solar protection mode RoomMind decides the position within the active window.`,"covers.add_schedule":`Add cover schedule...`,"covers.schedule_mode_force":`Force position`,"covers.schedule_mode_gate":`Allow solar protection`,"covers.schedule_mode_gate_short":`Solar gate`,"covers.schedule_position":`Position`,"covers.schedule_position_hint":`Cover position when this schedule is active (0% = fully closed, 100% = fully open).`,"covers.schedule_selector":`Schedule selector entity`,"covers.schedule_selector_hint":`Choose which schedule is active. input_boolean: off=#1, on=#2. input_number: value selects schedule number.`,"covers.schedule_selector_warning":`Multiple schedules configured but no selector set. Only the first schedule will be used.`,"covers.schedule_state_active":`Active`,"covers.schedule_state_inactive":`Inactive`,"covers.schedule_state_unreachable":`Unreachable`,"covers.schedule_active":`Schedule active`,"covers.schedule_create_link":`Create schedule helper`,"covers.night_position":`Night position`,"covers.night_position_hint":`Cover position when night close is active (0% = fully closed). Covers with an individual min. position will never go below that.`,"covers.night_close_advanced":`Advanced`,"covers.night_close_elevation":`Sun position threshold`,"covers.night_close_elevation_hint":`How far below or above the horizon the sun must be. 0° = exactly at sunset/sunrise. Negative = darker (e.g. -6° = dusk, when it's noticeably dark). Positive = still bright (e.g. 5° = sun still visible above horizon).`,"covers.night_close_offset":`Time offset`,"covers.night_close_offset_hint":`Additional shift relative to the sun position threshold. Positive = close later (e.g. +20 = 20 min after threshold is reached), negative = close earlier.`,"covers.outdoor_min_temp":`Min. outdoor temperature`,"covers.outdoor_min_temp_hint":`Don't close covers for solar protection below this outdoor temperature. Solar heat gain is welcome when it's cold.`,"covers.per_cover_title":`Per-cover settings`,"covers.per_cover_hint":`Set the compass direction each cover faces and optional individual minimum positions.`,"covers.per_cover_min_short":`Min`,"covers.per_cover_min_position":`Min. position`,"covers.per_cover_min_position_hint":`Individual minimum position per cover. Covers will never close further than this. Useful when blinds are physically fully closed at a position > 0%.`,"covers.snap_deploy":`Snap to minimum position`,"covers.snap_deploy_hint":`Close covers directly to the minimum position instead of gradually closing. Recommended for triple-pane windows where intermediate positions can cause thermal stress.`,"covers.info.selection_title":`Cover selection`,"covers.info.selection_body":`Select covers/blinds from this area or add entities from other areas. RoomMind tracks their position and can control them automatically.`,"covers.info.schedule_title":`Schedule control`,"covers.info.schedule_body":`Use HA schedule helpers to define times when covers should close (e.g. privacy in the evening). The schedule's position attribute determines how far they close. Schedules override all other automatic logic.`,"covers.info.solar_title":`Solar/thermal control`,"covers.info.solar_body":`When automatic control is enabled, RoomMind predicts whether solar radiation will overheat the room and closes blinds preventively. It uses learned thermal data when available, otherwise a conservative default. The deploy threshold controls how much predicted overshoot is needed before blinds close.`,"covers.info.night_title":`Night closing`,"covers.info.night_body":`Closes covers at sunset and opens them at sunrise. You can set a custom night position (e.g. 10% = almost closed but not fully).`,"covers.info.override_title":`Manual override`,"covers.info.override_body":`If you manually move a cover, RoomMind detects this and pauses automatic control for the configured duration. This prevents fighting with the user.`,"covers.info.priority_title":`Priority order`,"covers.info.priority_body":`Manual override > Schedule > Night close > Solar/thermal control. Higher priority rules always win. When no rule applies, covers stay open.`,"covers.info.entities_title":`HA entities`,"covers.info.entities_body":`RoomMind creates two entities per room for external use: switch.roommind_{area}_cover_auto (enable/disable automatic cover control — usable in automations or dashboards) and binary_sensor.roommind_{area}_cover_paused (on when manual override is active, e.g. after manually moving a cover).`,"covers.orientation_group_title":`Cover orientation`,"covers.orientation_hint":`Set the compass direction each cover faces. RoomMind uses this to skip solar deployment when the sun is not shining on that side of the building.`,"covers.orientation_none":`Any direction`,"covers.orientation_N":`N`,"covers.orientation_NE":`NE`,"covers.orientation_E":`E`,"covers.orientation_SE":`SE`,"covers.orientation_S":`S`,"covers.orientation_SW":`SW`,"covers.orientation_W":`W`,"covers.orientation_NW":`NW`,"covers.orientation_N_full":`North`,"covers.orientation_NE_full":`Northeast`,"covers.orientation_E_full":`East`,"covers.orientation_SE_full":`Southeast`,"covers.orientation_S_full":`South`,"covers.orientation_SW_full":`Southwest`,"covers.orientation_W_full":`West`,"covers.orientation_NW_full":`Northwest`,"settings.general_title":`General`,"settings.group_by_floor":`Group rooms by floor`,"settings.climate_control_active":`Climate control active`,"settings.climate_control_hint":`When disabled, RoomMind continues to monitor all sensors and train the model, but will not send any commands to your heating or cooling devices.`,"settings.learning_title":`Model Training`,"settings.learning_hint":`When paused, RoomMind stops collecting new measurement data and training the thermal model. Existing model data is preserved.`,"settings.learning_exceptions":`Exceptions`,"settings.learning_room_paused":`room paused`,"settings.learning_rooms_paused":`rooms paused`,"settings.sensors_title":`Sensors & Data Sources`,"settings.control_title":`Control`,"settings.outdoor_sensor":`Outdoor Temperature`,"settings.outdoor_sensor_label":`Outdoor temperature sensor`,"settings.outdoor_current":`Currently {temp}{unit} outside`,"settings.outdoor_waiting":`Waiting for sensor data...`,"settings.outdoor_humidity_sensor":`Outdoor Humidity`,"settings.outdoor_humidity_label":`Outdoor humidity sensor`,"settings.outdoor_humidity_current":`Currently {value}% outside`,"settings.smart_control":`Smart Climate Control`,"settings.smart_control_hint":`Configure outdoor temperature limits for heating and cooling.`,"settings.outdoor_cooling_min":`Minimum outdoor temp for cooling`,"settings.outdoor_cooling_min_hint":`AC stays off when outdoor temperature is below this value`,"settings.outdoor_heating_max":`Maximum outdoor temp for heating`,"settings.outdoor_heating_max_hint":`Heating stays off when outdoor temperature exceeds this value`,"settings.saving":`Saving...`,"settings.saved":`Saved`,"settings.error":`Error saving`,"devices.using_builtin_sensor":`Using thermostat's built-in sensor`,"settings.climate_intelligence":`Climate Intelligence`,"settings.control_mode":`Control Mode`,"settings.control_mode_simple":`Simple (Bang-Bang)`,"settings.control_mode_mpc":`Intelligent (MPC)`,"settings.control_mode_hint":`MPC learns your room's thermal behavior for optimal control`,"settings.comfort_weight":`Priority`,"settings.comfort_weight_comfort":`Comfort`,"settings.comfort_weight_efficiency":`Efficiency`,"settings.comfort_weight_hint":`Balances temperature precision against energy use. Comfort reacts earlier and stays closer to target. Efficiency allows more drift to reduce heating/cooling runtime.`,"settings.weather_entity":`Weather Forecast`,"settings.weather_entity_hint":`Optional: enables predictive outdoor temperature planning, and acts as a fallback when the outdoor sensor is unavailable`,"settings.outdoor_unavailable_notify":`Notify when outdoor temperature is unavailable`,"settings.outdoor_unavailable_notify_hint":`Show a Home Assistant notification when neither the outdoor sensor nor the weather entity has reported a temperature for 30 minutes. While this is the case, RoomMind pauses thermal model learning to avoid corruption.`,"settings.prediction_enabled":`Temperature prediction`,"settings.prediction_enabled_hint":`Show predicted temperature trend in analytics charts. Disable if you experience slow performance.`,"vacation.title":`Vacation Mode`,"vacation.hint":`Sets all rooms to a setback temperature until the end date.`,"vacation.active_label":`Vacation mode active`,"vacation.end_date":`End date & time`,"vacation.setback_temp":`Setback temperature`,"vacation.no_end_date":`No end date`,"vacation.deactivate":`Deactivate`,"tabs.analytics":`Analytics`,"analytics.select_room":`Select Room`,"analytics.temperature":`Temperature`,"analytics.target":`Target`,"analytics.prediction":`Prediction`,"analytics.outdoor":`Outdoor`,"analytics.model_status":`Model Status`,"analytics.confidence":`Confidence`,"analytics.heating_rate":`Heating Strength`,"analytics.cooling_rate":`Cooling Strength`,"analytics.solar_gain":`Solar Gain`,"analytics.occupancy_gain":`Occupancy Gain`,"analytics.time_constant":`Time Constant`,"analytics.samples":`Samples`,"analytics.prediction_accuracy":`Prediction Accuracy`,"analytics.avg_deviation":`Avg. Deviation`,"analytics.data_sources":`Data Sources`,"analytics.data_points":`Data Points`,"analytics.control_mode":`Control Mode`,"analytics.control_mode_mpc":`MPC active`,"analytics.control_mode_bangbang":`MPC learning`,"analytics.last_model_update":`Last Model Update`,"analytics.accuracy_idle":`Accuracy (Idle)`,"analytics.accuracy_heating":`Accuracy (Heating)`,"analytics.info.accuracy_idle":`How precisely the model predicts temperature when neither heating nor cooling is active. A lower value means the model understands your room's natural heat loss well. This is the first value to improve because idle data is collected continuously.`,"analytics.info.accuracy_heating":`How precisely the model predicts temperature during active heating. This value stays high initially because the model needs real heating cycles to learn from. Once your heating has run a few times, this value will drop and MPC control becomes available.`,"analytics.info.confidence":`Overall model readiness for intelligent MPC control, combining two factors: data quantity (how many idle and active-mode samples have been collected) and prediction accuracy (how precise the temperature forecasts are). Confidence starts at 0% and rises as the model collects data and learns. Around 50% means enough idle data but still waiting for heating/cooling cycles. Above 80% means the model has enough data and accurate predictions — MPC control becomes available. 100% is the theoretical maximum when predictions are as accurate as physically possible.`,"analytics.info.time_constant":`How long it takes your room to naturally cool down halfway toward the outdoor temperature when heating is off. A longer time constant means better insulation — the room holds warmth longer. A short time constant means the room cools quickly. The model learns this by observing temperature drops during idle periods.`,"analytics.info.heating_rate":`How strongly your heating affects the room temperature. A higher value means your heating system warms the room faster relative to its thermal mass. The model learns this by observing how quickly the temperature rises during active heating, and uses it to predict how long heating needs to run.`,"analytics.info.cooling_rate":`How strongly your AC affects the room temperature. A higher value means the AC cools the room faster relative to its thermal mass. The model learns this by observing how quickly the temperature drops during active cooling, and uses it to predict how long the AC needs to run.`,"analytics.info.solar_gain":`The estimated effect of solar radiation through windows on room temperature. The model learns this by observing how the room warms during sunny periods when heating is off. Rooms with large south-facing windows will have higher values. The model uses this to reduce heating when solar gain is expected.`,"analytics.info.occupancy_gain":`The estimated heat contribution from occupancy (people, pets, computers) while the room is occupied. The model learns this by observing temperature changes when the configured occupancy sensors are active. Separating this from solar gain prevents body heat from being misattributed to sunlight. Only shown when at least one occupancy sensor is configured for this room.`,"analytics.info.data_sources":`Number of measurement samples used for model training.`,"analytics.info.data_points":`Total number of observations the model has been trained on. More data points generally lead to better predictions. The model collects a new data point roughly every 3 minutes while RoomMind is running.`,"analytics.no_data":`No data yet — model is learning`,"analytics.loading":`Loading analytics...`,"settings.reset_title":`Reset Thermal Data`,"settings.reset_hint":`Clear learned thermal model data and history. The model will start learning from scratch.`,"settings.reset_all_label":`All rooms`,"settings.reset_all_hint":`Clear thermal data and history for all rooms at once.`,"settings.reset_all_btn":`Reset all`,"settings.reset_all_confirm":`Clear all learned thermal data and history for ALL rooms? All models will start learning from scratch.`,"settings.reset_room_label":`Individual room`,"settings.reset_room_hint":`Select a room to clear its thermal data and history.`,"settings.reset_room_confirm":`Clear all learned thermal data and history for this room? The model will start learning from scratch.`,"settings.reset_room_select":`Select room`,"settings.reset_btn":`Reset`,"settings.reset_no_rooms":`No configured rooms.`,"settings.boost_title":`Accelerate Learning`,"settings.boost_hint":`The thermal model learns your room's heating and cooling behavior over time. After major changes (new radiator, AC, insulation, furniture), the model may be inaccurate. This increases the model's uncertainty so it adapts faster to new conditions.`,"settings.boost_label":`Accelerate learning`,"settings.boost_room_select":`Select room`,"settings.boost_btn":`Accelerate`,"settings.boost_cooldown":`Active – re-learning in progress`,"settings.boost_no_rooms":`No configured rooms.`,"analytics.range_1d":`Today`,"analytics.range_2d":`2 days`,"analytics.range_7d":`Week`,"analytics.range_30d":`Month`,"analytics.export":`Measurements`,"analytics.heating_period":`Heating`,"analytics.cooling_period":`Cooling`,"analytics.blind_position":`Blind position`,"analytics.window_open_period":`Window open`,"analytics.chart_info_title":`How to read this chart`,"analytics.exported":`Exported!`,"analytics.copy_diagnostics":`Diagnostics`,"analytics.export_download":`Download file`,"analytics.export_clipboard":`Copy to clipboard`,"analytics.copied_to_clipboard":`Copied!`,"analytics.range_from":`From`,"analytics.range_to":`To`,"analytics.chart_info_body":`**Lines:** The solid orange line shows the measured room temperature. The green dashed line is the target temperature from your schedule. The blue dotted line is the model's temperature prediction.

**Shaded areas:** Red shading marks heating periods, blue marks cooling, and teal marks times when a window was open.

**Future forecast (right of the 'now' line):** The green dashed line shows the upcoming schedule targets for the next 3 hours. The blue dotted line shows the predicted temperature trend.

**Prediction modes:** When 'MPC active' is shown, the prediction uses the full MPC optimizer with intelligent pre-heating/pre-cooling. While the model is still learning, a simpler simulation is used.

**Limitations:** The prediction assumes current conditions stay constant (outdoor temperature, window state). The simulation accuracy depends on how well the thermal model has learned your room — early on, predictions may be less accurate. Once MPC activates, predictions become significantly more reliable.`,"presence.title":`Presence Detection`,"presence.hint":`Uses eco temperature when nobody is home.`,"presence.hint_detail":`When enabled, all rooms switch to eco temperature as soon as none of the configured persons are home. You can optionally restrict per room which persons are relevant.`,"presence.add_person":`Add person`,"presence.add_entity":`Add presence entity`,"presence.person_label":`Person`,"room.section.presence":`Presence`,"presence.room_help_header":`How does per-room presence work?`,"presence.room_help_body":`Select which persons are relevant for this room. The room switches to eco temperature when none of the selected persons are home. Without selection, the global rule applies: eco when nobody is home.`,"presence.state_home":`Home`,"presence.state_away":`Away`,"presence.room_none_assigned":`Global rule — eco when nobody is home`,"presence.ignore_toggle":`Ignore presence`,"presence.ignore_hint":`Controls how this room reacts to presence. You can assign specific persons below. The room switches to eco when none of the assigned persons are home. Use the toggle above to skip detection entirely and always follow the schedule.`,"presence.help_ignore_title":`What does "Ignore presence" do?`,"presence.help_ignore_body":`When enabled, this room skips presence detection entirely. It always follows its schedule and never switches to eco based on who is home. Useful for rooms that should maintain temperature regardless of presence, such as a server room, a pet room, or a guest room used by someone not tracked by Home Assistant.`,"presence.tile_ignored":`Presence detection is ignored. Room always follows its schedule.`,"presence.away_action_label":`Action when nobody is home`,"presence.away_action_eco":`Use eco temperature`,"presence.away_action_off":`Turn off devices`,"presence.clears_override_label":`Absence stops override`,"presence.clears_override_hint":`When nobody is home, manual overrides are paused and the room follows the away action. When someone returns, the override resumes until it expires.`,"card.presence_away":`Away`,"valve_protection.title":`Valve Protection`,"valve_protection.hint":`Periodically opens idle TRV valves briefly to prevent seizing or calcification.`,"valve_protection.interval_label":`Cycle interval`,"valve_protection.interval_suffix":`days`,"valve_protection.interval_hint":`How long a valve can be idle before being cycled (1–90 days)`,"compressor.title":`Compressor Protection`,"compressor.no_groups":`No compressor groups configured.`,"compressor.add_group":`Add compressor group`,"compressor.group_name":`Group name`,"compressor.members":`Indoor units`,"compressor.members_hint":`Select all climate devices powered by this compressor (indoor splits, TRVs on radiators, fan coils).`,"compressor.min_run":`Minimum run time`,"compressor.min_run_hint":`Compressor must run at least this long once started.`,"compressor.min_run_suffix":`min`,"compressor.min_off":`Minimum off time`,"compressor.min_off_hint":`Compressor must stay off at least this long after stopping.`,"compressor.min_off_suffix":`min`,"compressor.delete":`Delete group`,"compressor.delete_confirm":`Delete compressor group "{name}"?`,"compressor.master_entity":`Master device`,"compressor.master_entity_hint":`The central unit that powers the indoor devices in this group, e.g. a gas boiler, outdoor heat pump unit, or ducted AC master switch. RoomMind will turn it on when any room needs heating or cooling, and off when all rooms are idle. Leave empty to use only the action script or short-cycle protection.`,"compressor.conflict_resolution":`Conflict resolution`,"compressor.conflict_resolution_hint":`Determines what happens when some rooms need heating while others need cooling at the same time. Heating priority: heating always wins (safest for frost protection). Cooling priority: cooling always wins. Majority: the mode with more rooms wins, ties go to heating. Outdoor temperature: uses the outdoor heating max threshold from settings to decide automatically.`,"compressor.conflict_heating_priority":`Heating priority (frost protection)`,"compressor.conflict_cooling_priority":`Cooling priority`,"compressor.conflict_majority":`Majority wins`,"compressor.conflict_outdoor_temp":`Based on outdoor temperature`,"compressor.action_script":`Action script`,"compressor.action_script_hint":`A Home Assistant script that runs whenever the heating/cooling demand changes. Useful for systems that need special commands, e.g. cancelling a Vaillant Quick Veto or toggling a relay. Works with or without a master device. Without a master device, only the script is triggered. Receives variables: action (heat/cool/idle), master_entity, members, active_members.`,"compressor.enforce_uniform_mode":`Enforce uniform mode`,"compressor.enforce_uniform_mode_hint":`All thermostats in this group must operate in the same HVAC mode (all heating or all cooling). Rooms that disagree with the resolved group mode will be set to idle. Use this for heat pumps that start automatically but require all connected units to run the same mode.`,"mold.title":`Mold Risk Protection`,"mold.detection":`Mold Detection`,"mold.detection_desc":`Receive notifications when humidity indicates mold risk`,"mold.threshold":`Humidity threshold (%)`,"mold.threshold_hint":`Alert when room humidity stays above this value`,"mold.sustained":`Sustained duration (minutes)`,"mold.sustained_hint":`Alert only after risk persists for this long`,"mold.prevention":`Mold Prevention`,"mold.prevention_desc":`Automatically raise temperature to reduce mold risk`,"mold.intensity":`Intensity`,"mold.intensity_light":`Light (+{delta}{unit})`,"mold.intensity_medium":`Medium (+{delta}{unit})`,"mold.intensity_strong":`Strong (+{delta}{unit})`,"mold.intensity_hint":`Warmer air reduces surface humidity on cold walls. Light is usually sufficient for moderate risk, Strong can lower surface humidity by up to 8–10% — but uses noticeably more energy.`,"card.mold_warning":`Mold risk`,"card.mold_critical":`Mold danger!`,"card.mold_prevention":`Mold prevention +{delta}{unit}`,"room.mold_surface_rh":`Est. surface humidity: {value}%`,"settings.intro.general":`Basic display and control settings.`,"settings.intro.sensors":`Configure outdoor sensors and weather data for accurate climate control.`,"settings.intro.control":`Choose how RoomMind controls your climate devices and set priority and thresholds.`,"settings.intro.presence":`Automatically reduce temperature when nobody is home.`,"settings.intro.vacation":`Set all rooms to a reduced temperature while you are away.`,"settings.intro.valve":`Periodically move idle TRV valves to prevent seizing or calcification.`,"settings.intro.compressor":`Manage groups of indoor units that share an outdoor compressor or central heating source. Optionally assign a master device (boiler, outdoor unit) to automatically turn on/off based on room demand. Short-cycle protection prevents rapid on/off switching that can damage equipment.`,"settings.intro.mold":`Monitor humidity and automatically reduce mold risk.`,"settings.intro.notifications":`Configure who receives alerts and how.`,"settings.intro.learning":`Manage thermal model training and accelerate re-learning after changes.`,"settings.intro.reset":`Clear learned thermal model data. The model will start learning from scratch.`,"notifications.title":`Notifications`,"notifications.enabled":`Enable notifications`,"notifications.enabled_hint":`When disabled, no notifications are sent — neither to devices nor to the HA sidebar.`,"notifications.desc":`Choose which devices receive alerts. Without targets, alerts appear in the HA sidebar.`,"notifications.add_target_label":`Add notification device`,"notifications.add_target_hint":`Type the entity ID if your device is not listed (e.g. notify.mobile_app_...). You can find it under Settings → Devices → your phone → Notify entity.`,"notifications.target_unnamed":`Unnamed device`,"notifications.target_person":`Person`,"notifications.target_when_always":`Always`,"notifications.target_when_home":`Only when home`,"notifications.cooldown":`Notification cooldown (minutes)`,"notifications.cooldown_hint":`Minimum time between repeated alerts per room`,"notifications.mold_prevention_notify":`Notify when mold prevention activates`,"notifications.mold_prevention_notify_hint":`Also send a notification when prevention activates (temperature raised)`,"room.section.heat_source":`Heat Source Orchestration`,"heat_source.toggle":`Smart source selection`,"heat_source.toggle_hint":`When this room has both radiator thermostats and an AC/heat pump, RoomMind intelligently routes heating demand to the most efficient device based on temperature gap and outdoor conditions.`,"heat_source.primary_delta":`Boiler activation threshold`,"heat_source.primary_delta_hint":`Only activate the primary source when the temperature gap exceeds this value. Below this threshold, only the fast secondary source is used.`,"heat_source.primary_delta_suffix":`°C`,"heat_source.outdoor_threshold":`Outdoor preference switchover`,"heat_source.outdoor_threshold_hint":`Above this outdoor temperature, prefer the AC/heat pump (higher efficiency). Below, prefer the gas boiler/radiator.`,"heat_source.outdoor_threshold_suffix":`°C`,"heat_source.ac_min_outdoor":`Min. outdoor temp for AC heating`,"heat_source.ac_min_outdoor_hint":`Disable AC heating entirely below this temperature to protect the heat pump hardware.`,"heat_source.ac_min_outdoor_suffix":`°C`,"heat_source.summary_disabled":`Smart source selection is off`,"common.remove":`Remove`,"common.yes":`Yes`,"common.no":`No`,"room.section.comfort":`Comfort & night`,"hero.perceived_temp":`Feels like {value}{unit}`,"hero.night_mode_active":`Night mode active`,"hero.rapid_recovery_active":`Rapid recovery active`,"airflow.hvac_output":`HVAC output`,"airflow.night_capped":`Night cap`,"airflow.skipped":`skipped`,"airflow.confidence_observed":`Observed`,"airflow.confidence_assumed":`Assumed`,"airflow.confidence_stale":`Stale`,"airflow.confidence_conflicting":`Conflict`,"airflow.confidence_unknown":`Unknown`,"airflow.preset_mode_thermal":`Thermal preset`,"airflow.preset_mode_idle":`Idle preset`,"airflow.preset_mode_night":`Night preset`,"airflow.power_sensor":`Power sensor`,"airflow.compressor_stage_observer":`Compressor observer`,"airflow.observer_auto":`Auto`,"airflow.observer_power":`Power sensor`,"airflow.observer_slope":`Thermal slope`,"airflow.observer_disabled":`Disabled`,"airflow.assumed_state_ttl":`Assumed state TTL (s)`,"airflow.fan_capacity_curve":`Fan capacity curve`,"airflow.fan_power_curve":`Fan power curve`,"comfort.perceived_temp":`Feels like`,"comfort.control_target":`Control target`,"comfort.control_target_air":`Air temperature`,"comfort.control_target_perceived":`Feels-like temperature`,"comfort.night_mode":`Night mode`,"comfort.active":`Active`,"comfort.inactive":`Inactive`,"comfort.rapid_recovery":`Rapid recovery`,"comfort.night_controls":`Night controls`,"comfort.room_coupling":`Room coupling`,"comfort.summary":`Quiet hours {hours}; night fan cap {fan}; sleep setpoint ramp {ramp}°C.`,"comfort.live_coupling":`Live room coupling`,"comfort.gate":`Gate`,"comfort.adjacent_temp":`Adjacent temperature {temp}°C`,"comfort.night_mode_hint":`Dims lights, displays and beepers during quiet hours and applies sleep comfort rules.`,"comfort.quiet_start":`Quiet start`,"comfort.quiet_end":`Quiet end`,"comfort.max_fan_level_night":`Night max fan level`,"comfort.sleep_temp_ramp":`Sleep setpoint ramp (°C)`,"comfort.room_volume":`Room volume (m³)`,"comfort.rapid_recovery_delta":`Rapid recovery threshold (°C)`,"comfort.night_allow_rapid_recovery":`Allow rapid recovery at night`,"comfort.night_allow_rapid_recovery_hint":`Temporarily overrides quiet fan caps when the room is far from target.`,"comfort.no_night_controls":`No light, display or sound controls configured yet.`,"comfort.add_night_control":`Add night control`,"comfort.night_control_new":`New night control`,"comfort.night_control_entity":`Light, switch, select or number entity`,"comfort.night_control_role":`Role`,"comfort.role_indicator_light":`Indicator light`,"comfort.role_display":`Display`,"comfort.role_beeper":`Beeper`,"comfort.role_sound":`Sound`,"comfort.role_other":`Other`,"comfort.restore_after_night":`Restore after night`,"comfort.night_value":`Night value`,"comfort.day_value":`Day value`,"comfort.adjacent_rooms":`Adjacent rooms`,"comfort.no_adjacent_rooms":`No adjacent rooms configured yet.`,"comfort.add_adjacent_room":`Add adjacent room`,"comfort.adjacent_new":`New adjacent room`,"comfort.adjacent_room":`Adjacent room`,"comfort.select_room":`Select room`,"comfort.door_sensor":`Door/window/channel sensor`,"comfort.coupling_weight":`Coupling weight k`,"comfort.allow_borrowed_conditioning":`Allow borrowed heating/cooling`,"comfort.allow_borrowed_conditioning_hint":`Let this room use thermal influence from connected rooms when the gate is open.`,"comfort.info_title":`Comfort model`,"comfort.info_body":`RoomMind can control either measured air temperature or estimated feels-like temperature, which accounts for fan airflow and humidity.`,"comfort.info_night_title":`Night mode`,"comfort.info_night_body":`During quiet hours RoomMind can cap fans, select sleep presets and turn off device LEDs, displays and beepers, then restore them in the morning.`,"comfort.info_coupling_title":`Room coupling`,"comfort.info_coupling_body":`Adjacent rooms and door sensors let the model estimate borrowed cooling or heating instead of treating every room as isolated.`},yt={"panel.title":`RoomMind`,"panel.subtitle":`Klimasteuerung`,"panel.tab.rooms":`Räume`,"panel.tab.settings":`Einstellungen`,"panel.edit":`Raum bearbeiten`,"panel.loading":`Laden...`,"panel.no_areas":`Keine Bereiche in Home Assistant konfiguriert.`,"panel.no_areas_hint":`Bereiche in den HA-Einstellungen anlegen.`,"badge.beta":`Beta`,"badge.beta_hint":`Dieses Feature ist in der Beta-Phase und kann sich in zukünftigen Updates noch ändern.`,"common.learn_more":`Mehr erfahren`,"panel.stat.rooms":`Räume`,"panel.stat.heating":`Heizen`,"panel.stat.cooling":`Kühlen`,"panel.stat.vacation":`Urlaub`,"panel.stat.away":`Abwesend`,"panel.stat.mold":`Schimmel`,"panel.hide_room":`Ausblenden`,"panel.unhide":`Einblenden`,"panel.hidden_rooms":`Ausgeblendete Räume`,"panel.floor_other":`Sonstige`,"panel.reorder":`Räume sortieren`,"panel.reorder_done":`Fertig`,"room.back":`Zurück zu den Räumen`,"room.section.climate_mode":`Klimamodus`,"room.section.schedule":`Zeitplan & Temperaturen`,"room.section.control_mode":`Steuerungsmodus`,"room.section.devices":`Geräte`,"room.section.sensors":`Sensoren`,"room.section.airflow":`Luftstrom`,"room.section.windows":`Fenstersensoren`,"room.control_mode.full_control":`Full Control`,"room.control_mode.managed":`Managed`,"room.control_mode.external_sensor":`Externer Sensor: {sensor}`,"room.control_mode.no_sensor":`Kein externer Temperatursensor zugewiesen`,"room.control_mode.mpc_active":`MPC aktiv`,"room.control_mode.mpc_learning":`Lernphase`,"room.control_mode.device_setpoint":`Geräte-Setpoint: {temp}`,"room.control_mode.power":`Leistung: {power}%`,"room.control_mode.full_control_info":`RoomMind hat volle Kontrolle über deine Klimageräte. Ein externer Temperatursensor liefert die tatsächliche Raumtemperatur, was eine proportionale Setpoint-Berechnung ermöglicht. Der Geräte-Setpoint wird dynamisch basierend auf der MPC-Leistung angepasst. Das thermische Modell (EKF) lernt das Verhalten deines Raums für optimalen Komfort und Energieeffizienz.`,"room.control_mode.managed_info":`RoomMind setzt die Zieltemperatur auf deinem Gerät (aus Zeitplan, Override oder Urlaubsmodus), aber das Gerät regelt selbstständig mit seinem internen Sensor. Kein proportionaler Boost, kein thermisches Modell-Lernen und keine MPC-Optimierung. Für präzisere Steuerung einen externen Temperatursensor in der Geräte-Sektion zuweisen.`,"room.delete":`Raum löschen`,"room.deleting":`Wird gelöscht...`,"room.saving":`Speichern...`,"room.saved":`Gespeichert`,"room.error_saving":`Fehler beim Speichern`,"room.confirm_delete":`RoomMind-Konfiguration für "{name}" entfernen?`,"room.error_save_fallback":`Konfiguration konnte nicht gespeichert werden`,"room.error_delete_fallback":`Konfiguration konnte nicht gelöscht werden`,"room.climate_control_toggle":`Klimasteuerung`,"room.climate_control_hint":`Wenn deaktiviert, steuert RoomMind keine Geräte in diesem Raum`,"room.outdoor_toggle":`Außenbereich`,"room.outdoor_hint":`Deaktiviert Klimasteuerung, Schimmelerkennung und Modell-Training. Sensorüberwachung läuft weiter.`,"room.alias.placeholder":`Eigener Anzeigename`,"room.alias.clear":`Auf Bereichsname zurücksetzen`,"override.label":`Temporärer Override`,"override.comfort":`Komfort`,"override.eco":`Eco`,"override.custom":`Individuell`,"override.target":`Ziel:`,"override.activate_for":`Aktivieren für:`,"override.error_set":`Override konnte nicht gesetzt werden`,"override.error_clear":`Override konnte nicht aufgehoben werden`,"hero.target":`Ziel`,"hero.override":`Override`,"hero.remaining":`noch {time}`,"hero.humidity":`{value}% Luftfeuchtigkeit`,"hero.device_setpoint":`Gerät auf {value}{unit}`,"hero.heat_source_primary":`Heizung: TRV`,"hero.heat_source_secondary":`Heizung: AC`,"hero.heat_source_both":`Heizung: TRV + AC`,"hero.permanent":`Dauerhaft`,"hero.waiting":`Warte auf Sensordaten...`,"hero.not_configured":`Noch nicht konfiguriert`,"hero.mpc_learning_paused":`MPC-Lernen pausiert`,"hero.mpc_learning_paused.outdoor_unavailable":`RoomMind benötigt eine Außentemperatur, um das thermische Modell dieses Raums zu lernen. Der konfigurierte Außensensor ist nicht verfügbar und es ist keine Wetter-Entity als Fallback gesetzt. Konfiguriere eine der beiden in den Einstellungen.`,"card.target":`Ziel`,"card.waiting":`Warte auf Daten...`,"card.humidity":`{value}% Luftfeuchtigkeit`,"card.thermostat":`Thermostat`,"card.thermostats":`Thermostate`,"card.ac":`Klimaanlage`,"card.acs":`Klimaanlagen`,"card.climate_device":`Klimagerät`,"card.climate_devices":`Klimageräte`,"card.temp_sensor":`Temperatursensor`,"card.temp_sensors":`Temperatursensoren`,"card.no_climate":`Keine Klimageräte`,"card.outdoor":`Außen`,"card.tap_configure":`Tippen zum Konfigurieren`,"card.mpc_active":`MPC aktiv`,"card.mpc_learning":`MPC lernt`,"card.not_controlled":`Nicht von RoomMind gesteuert`,"mode.auto":`Automatisch`,"mode.auto_desc":`Heizt und kühlt automatisch basierend auf der Zieltemperatur`,"mode.heat_only":`Nur Heizen`,"mode.heat_only_desc":`Nutzt nur Thermostate, Klimaanlagen bleiben aus`,"mode.cool_only":`Nur Kühlen`,"mode.cool_only_desc":`Nutzt nur Klimaanlagen, Thermostate bleiben aus`,"mode.heating":`Heizen`,"mode.cooling":`Kühlen`,"mode.fan_only":`Nur Ventilator`,"mode.idle":`Standby`,"schedule.add_schedule":`Zeitplan hinzufügen`,"schedule.select_schedule":`Zeitplan-Helfer auswählen`,"schedule.create_helper_hint":`Neuen Zeitplan-Helfer in HA erstellen`,"schedule.selector_label":`Zeitplan-Auswahl`,"schedule.selector_value_boolean":`Aktuell: {value}`,"schedule.selector_value_number":`Aktueller Wert: {value}`,"schedule.selector_warning":`Mehrere Zeitpläne, aber keine Auswahl-Entity gesetzt. Nur der erste wird verwendet.`,"schedule.off_action_label":`Aktion wenn Zeitplan aus`,"schedule.off_action_eco":`Eco-Temperatur verwenden`,"schedule.off_action_off":`Geräte ausschalten`,"schedule.state_active":`Aktiv`,"schedule.state_inactive":`Inaktiv`,"schedule.state_unreachable":`Nicht erreichbar`,"schedule.no_schedules":`Keine Zeitpläne konfiguriert`,"schedule.done":`Fertig`,"schedule.view_comfort":`Komfort: {temp}{unit}`,"schedule.view_eco":`Eco: {temp}{unit}`,"schedule.view_selector":`Aktiver Zeitplan gewählt durch: {name}`,"schedule.view_selector_prefix":`Aktiver Zeitplan gewählt durch:`,"schedule.help_header":`Wie funktionieren Zeitpläne?`,"schedule.help_temps_title":`Wie wird die Zieltemperatur bestimmt?`,"schedule.help_temps":`Die Zieltemperatur folgt dieser Prioritätskette:`,"schedule.help_temps_1":`<strong>Manueller Override</strong> – Ein temporärer Komfort-/Eco-/Individueller Override hat immer die höchste Priorität.`,"schedule.help_temps_2":`<strong>Block-Temperatur</strong> – Wenn der aktive Zeitblock einen <code>temperature</code>-Wert in seinen Daten hat, wird dieser verwendet.`,"schedule.help_temps_3":`<strong>Komforttemperatur</strong> – Wenn der Zeitplan "an" ist, aber der Block keine Temperatur hat, wird die Komfort-Fallback-Temperatur verwendet.`,"schedule.help_temps_4":`<strong>Eco-Temperatur</strong> – Wenn der Zeitplan "aus" ist (außerhalb aller Zeitblöcke), wird die Eco-Temperatur verwendet.`,"schedule.help_block_title":`Temperatur pro Zeitblock setzen`,"schedule.help_block":`Du kannst für jeden Zeitblock eine eigene Temperatur setzen, indem du einen <code>temperature</code>-Wert in der YAML-Konfiguration des Zeitplans angibst:`,"schedule.help_block_note":`Wenn ein Block keinen <code>temperature</code>-Wert hat, wird stattdessen die Komfort-Fallback-Temperatur verwendet.`,"schedule.help_split_title":`Getrennte Heiz-/Kühlziele pro Block`,"schedule.help_split":`Für Räume im Auto-Modus kannst du pro Zeitblock separate Heiz- und Kühlziele mit <code>heat_temperature</code> und <code>cool_temperature</code> setzen:`,"schedule.help_split_note":`Wenn nur eines gesetzt ist, wird das andere auf die Komforttemperatur des Raumes zurückgesetzt. Diese Schlüssel haben Vorrang vor <code>temperature</code>.`,"schedule.help_multi_title":`Mehrere Zeitpläne`,"schedule.help_multi":`Du kannst mehrere Zeitpläne hinzufügen und mit einer <strong>Auswahl-Entity</strong> zwischen ihnen wechseln. Das kann ein <code>input_boolean</code> (wechselt zwischen Zeitplan 1 und 2) oder ein <code>input_number</code> (wählt nach Nummer) sein. Ohne Auswahl-Entity wird nur der erste Zeitplan verwendet.`,"schedule.column_comfort":`Komfort`,"schedule.column_eco":`Eco`,"schedule.row_heat":`Heizen`,"schedule.row_cool":`Kühlen`,"schedule.view_heat":`Heizen: {comfort} / {eco}{unit}`,"schedule.view_cool":`Kühlen: {comfort} / {eco}{unit}`,"schedule.comfort_hint_auto":`Komfort: Ziel wenn Zeitplan an. Eco: Ziel wenn Zeitplan aus. Zeilen: Ziel für Heizen bzw. Kühlen.`,"schedule.comfort_label":`Komfort-Fallback-Temperatur`,"schedule.eco_label":`Eco-Temperatur`,"schedule.comfort_hint":`Wird verwendet wenn der Zeitplan "an" ist, aber keine Temperatur im Block gesetzt ist`,"schedule.from_schedule":`{temp}{unit} vom Zeitplan`,"schedule.from_schedule_split":`{heat}{unit} / {cool}{unit} vom Zeitplan`,"schedule.fallback":`{temp}{unit} (Fallback)`,"schedule.eco_detail":`{temp}{unit} (Eco)`,"devices.climate_entities":`Klimageräte`,"devices.temp_sensors":`Temperatursensoren`,"devices.primary_sensor":`Primär`,"devices.humidity_sensors":`Feuchtigkeitssensoren`,"devices.no_climate":`Keine Klimageräte in diesem Bereich gefunden.`,"devices.no_temp_sensors":`Keine Temperatursensoren in diesem Bereich gefunden.`,"devices.no_humidity_sensors":`Keine Feuchtigkeitssensoren in diesem Bereich gefunden.`,"devices.occupancy_sensors":`Anwesenheitssensoren`,"devices.no_occupancy_sensors":`Keine Anwesenheitssensoren in diesem Bereich gefunden`,"devices.occupancy_sensor_hint":`Verbessert die Genauigkeit des Wärmemodells durch Erkennung der Raumbelegung`,"devices.window_sensors":`Fenster- / Türsensoren`,"devices.no_window_sensors":`Keine Fenster-/Türsensoren in diesem Bereich gefunden.`,"devices.window_open_delay":`Verzögerung vor Pause`,"devices.window_close_delay":`Verzögerung vor Wiederaufnahme`,"devices.add_entity":`Entität hinzufügen`,"devices.done":`Fertig`,"devices.other_area":`Anderer Bereich`,"devices.type_thermostat":`Thermostat`,"devices.type_ac":`Klimagerät`,"devices.type_label":`Typ`,"devices.select_to_configure":`Gerät zum Konfigurieren auswählen`,"devices.heating_system_type":`Heizungstyp`,"devices.heating_system_type_info":`Nach dem Abschalten geben Heizkörper und besonders Fußbodenheizungen gespeicherte Wärme weiter ab. RoomMind berücksichtigt diese Nachlaufwärme, um Überschwingen zu vermeiden und die Modellgenauigkeit zu verbessern. Fußbodenheizungen erhalten außerdem längere Mindestlaufzeiten.`,"devices.system_type_none":`Standard (kein Nachlauf)`,"devices.system_type_radiator":`Heizkörper`,"devices.system_type_underfloor":`Fußbodenheizung`,"devices.underfloor_delay_hint":`Fußbodenheizung hat lange Anlaufzeiten. Eine Fenster-Verzögerung von mindestens 5 Minuten wird empfohlen, um unnötige Abschaltungen zu vermeiden.`,"devices.heating_system_type_boost_hint":`Tipp: Wenn sich die Heizungsart geändert hat, kannst du unter Einstellungen das Lernen beschleunigen.`,"devices.idle_action":`Im Leerlauf`,"devices.idle_action_off":`Ausschalten`,"devices.idle_action_fan_only":`Nur Ventilator`,"devices.idle_action_setback":`Absenkung`,"devices.idle_action_low":`Niedriger Sollwert (wach halten)`,"devices.idle_action_low_hint":`Senkt den Sollwert auf das Geräteminimum ab, statt auszuschalten. Verhindert, dass TRVs, die im Aus-Modus in Tiefschlaf gehen, spätere Befehle verlieren.`,"devices.idle_fan_mode":`Lüftergeschwindigkeit`,"devices.idle_fan_mode_keep":`Nicht ändern`,"devices.setpoint_mode":`Sollwert-Modus`,"devices.setpoint_mode_proportional":`Proportional (Ventilsteuerung)`,"devices.setpoint_mode_direct":`Direkt (Gerät regelt selbst)`,"devices.setpoint_mode_hint":`Direkt sendet die tatsächliche Raum-Zieltemperatur ans Gerät — geeignet für Thermostate und Heizlüfter mit eigener Regelung. Proportional sendet einen erhöhten Sollwert Richtung Geräte-max_temp — geeignet für Heizkörperventile (TRVs).`,"devices.valve_protection_excluded":`Vom Ventilschutz ausgenommen`,"devices.valve_protection_exclude_hint":`Dieses Gerät wird nicht vom Ventilschutz bewegt (z.B. virtuelle Kessel-Entitäten)`,"devices.info.types_title":`Gerätetypen`,"devices.info.types_body":`Thermostat bedeutet Heizkörperthermostat / TRV. Klimagerät bedeutet AC, Wärmepumpe oder eine andere Klima-Entität für Kühlung oder Warmluftheizung. Beides sind Home-Assistant-Klima-Entitäten; der Unterschied liegt darin, wie RoomMind sie ansteuert.`,"devices.info.control_title":`Wie RoomMind sie steuert`,"devices.info.control_body":`Der Sollwert-Modus gilt nur für Thermostate in Räumen mit Full Control und externem Temperatursensor. Verwende Proportional, wenn RoomMind die Heizleistung über angehobene Sollwerte steuern soll. Verwende Direkt, wenn das Gerät selbst um den echten Zielwert regeln soll.`,"devices.info.modes_title":`Verhalten im Leerlauf`,"devices.info.modes_body":`Im Leerlauf gilt nur für Klimageräte. Ausschalten schaltet das Gerät aus. Nur Ventilator hält die Luftzirkulation ohne Heizen oder Kühlen aufrecht. Absenkung lässt den aktuellen Modus aktiv, verschiebt den Sollwert aber um 2°C vom Raumziel weg. Dieser Offset ist derzeit fest. Für Thermostate hält Niedrig den TRV aktiv auf minimalem Sollwert statt ihn auszuschalten, nützlich für batteriebetriebene Zigbee-TRVs, die beim Ausschalten in den Tiefschlaf gehen.`,"devices.info.heat_source_title":`Intelligente Quellenwahl`,"devices.info.heat_source_body":`Diese Funktion erscheint nur, wenn ein Raum sowohl ein Thermostat/TRV als auch ein Klimagerät und zusätzlich einen externen Temperatursensor hat. RoomMind kann dann je nach Temperaturdifferenz und Außenbedingungen auswählen, welche Quelle das Heizen übernimmt.`,"airflow.devices":`Luftstrom-Geräte`,"airflow.no_devices":`Keine Luftstrom-Geräte konfiguriert.`,"airflow.no_candidates":`Keine Ventilator- oder luftstromfähigen Klima-Entitäten in diesem Bereich gefunden.`,"airflow.add_entity":`Luftstrom-Entität hinzufügen`,"airflow.role":`Rolle`,"airflow.role_circulation":`Umluft`,"airflow.role_ventilation":`Abluft / Frischluft`,"airflow.role_hvac_fan":`HVAC-Gebläse`,"airflow.controllable":`Steuerbar`,"airflow.controllable_hint":`RoomMind darf dieses Gerät beim Aufbau der Luftstrom-Stufen berücksichtigen.`,"airflow.control_enabled":`Steuerung erlauben`,"airflow.control_enabled_hint":`Wenn aktiv, kann MPC Lüfterstufe, Nur-Ventilator-Modus oder Schwenkoptionen setzen.`,"airflow.controllable_short":`Steuerbar`,"airflow.control_enabled_short":`Auto`,"airflow.direction":`Richtung`,"airflow.direction_forward":`Vorwärts`,"airflow.direction_reverse":`Rückwärts`,"airflow.preset_mode":`Preset-Modus`,"airflow.oscillating":`Oszillation`,"airflow.swing_mode":`Schwenkmodus`,"airflow.swing_horizontal_mode":`Horizontaler Schwenk`,"airflow.keep":`Aktuell behalten`,"airflow.on":`Ein`,"airflow.off":`Aus`,"airflow.plan_level":`MPC-Stufe`,"airflow.mix_plan_level":`Mischplan`,"airflow.vent_plan_level":`Lüftungsplan`,"airflow.mix_factor":`Mischfaktor`,"airflow.vent_factor":`Lüftungsfaktor`,"airflow.ach":`Luftwechsel`,"airflow.planned_level":`Geplant`,"airflow.actual_level":`Ist`,"airflow.command_applied":`Gesetzt`,"airflow.command_unsupported_fan_only":`Kein Nur-Ventilator`,"airflow.command_skipped_off_climate":`Klima aus`,"airflow.command_blocked_by_mode":`Übersprungen`,"airflow.command_failed":`Fehler`,"airflow.command_control_disabled":`Steuerung aus`,"airflow.unavailable":`Nicht verfügbar`,"airflow.info_title":`Beobachtete Luftstrom-Faktoren`,"airflow.info_body":`Umluft- und HVAC-Gebläse werden als Mischfaktoren behandelt, die Sensorabweichungen reduzieren können. Abluft- oder Frischluftgeräte gelten als Luftaustausch mit außen und beeinflussen die thermische Vorhersage.`,"airflow.info_control_title":`Steuerverhalten`,"airflow.info_control_body":`RoomMind sendet Luftstrom-Befehle an Fan- oder Klima-Entitäten nur, wenn für das Gerät sowohl Steuerbar als auch Steuerung erlauben aktiv ist. HVAC-Gebläse dürfen im Leerlauf nur starten, wenn die Klima-Entität Nur-Ventilator unterstützt; Heiz- und Kühl-Sollwerte bleiben im Gerätebereich.`,"hero.window_open":`Fenster offen – pausiert`,"card.window_open":`Fenster offen`,"room.section.covers":`Rollos & Jalousien`,"covers.section_title":`Rollos & Jalousien`,"covers.auto_control":`Automatische Rollosteuerung`,"covers.auto_control_hint":`RoomMind schließt Rollos, wenn Solarwärme den Raum voraussichtlich überhitzen würde.`,"covers.deploy_threshold":`Auslöseschwelle`,"covers.deploy_threshold_hint":`Rollos schließen, wenn die vorhergesagte Temperatur den Zielwert um diesen Betrag übersteigt.`,"covers.min_position":`Minimale Öffnungsposition`,"covers.min_position_hint":`Rollos werden nie weiter als diese Position geschlossen (0 = vollständig schließen erlaubt).`,"covers.override_minutes":`Override-Pausendauer`,"covers.override_minutes_hint":`Wie lange die automatische Steuerung nach manueller Rolloverstellung pausiert. 0 = keine Pause.`,"covers.no_covers":`Keine Rollo-Entitäten konfiguriert.`,"covers.no_covers_in_area":`Keine Rollo-Entitäten in diesem Bereich gefunden.`,"covers.add_cover":`Rollo-Entität hinzufügen...`,"covers.shading_active":`Beschattung aktiv`,"covers.auto_paused":`Automatik pausiert (manuell übersteuert)`,"covers.done":`Fertig`,"covers.night_close":`Nachts automatisch schließen`,"covers.night_close_hint":`Rolläden bei Sonnenuntergang schließen und bei Sonnenaufgang öffnen.`,"covers.night_close_active":`Nachtschließung aktiv`,"covers.schedule_group_title":`Zeitplan`,"covers.solar_group_title":`Solar-Steuerung`,"covers.schedule_section":`Rolläden-Zeitpläne`,"covers.schedule_section_hint":`Definiere Zeitfenster für die Rolladensteuerung. Im Modus 'Position erzwingen' überschreibt der Zeitplan die Solar-/Thermik-Logik. Im Modus 'Sonnenschutz erlauben' entscheidet RoomMind innerhalb des aktiven Zeitfensters selbst über die Position.`,"covers.add_schedule":`Zeitplan hinzufügen...`,"covers.schedule_mode_force":`Position erzwingen`,"covers.schedule_mode_gate":`Sonnenschutz erlauben`,"covers.schedule_mode_gate_short":`Solarschutz-Gate`,"covers.schedule_position":`Position`,"covers.schedule_position_hint":`Rolloposition wenn dieser Zeitplan aktiv ist (0% = vollständig geschlossen, 100% = vollständig offen).`,"covers.schedule_selector":`Zeitplan-Selektor`,"covers.schedule_selector_hint":`Bestimmt welcher Zeitplan aktiv ist. input_boolean: aus=#1, an=#2. input_number: Wert wählt Zeitplan-Nummer.`,"covers.schedule_selector_warning":`Mehrere Zeitpläne konfiguriert aber kein Selektor gesetzt. Nur der erste Zeitplan wird verwendet.`,"covers.schedule_state_active":`Aktiv`,"covers.schedule_state_inactive":`Inaktiv`,"covers.schedule_state_unreachable":`Nicht erreichbar`,"covers.schedule_active":`Zeitplan aktiv`,"covers.schedule_create_link":`Zeitplan-Helfer erstellen`,"covers.night_position":`Nachtposition`,"covers.night_position_hint":`Rolloposition wenn Nachtschließung aktiv ist (0% = vollständig geschlossen). Bei Rollos mit individueller Min. Position wird diese nie unterschritten.`,"covers.night_close_advanced":`Erweitert`,"covers.night_close_elevation":`Sonnenstand-Schwellwert`,"covers.night_close_elevation_hint":`Wie weit die Sonne unter oder über dem Horizont stehen muss. 0° = genau bei Sonnenuntergang/-aufgang. Negativ = dunkler (z.B. -6° = Dämmerung, wenn es merklich dunkel wird). Positiv = noch hell (z.B. 5° = Sonne noch sichtbar).`,"covers.night_close_offset":`Zeitversatz`,"covers.night_close_offset_hint":`Zusätzliche Verschiebung relativ zum Sonnenstand-Schwellwert. Positiv = später schließen (z.B. +20 = 20 Min. nach Erreichen des Schwellwerts), negativ = früher.`,"covers.outdoor_min_temp":`Min. Außentemperatur`,"covers.outdoor_min_temp_hint":`Rollos bei dieser Außentemperatur nicht für Sonnenschutz schließen. Bei Kälte ist der Solareintrag erwünscht.`,"covers.per_cover_title":`Pro-Rollo Einstellungen`,"covers.per_cover_hint":`Himmelsrichtung pro Rollo und optionale individuelle Mindestposition.`,"covers.per_cover_min_short":`Min`,"covers.per_cover_min_position":`Min. Position`,"covers.per_cover_min_position_hint":`Individuelle Mindestposition pro Rollo. Rollos werden nicht weiter geschlossen. Nützlich wenn Rollos physisch schon bei > 0% ganz zu sind.`,"covers.snap_deploy":`Direkt auf Minimalposition`,"covers.snap_deploy_hint":`Rolläden direkt auf die Minimalposition schließen statt schrittweise. Empfohlen für Dreifachverglasung, bei der Zwischenpositionen thermische Spannungen verursachen können.`,"covers.info.selection_title":`Rollo-Auswahl`,"covers.info.selection_body":`Wähle Rollos/Jalousien aus diesem Bereich oder füge Entitäten aus anderen Bereichen hinzu. RoomMind verfolgt deren Position und kann sie automatisch steuern.`,"covers.info.schedule_title":`Zeitplan-Steuerung`,"covers.info.schedule_body":`Verwende HA-Zeitplan-Helfer um festzulegen, wann Rollos schließen sollen (z.B. Sichtschutz am Abend). Das Positions-Attribut des Zeitplans bestimmt, wie weit sie schließen. Zeitpläne überschreiben alle andere Automatik-Logik.`,"covers.info.solar_title":`Solar-/Thermik-Steuerung`,"covers.info.solar_body":`Bei aktivierter Automatik sagt RoomMind vorher, ob Sonneneinstrahlung den Raum überhitzen wird und schließt Rollos präventiv. Es nutzt gelernte Thermodaten wenn verfügbar, sonst einen konservativen Standardwert. Die Auslöseschwelle bestimmt, wie viel vorhergesagte Überschreitung nötig ist.`,"covers.info.night_title":`Nachtschließung`,"covers.info.night_body":`Schließt Rollos bei Sonnenuntergang und öffnet sie bei Sonnenaufgang. Du kannst eine eigene Nachtposition setzen (z.B. 10% = fast geschlossen aber nicht komplett).`,"covers.info.override_title":`Manuelles Übersteuern`,"covers.info.override_body":`Wenn du ein Rollo manuell bewegst, erkennt RoomMind dies und pausiert die Automatik für die konfigurierte Dauer. So wird nicht gegen den Nutzer gearbeitet.`,"covers.info.priority_title":`Prioritätsreihenfolge`,"covers.info.priority_body":`Manuelles Override > Zeitplan > Nachtschließung > Solar-/Thermik-Steuerung. Höhere Priorität gewinnt immer. Wenn keine Regel greift, bleiben Rollos offen.`,"covers.info.entities_title":`HA-Entitäten`,"covers.info.entities_body":`RoomMind erstellt zwei Entitäten pro Raum zur externen Nutzung: switch.roommind_{bereich}_cover_auto (automatische Rollosteuerung ein-/ausschalten — nutzbar in Automatisierungen oder Dashboards) und binary_sensor.roommind_{bereich}_cover_paused (an wenn manuelles Override aktiv ist, z.B. nach manuellem Bewegen eines Rollos).`,"covers.orientation_group_title":`Rolloausrichtung`,"covers.orientation_hint":`Himmelsrichtung, in die das Rollo zeigt. RoomMind nutzt dies, um Sonnenschutz zu überspringen, wenn die Sonne nicht auf diese Gebäudeseite scheint.`,"covers.orientation_none":`Beliebige Richtung`,"covers.orientation_N":`N`,"covers.orientation_NE":`NO`,"covers.orientation_E":`O`,"covers.orientation_SE":`SO`,"covers.orientation_S":`S`,"covers.orientation_SW":`SW`,"covers.orientation_W":`W`,"covers.orientation_NW":`NW`,"covers.orientation_N_full":`Nord`,"covers.orientation_NE_full":`Nordost`,"covers.orientation_E_full":`Ost`,"covers.orientation_SE_full":`Südost`,"covers.orientation_S_full":`Süd`,"covers.orientation_SW_full":`Südwest`,"covers.orientation_W_full":`West`,"covers.orientation_NW_full":`Nordwest`,"settings.general_title":`Allgemein`,"settings.group_by_floor":`Räume nach Etagen gruppieren`,"settings.climate_control_active":`Klimasteuerung aktiv`,"settings.climate_control_hint":`Wenn deaktiviert, überwacht RoomMind weiterhin alle Sensoren und trainiert das Modell, steuert aber keine Heizungen oder Klimaanlagen mehr an.`,"settings.learning_title":`Modell-Training`,"settings.learning_hint":`Wenn pausiert, sammelt RoomMind keine neuen Messdaten und trainiert das thermische Modell nicht weiter. Bestehende Modelldaten bleiben erhalten.`,"settings.learning_exceptions":`Ausnahmen`,"settings.learning_room_paused":`Raum pausiert`,"settings.learning_rooms_paused":`Räume pausiert`,"settings.sensors_title":`Sensoren & Datenquellen`,"settings.control_title":`Steuerung`,"settings.outdoor_sensor":`Außentemperatur`,"settings.outdoor_sensor_label":`Außentemperatursensor`,"settings.outdoor_current":`Aktuell {temp}{unit} draußen`,"settings.outdoor_waiting":`Warte auf Sensordaten...`,"settings.outdoor_humidity_sensor":`Außenluftfeuchtigkeit`,"settings.outdoor_humidity_label":`Außenluftfeuchtigkeitssensor`,"settings.outdoor_humidity_current":`Aktuell {value}% draußen`,"settings.smart_control":`Intelligente Klimasteuerung`,"settings.smart_control_hint":`Außentemperaturgrenzen für Heiz- und Kühlentscheidungen konfigurieren.`,"settings.outdoor_cooling_min":`Mindest-Außentemperatur für Kühlung`,"settings.outdoor_cooling_min_hint":`Klimaanlage bleibt aus wenn Außentemperatur unter diesem Wert`,"settings.outdoor_heating_max":`Maximal-Außentemperatur für Heizung`,"settings.outdoor_heating_max_hint":`Heizung bleibt aus wenn Außentemperatur über diesem Wert`,"settings.saving":`Speichern...`,"settings.saved":`Gespeichert`,"settings.error":`Fehler beim Speichern`,"devices.using_builtin_sensor":`Nutzt den eingebauten Thermostat-Sensor`,"settings.climate_intelligence":`Klimaintelligenz`,"settings.control_mode":`Steuerungsmodus`,"settings.control_mode_simple":`Einfach (Ein/Aus)`,"settings.control_mode_mpc":`Intelligent (MPC)`,"settings.control_mode_hint":`MPC lernt das thermische Verhalten deiner Räume für optimale Steuerung`,"settings.comfort_weight":`Priorität`,"settings.comfort_weight_comfort":`Komfort`,"settings.comfort_weight_efficiency":`Effizienz`,"settings.comfort_weight_hint":`Gewichtet Temperaturgenauigkeit gegen Energieverbrauch. Komfort reagiert früher und bleibt näher am Zielwert. Effizienz erlaubt mehr Abweichung, um Heiz- und Kühllaufzeiten zu reduzieren.`,"settings.weather_entity":`Wettervorhersage`,"settings.weather_entity_hint":`Optional: ermöglicht vorausschauende Außentemperaturplanung und dient als Fallback wenn der Außensensor nicht verfügbar ist`,"settings.outdoor_unavailable_notify":`Hinweis bei fehlender Außentemperatur`,"settings.outdoor_unavailable_notify_hint":`Zeigt eine Home-Assistant-Benachrichtigung, wenn weder Außensensor noch Wetter-Entity 30 Minuten lang eine Temperatur geliefert haben. In dieser Zeit pausiert RoomMind das Lernen des thermischen Modells, um Korruption zu vermeiden.`,"settings.prediction_enabled":`Temperaturvorhersage`,"settings.prediction_enabled_hint":`Zeigt den vorhergesagten Temperaturverlauf im Analyse-Diagramm. Bei langsamer Performance deaktivieren.`,"vacation.title":`Urlaubsmodus`,"vacation.hint":`Setzt alle Räume auf eine Absenktemperatur bis zum Enddatum.`,"vacation.active_label":`Urlaubsmodus aktiv`,"vacation.end_date":`Enddatum & Uhrzeit`,"vacation.setback_temp":`Absenktemperatur`,"vacation.no_end_date":`Kein Enddatum`,"vacation.deactivate":`Deaktivieren`,"tabs.analytics":`Analyse`,"analytics.select_room":`Raum auswählen`,"analytics.temperature":`Temperatur`,"analytics.target":`Ziel`,"analytics.prediction":`Vorhersage`,"analytics.outdoor":`Außen`,"analytics.model_status":`Modellstatus`,"analytics.confidence":`Konfidenz`,"analytics.heating_rate":`Heizstärke`,"analytics.cooling_rate":`Kühlstärke`,"analytics.solar_gain":`Solargewinn`,"analytics.occupancy_gain":`Anwesenheitsgewinn`,"analytics.time_constant":`Zeitkonstante`,"analytics.samples":`Datenpunkte`,"analytics.prediction_accuracy":`Vorhersagegenauigkeit`,"analytics.avg_deviation":`Durchschn. Abweichung`,"analytics.data_sources":`Datenquellen`,"analytics.data_points":`Datenpunkte`,"analytics.control_mode":`Steuerungsmodus`,"analytics.control_mode_mpc":`MPC aktiv`,"analytics.control_mode_bangbang":`MPC wird trainiert`,"analytics.last_model_update":`Letztes Modell-Update`,"analytics.accuracy_idle":`Genauigkeit (Leerlauf)`,"analytics.accuracy_heating":`Genauigkeit (Heizen)`,"analytics.info.accuracy_idle":`Wie genau das Modell die Temperatur vorhersagt, wenn weder geheizt noch gekühlt wird. Ein niedrigerer Wert bedeutet, dass das Modell den natürlichen Wärmeverlust deines Raums gut versteht. Dieser Wert verbessert sich als erstes, da Leerlauf-Daten kontinuierlich gesammelt werden.`,"analytics.info.accuracy_heating":`Wie genau das Modell die Temperatur während des aktiven Heizens vorhersagt. Dieser Wert bleibt anfangs hoch, da das Modell echte Heizzyklen zum Lernen braucht. Sobald deine Heizung ein paar Mal gelaufen ist, sinkt dieser Wert und die intelligente MPC-Steuerung wird verfügbar.`,"analytics.info.confidence":`Gesamte Modellreife für die intelligente MPC-Steuerung, basierend auf zwei Faktoren: Datenmenge (wie viele Leerlauf- und Aktiv-Messwerte gesammelt wurden) und Vorhersagegenauigkeit (wie präzise die Temperaturprognosen sind). Die Konfidenz startet bei 0% und steigt mit zunehmenden Daten. Etwa 50% bedeutet: genug Leerlaufdaten, aber noch zu wenig Heiz-/Kühlzyklen. Über 80% bedeutet: genug Daten und genaue Vorhersagen — MPC-Steuerung wird verfügbar. 100% ist das theoretische Maximum, wenn die Vorhersagen so genau wie physikalisch möglich sind.`,"analytics.info.time_constant":`Wie lange es dauert, bis sich die Raumtemperatur bei ausgeschalteter Heizung halbwegs der Außentemperatur annähert. Eine längere Zeitkonstante bedeutet bessere Dämmung — der Raum hält die Wärme länger. Eine kurze Zeitkonstante bedeutet schnelles Auskühlen. Das Modell lernt diesen Wert, indem es Temperaturabfälle im Leerlauf beobachtet.`,"analytics.info.heating_rate":`Wie stark deine Heizung die Raumtemperatur beeinflusst. Ein höherer Wert bedeutet, dass dein Heizsystem den Raum schneller erwärmt relativ zur thermischen Masse. Das Modell lernt dies durch Beobachtung der Temperaturanstiege beim Heizen und nutzt es um vorherzusagen, wie lange geheizt werden muss.`,"analytics.info.cooling_rate":`Wie stark deine Klimaanlage die Raumtemperatur beeinflusst. Ein höherer Wert bedeutet schnellere Kühlung relativ zur thermischen Masse. Das Modell lernt dies durch Beobachtung der Temperaturabfälle bei aktiver Kühlung und nutzt es um vorherzusagen, wie lange gekühlt werden muss.`,"analytics.info.solar_gain":`Der geschätzte Effekt der Sonneneinstrahlung durch Fenster auf die Raumtemperatur. Wird gelernt, indem beobachtet wird, wie sich der Raum bei Sonnenschein erwärmt, wenn nicht geheizt wird. Räume mit großen Südfenstern haben höhere Werte. Das Modell nutzt dies um die Heizung zu reduzieren, wenn Solargewinn erwartet wird.`,"analytics.info.occupancy_gain":`Der geschätzte Wärmebeitrag durch Anwesenheit (Personen, Haustiere, Computer), solange der Raum belegt ist. Wird gelernt, indem Temperaturänderungen beobachtet werden, während die konfigurierten Anwesenheitssensoren aktiv sind. Durch die Trennung vom Solargewinn wird Körperwärme nicht mehr fälschlich der Sonneneinstrahlung zugeschrieben. Wird nur angezeigt, wenn für diesen Raum mindestens ein Anwesenheitssensor konfiguriert ist.`,"analytics.info.data_sources":`Anzahl der Messwerte, die für das Modelltraining verwendet werden.`,"analytics.info.data_points":`Gesamtzahl der Beobachtungen, mit denen das Modell trainiert wurde. Mehr Datenpunkte führen in der Regel zu besseren Vorhersagen. Das Modell sammelt etwa alle 3 Minuten einen neuen Datenpunkt während RoomMind läuft.`,"analytics.no_data":`Noch keine Daten — Modell lernt`,"analytics.loading":`Analyse wird geladen...`,"settings.reset_title":`Thermische Daten zurücksetzen`,"settings.reset_hint":`Gelernte thermische Modelldaten und Verlauf löschen. Das Modell beginnt von vorne zu lernen.`,"settings.reset_all_label":`Alle Räume`,"settings.reset_all_hint":`Thermische Daten und Verlauf für alle Räume auf einmal löschen.`,"settings.reset_all_btn":`Alle zurücksetzen`,"settings.reset_all_confirm":`Alle gelernten thermischen Daten und Verlauf für ALLE Räume löschen? Alle Modelle beginnen von vorne zu lernen.`,"settings.reset_room_label":`Einzelner Raum`,"settings.reset_room_hint":`Wähle einen Raum, um dessen thermische Daten und Verlauf zu löschen.`,"settings.reset_room_confirm":`Alle gelernten thermischen Daten und Verlauf für diesen Raum löschen? Das Modell beginnt von vorne zu lernen.`,"settings.reset_room_select":`Raum auswählen`,"settings.reset_btn":`Zurücksetzen`,"settings.reset_no_rooms":`Keine konfigurierten Räume.`,"settings.boost_title":`Lernen beschleunigen`,"settings.boost_hint":`Das thermische Modell lernt das Heiz- und Kühlverhalten deines Raumes über die Zeit. Nach grösseren Änderungen (neuer Heizkörper, Klimaanlage, Dämmung, Möbel) kann das Modell ungenau sein. Dies erhöht die Unsicherheit des Modells, damit es sich schneller an die neuen Bedingungen anpasst.`,"settings.boost_label":`Lernen beschleunigen`,"settings.boost_room_select":`Raum auswählen`,"settings.boost_btn":`Beschleunigen`,"settings.boost_cooldown":`Aktiv – Neues Lernen läuft`,"settings.boost_no_rooms":`Keine konfigurierten Räume.`,"analytics.range_1d":`Heute`,"analytics.range_2d":`2 Tage`,"analytics.range_7d":`Woche`,"analytics.range_30d":`Monat`,"analytics.export":`Messdaten`,"analytics.heating_period":`Heizen`,"analytics.cooling_period":`Kühlung`,"analytics.window_open_period":`Fenster offen`,"analytics.blind_position":`Rolloposition`,"analytics.chart_info_title":`So liest du dieses Diagramm`,"analytics.exported":`Exportiert!`,"analytics.copy_diagnostics":`Diagnose`,"analytics.export_download":`Datei herunterladen`,"analytics.export_clipboard":`In Zwischenablage kopieren`,"analytics.copied_to_clipboard":`Kopiert!`,"analytics.range_from":`Von`,"analytics.range_to":`Bis`,"analytics.chart_info_body":`**Linien:** Die durchgezogene orangene Linie zeigt die gemessene Raumtemperatur. Die grüne gestrichelte Linie ist die Zieltemperatur aus deinem Zeitplan. Die blaue gepunktete Linie ist die Temperaturvorhersage des Modells.

**Schattierte Bereiche:** Rote Schattierung markiert Heizperioden, blaue Kühlung und türkise Bereiche zeigen an, wenn ein Fenster offen war.

**Zukunftsprognose (rechts der 'Jetzt'-Linie):** Die grüne gestrichelte Linie zeigt die kommenden Zieltemperaturen für die nächsten 3 Stunden. Die blaue gepunktete Linie zeigt den vorhergesagten Temperaturverlauf.

**Vorhersage-Modus:** Wenn 'MPC aktiv' angezeigt wird, nutzt die Vorhersage den vollständigen MPC-Optimizer mit intelligentem Vorheizen/-kühlen. Solange das Modell noch lernt, wird eine einfachere Simulation verwendet.

**Einschränkungen:** Die Vorhersage nimmt an, dass aktuelle Bedingungen konstant bleiben (Außentemperatur, Fensterstatus). Die Genauigkeit hängt davon ab, wie gut das Modell deinen Raum bereits gelernt hat — anfangs können die Vorhersagen ungenau sein. Sobald MPC aktiviert wird, werden die Vorhersagen deutlich zuverlässiger.`,"presence.title":`Anwesenheitserkennung`,"presence.hint":`Eco-Temperatur wenn niemand zu Hause ist.`,"presence.hint_detail":`Wenn aktiviert, werden alle Räume auf Eco-Temperatur gesetzt, sobald keine der konfigurierten Personen zu Hause ist. Pro Raum kann optional eingeschränkt werden, welche Personen relevant sind.`,"presence.add_person":`Person hinzufügen`,"presence.add_entity":`Präsenz-Entity hinzufügen`,"presence.person_label":`Person`,"room.section.presence":`Anwesenheit`,"presence.room_help_header":`Wie funktioniert die Raum-Anwesenheit?`,"presence.room_help_body":`Wähle aus, welche Personen für diesen Raum relevant sind. Der Raum schaltet auf Eco-Temperatur, wenn keine der ausgewählten Personen zu Hause ist. Ohne Auswahl greift die globale Regel: Eco wenn niemand zu Hause ist.`,"presence.state_home":`Zu Hause`,"presence.state_away":`Abwesend`,"presence.room_none_assigned":`Globale Regel — Eco wenn niemand zu Hause ist`,"presence.ignore_toggle":`Anwesenheit ignorieren`,"presence.ignore_hint":`Hier wird festgelegt, wie dieser Raum auf Anwesenheit reagiert. Unten kannst du einzelne Personen zuweisen. Der Raum wechselt auf Eco, wenn keine der zugewiesenen Personen zu Hause ist. Mit dem Toggle oben wird die Erkennung komplett übersprungen und der Raum heizt immer nach Zeitplan.`,"presence.help_ignore_title":`Was bewirkt "Ignore presence"?`,"presence.help_ignore_body":`Wenn aktiviert, ignoriert dieser Raum die Anwesenheitserkennung komplett. Er folgt immer seinem Zeitplan und wechselt nie aufgrund von Anwesenheit auf Eco. Nützlich für Räume, die unabhängig von Anwesenheit ihre Temperatur halten sollen, etwa Serverräume, Tierzimmer oder Gästezimmer mit Personen, die nicht in Home Assistant getrackt werden.`,"presence.tile_ignored":`Anwesenheitserkennung ist deaktiviert. Raum folgt immer dem Zeitplan.`,"presence.away_action_label":`Aktion wenn niemand zuhause`,"presence.away_action_eco":`Eco-Temperatur verwenden`,"presence.away_action_off":`Geräte ausschalten`,"presence.clears_override_label":`Abwesenheit beendet Override`,"presence.clears_override_hint":`Sobald niemand zuhause ist, wird ein manueller Override pausiert und der Raum folgt der Abwesenheits-Aktion. Kommt jemand zurück, läuft der Override weiter, bis er abläuft.`,"card.presence_away":`Abwesend`,"valve_protection.title":`Ventilschutz`,"valve_protection.hint":`Bewegt inaktive TRV-Ventile regelmäßig kurz, um Festsitzen oder Verkalkung zu verhindern.`,"valve_protection.interval_label":`Zyklusintervall`,"valve_protection.interval_suffix":`Tage`,"valve_protection.interval_hint":`Wie lange ein Ventil inaktiv sein darf, bevor es bewegt wird (1–90 Tage)`,"compressor.title":`Kompressorschutz`,"compressor.no_groups":`Keine Kompressorgruppen konfiguriert.`,"compressor.add_group":`Kompressorgruppe hinzufügen`,"compressor.group_name":`Gruppenname`,"compressor.members":`Innengeräte`,"compressor.members_hint":`Alle Klimageräte auswählen, die von diesem Kompressor versorgt werden (Splits, TRVs an Radiatoren, Fan Coils).`,"compressor.min_run":`Mindestlaufzeit`,"compressor.min_run_hint":`Kompressor muss nach dem Start mindestens so lange laufen.`,"compressor.min_run_suffix":`Min.`,"compressor.min_off":`Mindestauszeit`,"compressor.min_off_hint":`Kompressor muss nach dem Stopp mindestens so lange aus bleiben.`,"compressor.min_off_suffix":`Min.`,"compressor.delete":`Gruppe löschen`,"compressor.delete_confirm":`Kompressorgruppe "{name}" löschen?`,"compressor.master_entity":`Hauptgerät`,"compressor.master_entity_hint":`Das zentrale Gerät das die Innengeräte dieser Gruppe versorgt, z.B. ein Gaskessel, eine Wärmepumpen-Außeneinheit oder ein Kanalklima-Hauptschalter. RoomMind schaltet es ein wenn ein Raum Heiz- oder Kühlbedarf hat und aus wenn alle Räume im Leerlauf sind. Leer lassen um nur das Aktionsskript oder den Kurzzyklusschutz zu verwenden.`,"compressor.conflict_resolution":`Konfliktlösung`,"compressor.conflict_resolution_hint":`Bestimmt was passiert wenn einige Räume heizen und andere gleichzeitig kühlen wollen. Heizpriorität: Heizen gewinnt immer (sicherste Option für Frostschutz). Kühlpriorität: Kühlen gewinnt immer. Mehrheit: Der Modus mit mehr Räumen gewinnt, bei Gleichstand wird geheizt. Außentemperatur: Entscheidet automatisch anhand des Heiz-Schwellwerts aus den Einstellungen.`,"compressor.conflict_heating_priority":`Heizpriorität (Frostschutz)`,"compressor.conflict_cooling_priority":`Kühlpriorität`,"compressor.conflict_majority":`Mehrheit gewinnt`,"compressor.conflict_outdoor_temp":`Nach Außentemperatur`,"compressor.action_script":`Aktionsskript`,"compressor.action_script_hint":`Ein Home Assistant Skript das bei jedem Wechsel des Heiz-/Kühlbedarfs ausgeführt wird. Nützlich für Systeme die spezielle Befehle benötigen, z.B. zum Aufheben eines Vaillant Quick Veto oder Schalten eines Relais. Funktioniert mit oder ohne Hauptgerät. Ohne Hauptgerät wird nur das Skript ausgelöst. Erhält Variablen: action (heat/cool/idle), master_entity, members, active_members.`,"compressor.enforce_uniform_mode":`Einheitlichen Modus erzwingen`,"compressor.enforce_uniform_mode_hint":`Alle Thermostate in dieser Gruppe müssen im gleichen HVAC-Modus arbeiten (alle heizen oder alle kühlen). Räume, die dem aufgelösten Gruppenmodus widersprechen, werden auf Leerlauf gesetzt. Für Wärmepumpen die automatisch starten, aber alle angeschlossenen Geräte im gleichen Modus benötigen.`,"mold.title":`Schimmelschutz`,"mold.detection":`Schimmelerkennung`,"mold.detection_desc":`Benachrichtigung bei Schimmelgefahr durch hohe Luftfeuchtigkeit`,"mold.threshold":`Feuchtigkeitsschwelle (%)`,"mold.threshold_hint":`Warnung wenn die Raumluftfeuchte diesen Wert dauerhaft überschreitet`,"mold.sustained":`Mindestdauer (Minuten)`,"mold.sustained_hint":`Warnung erst nach anhaltender Überschreitung`,"mold.prevention":`Schimmelprävention`,"mold.prevention_desc":`Temperatur automatisch erhöhen um Schimmelrisiko zu senken`,"mold.intensity":`Intensität`,"mold.intensity_light":`Leicht (+{delta}{unit})`,"mold.intensity_medium":`Mittel (+{delta}{unit})`,"mold.intensity_strong":`Stark (+{delta}{unit})`,"mold.intensity_hint":`Wärmere Raumluft senkt die Oberflächenfeuchte an kalten Wänden. Leicht reicht meist bei moderatem Risiko, Stark kann die Oberflächenfeuchte um bis zu 8–10 % senken — verbraucht aber deutlich mehr Energie.`,"card.mold_warning":`Schimmelrisiko`,"card.mold_critical":`Schimmelgefahr!`,"card.mold_prevention":`Schimmelschutz +{delta}{unit}`,"room.mold_surface_rh":`Geschätzte Oberflächenfeuchte: {value}%`,"settings.intro.general":`Grundlegende Anzeige- und Steuerungseinstellungen.`,"settings.intro.sensors":`Außensensoren und Wetterdaten für eine präzise Klimasteuerung konfigurieren.`,"settings.intro.control":`Wähle, wie RoomMind deine Klimageräte steuert und setze Priorität und Schwellenwerte.`,"settings.intro.presence":`Temperatur automatisch absenken wenn niemand zu Hause ist.`,"settings.intro.vacation":`Alle Räume auf eine reduzierte Temperatur setzen während du abwesend bist.`,"settings.intro.valve":`Inaktive TRV-Ventile regelmäßig bewegen um Festsitzen oder Verkalkung zu verhindern.`,"settings.intro.compressor":`Gruppen von Innengeräten verwalten die sich einen Außenkompressor oder eine zentrale Heizquelle teilen. Optional ein Hauptgerät (Kessel, Außeneinheit) zuweisen das automatisch je nach Raumbedarf ein- und ausgeschaltet wird. Kurzzyklusschutz verhindert schnelles Ein-/Ausschalten das Geräte beschädigen kann.`,"settings.intro.mold":`Luftfeuchtigkeit überwachen und Schimmelrisiko automatisch reduzieren.`,"settings.intro.notifications":`Konfiguriere wer Benachrichtigungen erhält und wie.`,"settings.intro.learning":`Thermisches Modelltraining verwalten und Lernen nach Änderungen beschleunigen.`,"settings.intro.reset":`Gelernte thermische Modelldaten löschen. Das Modell beginnt von vorne zu lernen.`,"notifications.title":`Benachrichtigungen`,"notifications.enabled":`Benachrichtigungen aktivieren`,"notifications.enabled_hint":`Wenn deaktiviert, werden keine Benachrichtigungen gesendet — weder an Geräte noch an die HA-Seitenleiste.`,"notifications.desc":`Wähle die Geräte, die Benachrichtigungen erhalten. Ohne Ziele erscheint eine Meldung in der HA-Seitenleiste.`,"notifications.add_target_label":`Benachrichtigungsgerät hinzufügen`,"notifications.add_target_hint":`Tippe die Entity-ID ein, falls dein Gerät nicht angezeigt wird (z.B. notify.mobile_app_...). Du findest sie unter Einstellungen → Geräte → dein Telefon → Notify-Entität.`,"notifications.target_unnamed":`Unbenanntes Gerät`,"notifications.target_person":`Person`,"notifications.target_when_always":`Immer`,"notifications.target_when_home":`Nur wenn zuhause`,"notifications.cooldown":`Benachrichtigungspause (Minuten)`,"notifications.cooldown_hint":`Mindestabstand zwischen wiederholten Warnungen pro Raum`,"notifications.mold_prevention_notify":`Bei Aktivierung der Prävention benachrichtigen`,"notifications.mold_prevention_notify_hint":`Auch benachrichtigen wenn die Prävention aktiviert wird (Temperaturerhöhung)`,"room.section.heat_source":`Heizquellen-Orchestrierung`,"heat_source.toggle":`Intelligente Quellenauswahl`,"heat_source.toggle_hint":`Wenn dieser Raum sowohl Heizkörper-Thermostate als auch eine AC/Wärmepumpe hat, leitet RoomMind die Heizanforderung intelligent an das effizienteste Gerät weiter, basierend auf Temperaturlücke und Außenbedingungen.`,"heat_source.primary_delta":`Boiler-Aktivierungsschwelle`,"heat_source.primary_delta_hint":`Primärquelle erst aktivieren, wenn die Temperaturlücke diesen Wert überschreitet. Darunter wird nur die schnelle Sekundärquelle genutzt.`,"heat_source.primary_delta_suffix":`°C`,"heat_source.outdoor_threshold":`Außentemperatur-Umschaltpunkt`,"heat_source.outdoor_threshold_hint":`Über dieser Außentemperatur die AC/Wärmepumpe bevorzugen (höhere Effizienz). Darunter den Gas-Boiler/Heizkörper.`,"heat_source.outdoor_threshold_suffix":`°C`,"heat_source.ac_min_outdoor":`Min. Außentemp. für AC-Heizen`,"heat_source.ac_min_outdoor_hint":`AC-Heizen unter dieser Temperatur komplett deaktivieren, um die Wärmepumpen-Hardware zu schützen.`,"heat_source.ac_min_outdoor_suffix":`°C`,"heat_source.summary_disabled":`Intelligente Quellenwahl ist aus`,"common.remove":`Entfernen`,"common.yes":`Ja`,"common.no":`Nein`,"room.section.comfort":`Komfort & Nacht`,"hero.perceived_temp":`Gefühlt {value}{unit}`,"hero.night_mode_active":`Nachtmodus aktiv`,"hero.rapid_recovery_active":`Schnelles Aufholen aktiv`,"airflow.hvac_output":`HVAC-Leistung`,"airflow.night_capped":`Nachtlimit`,"airflow.skipped":`übersprungen`,"airflow.confidence_observed":`Beobachtet`,"airflow.confidence_assumed":`Angenommen`,"airflow.confidence_stale":`Veraltet`,"airflow.confidence_conflicting":`Konflikt`,"airflow.confidence_unknown":`Unbekannt`,"airflow.preset_mode_thermal":`Thermik-Preset`,"airflow.preset_mode_idle":`Leerlauf-Preset`,"airflow.preset_mode_night":`Nacht-Preset`,"airflow.power_sensor":`Leistungssensor`,"airflow.compressor_stage_observer":`Kompressor-Beobachter`,"airflow.observer_auto":`Auto`,"airflow.observer_power":`Leistungssensor`,"airflow.observer_slope":`Temperaturtrend`,"airflow.observer_disabled":`Deaktiviert`,"airflow.assumed_state_ttl":`TTL für angenommene Zustände (s)`,"airflow.fan_capacity_curve":`Ventilator-Leistungskurve`,"airflow.fan_power_curve":`Ventilator-Stromkurve`,"comfort.perceived_temp":`Gefühlt`,"comfort.control_target":`Regelziel`,"comfort.control_target_air":`Lufttemperatur`,"comfort.control_target_perceived":`Gefühlte Temperatur`,"comfort.night_mode":`Nachtmodus`,"comfort.active":`Aktiv`,"comfort.inactive":`Inaktiv`,"comfort.rapid_recovery":`Schnelles Aufholen`,"comfort.night_controls":`Nachtsteuerung`,"comfort.room_coupling":`Raumkopplung`,"comfort.summary":`Ruhezeit {hours}; Nacht-Lüfterlimit {fan}; Schlaf-Rampe {ramp} °C.`,"comfort.live_coupling":`Live-Raumkopplung`,"comfort.gate":`Tor`,"comfort.adjacent_temp":`Nachbarraum {temp} °C`,"comfort.night_mode_hint":`Dimmt Lichter, Displays und Pieptöne während der Ruhezeit und nutzt Schlafregeln.`,"comfort.quiet_start":`Ruhebeginn`,"comfort.quiet_end":`Ruheende`,"comfort.max_fan_level_night":`Max. Lüfter nachts`,"comfort.sleep_temp_ramp":`Schlaf-Rampe (°C)`,"comfort.room_volume":`Raumvolumen (m³)`,"comfort.rapid_recovery_delta":`Schwelle schnelles Aufholen (°C)`,"comfort.night_allow_rapid_recovery":`Schnelles Aufholen nachts erlauben`,"comfort.night_allow_rapid_recovery_hint":`Übergeht leise Lüfterlimits vorübergehend, wenn der Raum weit vom Ziel entfernt ist.`,"comfort.no_night_controls":`Noch keine Licht-, Display- oder Soundsteuerung eingerichtet.`,"comfort.add_night_control":`Nachtsteuerung hinzufügen`,"comfort.night_control_new":`Neue Nachtsteuerung`,"comfort.night_control_entity":`Licht-, Schalter-, Auswahl- oder Zahlen-Entität`,"comfort.night_control_role":`Rolle`,"comfort.role_indicator_light":`Status-LED`,"comfort.role_display":`Display`,"comfort.role_beeper":`Pieper`,"comfort.role_sound":`Ton`,"comfort.role_other":`Andere`,"comfort.restore_after_night":`Nachts wiederherstellen`,"comfort.night_value":`Nachtwert`,"comfort.day_value":`Tageswert`,"comfort.adjacent_rooms":`Nachbarräume`,"comfort.no_adjacent_rooms":`Noch keine Nachbarräume konfiguriert.`,"comfort.add_adjacent_room":`Nachbarraum hinzufügen`,"comfort.adjacent_new":`Neuer Nachbarraum`,"comfort.adjacent_room":`Nachbarraum`,"comfort.select_room":`Raum auswählen`,"comfort.door_sensor":`Tür-/Fenster-/Durchgangssensor`,"comfort.coupling_weight":`Kopplungsgewicht k`,"comfort.allow_borrowed_conditioning":`Geliehene Wärme/Kälte erlauben`,"comfort.allow_borrowed_conditioning_hint":`Thermischen Einfluss verbundener Räume nutzen, wenn die Verbindung offen ist.`,"comfort.info_title":`Komfortmodell`,"comfort.info_body":`RoomMind kann Lufttemperatur oder gefühlte Temperatur regeln, inklusive Lüfterluftstrom und Feuchte.`,"comfort.info_night_title":`Nachtmodus`,"comfort.info_night_body":`In der Ruhezeit kann RoomMind Lüfter begrenzen, Schlaf-Presets wählen und LEDs, Displays sowie Pieptöne ausschalten und morgens wiederherstellen.`,"comfort.info_coupling_title":`Raumkopplung`,"comfort.info_coupling_body":`Nachbarräume und Türsensoren helfen, geliehene Kühlung oder Heizung zu schätzen, statt Räume isoliert zu betrachten.`},bt={"panel.title":`RoomMind`,"panel.subtitle":`智能温控管理`,"panel.tab.rooms":`房间`,"panel.edit":`编辑房间`,"panel.tab.settings":`设置`,"panel.loading":`正在加载...`,"panel.no_areas":`Home Assistant 中未配置区域。`,"panel.no_areas_hint":`请在 Home Assistant 设置中添加区域以开始。`,"badge.beta":`测试版`,"badge.beta_hint":`此功能处于测试阶段，在未来的更新中可能会有所更改或重构。`,"common.learn_more":`了解更多`,"panel.stat.rooms":`房间`,"panel.stat.heating":`供暖`,"panel.stat.cooling":`制冷`,"panel.stat.vacation":`度假`,"panel.stat.away":`离家`,"panel.stat.mold":`霉菌风险`,"panel.hide_room":`隐藏`,"panel.unhide":`显示`,"panel.hidden_rooms":`隐藏的房间`,"panel.floor_other":`其他`,"panel.reorder":`调整房间顺序`,"panel.reorder_done":`完成`,"room.back":`返回房间`,"room.section.climate_mode":`温控模式`,"room.section.schedule":`日程与温度`,"room.section.control_mode":`控制模式`,"room.section.devices":`设备`,"room.section.sensors":`传感器`,"room.section.airflow":`空气流动`,"room.section.windows":`窗户传感器`,"room.control_mode.full_control":`完全控制`,"room.control_mode.managed":`协同管理`,"room.control_mode.external_sensor":`外部传感器: {sensor}`,"room.control_mode.no_sensor":`未分配外部温度传感器`,"room.control_mode.mpc_active":`MPC 已启用`,"room.control_mode.mpc_learning":`学习中`,"room.control_mode.device_setpoint":`设备设定值: {temp}`,"room.control_mode.power":`功率: {power}%`,"room.control_mode.full_control_info":`RoomMind 对您的温控设备拥有完全控制权。外部温度传感器提供房间的实际温度，从而实现比例设定值计算。设备设定值根据 MPC 功率输出进行动态调整。热学模型 (EKF) 会自动学习您的房间特性，以实现最佳的舒适度与能源效率。`,"room.control_mode.managed_info":`RoomMind 在您的设备上设置目标温度（来自日程安排、临时覆盖或度假设置），但设备会使用其内部传感器进行自我调节。没有比例提升，没有热学模型 learning，也没有 MPC 优化。如需更精准的控制，请在“设备”部分分配一个外部温度传感器。`,"room.delete":`删除房间`,"room.deleting":`正在删除...`,"room.saving":`正在保存...`,"room.saved":`已保存`,"room.error_saving":`保存出错`,"room.confirm_delete":`是否移除“{name}”的 RoomMind 配置？`,"room.error_save_fallback":`保存配置失败`,"room.error_delete_fallback":`删除配置失败`,"room.climate_control_toggle":`温控管理`,"room.climate_control_hint":`禁用后，RoomMind 将不会控制该房间内的设备`,"room.outdoor_toggle":`室外区域`,"room.outdoor_hint":`禁用温控、霉菌检测和模型训练。传感器监控仍将继续。`,"room.alias.placeholder":`自定义显示名称`,"room.alias.clear":`重置为区域名称`,"override.label":`临时覆盖`,"override.comfort":`舒适`,"override.eco":`节能`,"override.custom":`自定义`,"override.target":`目标温度：`,"override.activate_for":`启用时长：`,"override.error_set":`设置临时覆盖失败`,"override.error_clear":`清除临时覆盖失败`,"hero.target":`目标`,"hero.override":`临时覆盖`,"hero.remaining":`剩余 {time}`,"hero.humidity":`湿度 {value}%`,"hero.device_setpoint":`设备设置为 {value}{unit}`,"hero.heat_source_primary":`供暖设备：散热器恒温阀`,"hero.heat_source_secondary":`供暖设备：空调`,"hero.heat_source_both":`供暖设备：暖气阀 + 空调`,"hero.permanent":`永久`,"hero.waiting":`正在等待传感器数据...`,"hero.not_configured":`尚未配置`,"hero.mpc_learning_paused":`MPC 学习已暂停`,"hero.mpc_learning_paused.outdoor_unavailable":`RoomMind 需要室外温度来学习该房间的热学模型。配置的室外传感器目前不可用，且未设置备用天气实体。请在“设置”中配置其中之一。`,"card.target":`目标`,"card.waiting":`正在等待数据...`,"card.humidity":`湿度 {value}%`,"card.thermostat":`温控器`,"card.thermostats":`温控器`,"card.ac":`空调`,"card.acs":`空调`,"card.climate_device":`温控设备`,"card.climate_devices":`温控设备`,"card.temp_sensor":`温度传感器`,"card.temp_sensors":`温度传感器`,"card.no_climate":`无温控设备`,"card.outdoor":`室外`,"card.tap_configure":`点击进行配置`,"card.mpc_active":`MPC 已启用`,"card.mpc_learning":`MPC 学习中`,"card.not_controlled":`未受 RoomMind 控制`,"mode.auto":`自动`,"mode.auto_desc":`根据目标温度自动进行供暖与制冷`,"mode.heat_only":`仅供暖`,"mode.heat_only_desc":`仅使用温控器/暖气，空调保持关闭`,"mode.cool_only":`仅制冷`,"mode.cool_only_desc":`仅使用空调，温控器/暖气保持关闭`,"mode.heating":`正在供暖`,"mode.cooling":`正在制冷`,"mode.fan_only":`仅送风`,"mode.idle":`待机`,"schedule.add_schedule":`添加日程`,"schedule.select_schedule":`选择日程辅助实体`,"schedule.create_helper_hint":`在 HA 设置中创建新的日程辅助实体`,"schedule.selector_label":`日程选择器实体`,"schedule.selector_value_boolean":`当前值：{value}`,"schedule.selector_value_number":`当前值：{value}`,"schedule.selector_warning":`配置了多个日程，但未设置选择器实体。将仅使用第一个日程。`,"schedule.off_action_label":`日程未启用时的动作`,"schedule.off_action_eco":`使用节能温度`,"schedule.off_action_off":`关闭设备`,"schedule.state_active":`已启用`,"schedule.state_inactive":`未启用`,"schedule.state_unreachable":`无法访问`,"schedule.no_schedules":`未配置日程`,"schedule.done":`完成`,"schedule.view_comfort":`舒适度温度：{temp}{unit}`,"schedule.view_eco":`节能温度：{temp}{unit}`,"schedule.view_selector":`当前活跃日程选择自：{name}`,"schedule.view_selector_prefix":`当前活跃日程选择自：`,"schedule.help_header":`日程是如何工作的？`,"schedule.help_temps_title":`目标温度是如何确定的？`,"schedule.help_temps":`目标温度遵循以下优先级顺序：`,"schedule.help_temps_1":`<strong>手动覆盖</strong> – 临时提升/节能/自定义覆盖始终拥有最高优先级。`,"schedule.help_temps_2":`<strong>时间段设定温度</strong> – 如果当前活跃的日程时间段的属性中包含 <code>temperature</code> 值，则使用该值。`,"schedule.help_temps_3":`<strong>默认舒适温度</strong> – 如果日程处于“开启”状态，但当前时间段没有设定温度，则使用下方配置的备用舒适温度。`,"schedule.help_temps_4":`<strong>节能温度</strong> – 当日程处于“关闭”状态（在所有设定时间段之外）时，使用节能温度。`,"schedule.help_block_title":`为每个时间段设置温度`,"schedule.help_block":`您可以通过在日程的 YAML 配置中添加 <code>temperature</code> 值，为每个时间段设置特定温度：`,"schedule.help_block_note":`如果某个时间段没有 <code>temperature</code> 数据，则将使用默认舒适温度作为替代。`,"schedule.help_split_title":`每个时间段独立的供暖/制冷目标温度`,"schedule.help_split":`对于自动模式的房间，您可以使用 <code>heat_temperature</code> 和 <code>cool_temperature</code> 为每个时间段设置独立的供暖和制冷目标温度：`,"schedule.help_split_note":`如果仅设置了其中之一，另一个将回退至房间的默认舒适温度。如果存在这两个键，它们的优先级将高于 <code>temperature</code>。`,"schedule.help_multi_title":`多个日程日程`,"schedule.help_multi":`您可以添加多个日程日程，并使用 <strong>选择器实体 (selector entity)</strong> 在它们之间进行切换。这可以是一个 <code>input_boolean</code>（在日程 1 和 2 之间切换）或一个 <code>input_number</code>（通过数字选择日程）。如果没有设置选择器实体，将仅使用第一个日程。`,"schedule.column_comfort":`舒适`,"schedule.column_eco":`节能`,"schedule.row_heat":`供暖`,"schedule.row_cool":`制冷`,"schedule.view_heat":`供暖：{comfort} / {eco}{unit}`,"schedule.view_cool":`制冷：{comfort} / {eco}{unit}`,"schedule.comfort_hint_auto":`舒适度：日程启用时的目标值。节能：日程关闭时的目标值。行项目分别设置供暖和制冷的目标值。`,"schedule.comfort_label":`备用舒适温度`,"schedule.eco_label":`节能温度`,"schedule.comfort_hint":`当日程处于“开启”状态但时间段内未设置具体温度时使用`,"schedule.from_schedule":`日程设定值：{temp}{unit}`,"schedule.from_schedule_split":`日程设定值：{heat}{unit} / {cool}{unit}`,"schedule.fallback":`备用值：{temp}{unit}`,"schedule.eco_detail":`节能模式：{temp}{unit}`,"devices.climate_entities":`温控实体`,"devices.temp_sensors":`温度传感器`,"devices.primary_sensor":`主传感器`,"devices.humidity_sensors":`湿度传感器`,"devices.no_climate":`该区域内未找到温控实体。`,"devices.no_temp_sensors":`该区域内未找到温度传感器。`,"devices.no_humidity_sensors":`该区域内未找到湿度传感器。`,"devices.occupancy_sensors":`人体存在传感器`,"devices.no_occupancy_sensors":`该区域内未找到存在传感器`,"devices.occupancy_sensor_hint":`通过追踪房间是否有人来提高热学模型的准确性`,"devices.window_sensors":`门窗传感器`,"devices.no_window_sensors":`该区域内未找到门窗传感器。`,"devices.window_open_delay":`暂停前延迟`,"devices.window_close_delay":`恢复前延迟`,"devices.add_entity":`添加实体`,"devices.done":`完成`,"devices.other_area":`其他区域`,"devices.type_thermostat":`温控阀/暖气阀`,"devices.type_ac":`空调/温控设备`,"devices.type_label":`类型`,"devices.select_to_configure":`选择要配置的设备`,"devices.heating_system_type":`供暖系统类型`,"devices.heating_system_type_info":`在停止供暖后，散热器（暖气片）特别是地暖系统会继续释放储存的余热。RoomMind 会将这种残留热量纳入计算，以避免温度过冲并提高模型准确性。采用地暖的房间还会获得更长的最短运行时间。`,"devices.system_type_none":`标准（无残留热量）`,"devices.system_type_radiator":`暖气片/散热器`,"devices.system_type_underfloor":`地板辐射供暖（地暖）`,"devices.underfloor_delay_hint":`地暖的重新启动时间较长。建议设置至少 5 分钟的开窗延迟，以避免频繁且不必要的关闭。`,"devices.heating_system_type_boost_hint":`提示：如果供暖系统类型已更改，您可以在“设置”中加速重新学习。`,"devices.idle_action":`空闲时动作`,"devices.idle_action_off":`关机`,"devices.idle_action_fan_only":`仅送风`,"devices.idle_action_setback":`节能回退`,"devices.idle_action_low":`保持最低设定值（防休眠）`,"devices.idle_action_low_hint":`将设定值降至设备的最低限值，而不是直接关机。这可以防止在“关闭”模式下休眠的电池版 Zigbee 恒温阀（TRV）无法接收后续指令。`,"devices.idle_fan_mode":`风速`,"devices.idle_fan_mode_keep":`保持不变`,"devices.setpoint_mode":`设定值控制模式`,"devices.setpoint_mode_proportional":`比例控制（阀门开度调节）`,"devices.setpoint_mode_direct":`直接控制（设备自行调节）`,"devices.setpoint_mode_hint":`“直接控制”会将实际房间目标发送至设备 —— 最适合能够自我调节的温控器和空间加热器。“比例控制”则向设备发送一个朝向最高温度的过载提升设定值 —— 最适合散热器恒温阀（TRV）。`,"devices.valve_protection_excluded":`不参与阀门保护`,"devices.valve_protection_exclude_hint":`此实体将不会被阀门保护程序循环触发（例如虚拟锅炉实体）`,"devices.info.types_title":`设备类型`,"devices.info.types_body":`“温控阀/暖气阀”指散热器恒温阀（TRV）。“温控设备”指空调、热泵或其他用于制冷或强制送风加热的设备。它们在 Home Assistant 中都是 climate 实体，两者的区别在于 RoomMind 对其控制方式的不同。`,"devices.info.control_title":`RoomMind 如何控制它们`,"devices.info.control_body":`设定值控制模式仅适用于在“完全控制”房间内配置了外部温度传感器的温控器/暖气阀。当您希望 RoomMind 通过发送提升设定值来驱动热量输出时，请使用“比例控制”。当设备应自行围绕真实目标温度进行调节时，请使用“直接控制”。`,"devices.info.modes_title":`空闲行为`,"devices.info.modes_body":`“空闲时动作”仅适用于空调/温控设备。“关机”会让设备关闭电源。“仅送风”会保持空气循环而不进行供暖或制冷。“节能回退”会保持当前模式激活，但将目标温度向背离房间目标的方向移动 2°C。此回退偏差值目前是固定的。对于暖气阀/温控器，“最低值”会让 TRV 保持在其最低设定值以防止彻底关闭，这对于在设为 OFF 时会进入深度休眠的电池供电 Zigbee TRV 非常有用。`,"devices.info.heat_source_title":`热源智能选择`,"devices.info.heat_source_body":`此选项仅当房间内同时配置了暖气阀/温控器、空调设备，并且配备了外部温度传感器时才会出现。RoomMind 可以根据室温差距和室外天气情况，自动且智能地选择最适合的设备来承担供暖任务。`,"airflow.devices":`空气流动设备`,"airflow.no_devices":`尚未配置空气流动设备。`,"airflow.no_candidates":`该区域内未找到风扇或支持风速/摆风的温控实体。`,"airflow.add_entity":`添加空气流动实体`,"airflow.role":`角色`,"airflow.role_circulation":`循环风`,"airflow.role_ventilation":`排风/新风`,"airflow.role_hvac_fan":`HVAC 内置风机`,"airflow.controllable":`可控制`,"airflow.controllable_hint":`RoomMind 可以将此设备纳入可选空气流动档位。`,"airflow.control_enabled":`允许自动控制`,"airflow.control_enabled_hint":`启用后，MPC 可调整风速、仅送风模式或摆风设置。`,"airflow.controllable_short":`可控`,"airflow.control_enabled_short":`自动`,"airflow.direction":`方向`,"airflow.direction_forward":`正向`,"airflow.direction_reverse":`反向`,"airflow.preset_mode":`预设模式`,"airflow.oscillating":`摇头`,"airflow.swing_mode":`摆风模式`,"airflow.swing_horizontal_mode":`水平摆风`,"airflow.keep":`保持当前`,"airflow.on":`开启`,"airflow.off":`关闭`,"airflow.plan_level":`MPC 档位`,"airflow.mix_plan_level":`混合计划档位`,"airflow.vent_plan_level":`换气计划档位`,"airflow.mix_factor":`混合因子`,"airflow.vent_factor":`换气因子`,"airflow.ach":`换气次数`,"airflow.planned_level":`计划档位`,"airflow.actual_level":`实际档位`,"airflow.command_applied":`已下发`,"airflow.command_unsupported_fan_only":`不支持仅送风`,"airflow.command_skipped_off_climate":`空调已关`,"airflow.command_blocked_by_mode":`已跳过`,"airflow.command_failed":`下发失败`,"airflow.command_control_disabled":`控制已关闭`,"airflow.unavailable":`不可用`,"airflow.info_title":`观测到的空气流动因子`,"airflow.info_body":`循环风和 HVAC 内置风机会作为混合因子，帮助降低多传感器读数冲突。排风/新风设备会作为室内外换气因子进入热学预测。`,"airflow.info_control_title":`控制行为`,"airflow.info_control_body":`只有同时启用“可控制”和“允许自动控制”时，RoomMind 才会向 fan 或 climate 实体发送空气流动命令。HVAC 内置风机在空闲时只有支持“仅送风”才会启动；供暖/制冷设定值仍由设备配置区控制。`,"hero.window_open":`窗户已打开 – 暂停温控`,"card.window_open":`窗户已打开`,"room.section.covers":`窗帘与遮阳`,"covers.section_title":`窗帘与遮阳`,"covers.auto_control":`窗帘自动控制`,"covers.auto_control_hint":`当预测到太阳能辐射热量会导致房间过热时，RoomMind 会自动关闭窗帘。`,"covers.deploy_threshold":`触发偏差阈值`,"covers.deploy_threshold_hint":`当预测温度超过目标温度达到此设定值时，将自动关闭窗帘。`,"covers.min_position":`最小开启位置`,"covers.min_position_hint":`窗帘关闭时的开度不会低于此值（设为 0 表示允许完全关闭）。`,"covers.override_minutes":`手动覆盖暂停时长`,"covers.override_minutes_hint":`手动移动窗帘后，暂停自动控制的时间。设为 0 表示不暂停。`,"covers.no_covers":`未配置窗帘实体。`,"covers.no_covers_in_area":`该区域内未找到窗帘实体。`,"covers.add_cover":`添加窗帘实体...`,"covers.shading_active":`防晒遮阳生效中`,"covers.auto_paused":`自动控制已暂停（手动覆盖中）`,"covers.done":`完成`,"covers.night_close":`夜间自动关闭`,"covers.night_close_hint":`在日落时自动关闭窗帘，在日出时自动打开。`,"covers.night_close_active":`夜间关闭生效中`,"covers.schedule_group_title":`日程安排`,"covers.solar_group_title":`日照控制`,"covers.schedule_section":`窗帘日程`,"covers.schedule_section_hint":`使用 HA 日程辅助实体定义窗帘控制的时间窗口。在“强制位置模式”下，日程中设定的位置会覆盖日照和温控逻辑。在“允许日照保护模式”下，RoomMind 将在当前时间窗口内自主决定窗帘的位置。`,"covers.add_schedule":`添加窗帘日程...`,"covers.schedule_mode_force":`强制位置`,"covers.schedule_mode_gate":`允许日照保护`,"covers.schedule_mode_gate_short":`日照过滤`,"covers.schedule_position":`开度位置`,"covers.schedule_position_hint":`此日程激活时的窗帘开度位置（0% = 完全关闭，100% = 完全打开）。`,"covers.schedule_selector":`日程选择器实体`,"covers.schedule_selector_hint":`选择当前激活的日程。input_boolean: 关=#1，开=#2。input_number: 对应数值选择日程序号。`,"covers.schedule_selector_warning":`配置了多个日程，但未设置选择器。将仅使用第一个日程。`,"covers.schedule_state_active":`激活`,"covers.schedule_state_inactive":`未激活`,"covers.schedule_state_unreachable":`无法访问`,"covers.schedule_active":`日程生效中`,"covers.schedule_create_link":`创建日程辅助实体`,"covers.night_position":`夜间位置`,"covers.night_position_hint":`夜间自动关闭激活时的窗帘开度位置（0% = 完全关闭）。设置了独立最小开启位置的窗帘不会低于其个别限制。`,"covers.night_close_advanced":`高级设置`,"covers.night_close_elevation":`太阳高度角阈值`,"covers.night_close_elevation_hint":`太阳必须处于地平线以下或以上的角度。0° = 恰好在日落/日出。负值 = 更暗（例如 -6° = 暮光，天明显变黑）。正值 = 仍然明亮（例如 5° = 太阳仍在地平线上方可见）。`,"covers.night_close_offset":`时间偏差`,"covers.night_close_offset_hint":`相对于太阳高度角阈值的额外时间偏移。正值 = 较晚关闭（例如 +20 = 达到阈值后延迟 20 分钟），负值 = 较早关闭。`,"covers.outdoor_min_temp":`最低室外温度限制`,"covers.outdoor_min_temp_hint":`当室外温度低于此值时，不为日照保护而关闭窗帘。天气寒冷时，来自阳光的日照热量是受欢迎的。`,"covers.per_cover_title":`单窗帘独立设置`,"covers.per_cover_hint":`为每个窗帘设置其朝向的罗盘方位以及可选的独立最小位置。`,"covers.per_cover_min_short":`最小限制`,"covers.per_cover_min_position":`单窗帘最小开启位置`,"covers.per_cover_min_position_hint":`每个窗帘的独立最小开启位置。该窗帘关闭开度绝不会低于此值。在窗帘处于大于 0% 位置时物理上已完全关闭的情况下很有用。`,"covers.snap_deploy":`直接闭合至最小位置`,"covers.snap_deploy_hint":`将窗帘直接关闭至设定的最小开启位置，而不是渐进式关闭。建议在三层玻璃窗户上使用，因为中间位置可能会导致热应力。`,"covers.info.selection_title":`选择窗帘`,"covers.info.selection_body":`从此区域选择窗帘/遮阳帘，或添加来自其他区域的实体。RoomMind 会跟踪它们的位置并进行自动控制。`,"covers.info.schedule_title":`日程控制`,"covers.info.schedule_body":`使用 HA 日程辅助实体来定义窗帘应当关闭的时段（例如晚上保护隐私）。日程的“位置”属性决定了它们关闭的程度。日程将覆盖所有其他自动控制逻辑。`,"covers.info.solar_title":`日照/温控保护`,"covers.info.solar_body":`启用自动控制后，RoomMind 会预测太阳辐射是否会导致房间过热并预防性地关闭窗帘。当学习到的热学数据可用时将使用该数据，否则采用保守的默认值。触发偏差阈值控制在关闭窗帘之前需要预测到多少温度超标。`,"covers.info.night_title":`夜间关闭`,"covers.info.night_body":`在日落时自动关闭窗帘，并在日出时重新打开。您可以设置自定义的夜间开度位置（例如 10% = 几乎关闭，但未完全关闭）。`,"covers.info.override_title":`手动覆盖`,"covers.info.override_body":`如果您手动调整了窗帘，RoomMind 会检测到该行为并为配置的持续时间暂停自动控制，这能防止系统与用户的操作发生冲突。`,"covers.info.priority_title":`优先级顺序`,"covers.info.priority_body":`手动覆盖 > 日程 > 夜间关闭 > 日照/热学控制。优先级高的规则始终胜出。当没有规则适用时，窗帘保持开启状态。`,"covers.info.entities_title":`HA 生成实体`,"covers.info.entities_body":"RoomMind 为每个房间创建两个用于外部调用的实体：`switch.roommind_{area}_cover_auto`（启用/禁用自动窗帘控制 —— 可在自动化或仪表板中使用）以及 `binary_sensor.roommind_{area}_cover_paused`（当手动覆盖激活时为 ON，例如手动移动窗帘后）。","covers.orientation_group_title":`窗帘朝向罗盘方位`,"covers.orientation_hint":`设置每个窗帘所面对的罗盘方向。RoomMind 使用该设置在阳光没有照射到建筑物这一侧时跳过防晒关闭动作。`,"covers.orientation_none":`任意方向`,"covers.orientation_N":`北`,"covers.orientation_NE":`东北`,"covers.orientation_E":`东`,"covers.orientation_SE":`东南`,"covers.orientation_S":`南`,"covers.orientation_SW":`西南`,"covers.orientation_W":`西`,"covers.orientation_NW":`西北`,"covers.orientation_N_full":`正北`,"covers.orientation_NE_full":`东北`,"covers.orientation_E_full":`正东`,"covers.orientation_SE_full":`东南`,"covers.orientation_S_full":`正南`,"covers.orientation_SW_full":`西南`,"covers.orientation_W_full":`正西`,"covers.orientation_NW_full":`西北`,"settings.general_title":`常规设置`,"settings.group_by_floor":`按楼层对房间进行分组`,"settings.climate_control_active":`温控 management 启用状态`,"settings.climate_control_hint":`禁用后，RoomMind 会继续监控所有传感器并训练模型，但不会向您的供暖或制冷设备发送任何控制指令。`,"settings.learning_title":`热学模型训练`,"settings.learning_hint":`暂停后，RoomMind 将停止收集新的测量数据并暂停热学模型训练。已有的模型数据将被保留。`,"settings.learning_exceptions":`例外情况`,"settings.learning_room_paused":`个房间已暂停学习`,"settings.learning_rooms_paused":`个房间已暂停学习`,"settings.sensors_title":`传感器与数据源`,"settings.control_title":`控制参数`,"settings.outdoor_sensor":`室外温度`,"settings.outdoor_sensor_label":`室外温度传感器`,"settings.outdoor_current":`当前室外：{temp}{unit}`,"settings.outdoor_waiting":`正在等待传感器数据...`,"settings.outdoor_humidity_sensor":`室外湿度`,"settings.outdoor_humidity_label":`室外湿度传感器`,"settings.outdoor_humidity_current":`当前室外湿度：{value}%`,"settings.smart_control":`智能温控阈值`,"settings.smart_control_hint":`配置用于供暖和制冷的室外温度限制。`,"settings.outdoor_cooling_min":`允许制冷的最低室外温度`,"settings.outdoor_cooling_min_hint":`当室外温度低于此值时，空调保持关闭`,"settings.outdoor_heating_max":`允许供暖的最高室外温度`,"settings.outdoor_heating_max_hint":`当室外温度高于此值时，供暖系统保持关闭`,"settings.saving":`正在保存...`,"settings.saved":`已保存`,"settings.error":`保存出错`,"devices.using_builtin_sensor":`正在使用温控器内置的温度传感器`,"settings.climate_intelligence":`气候智能控制`,"settings.control_mode":`控制模式`,"settings.control_mode_simple":`简单模式（滞后双位控制 / Bang-Bang）`,"settings.control_mode_mpc":`智能模式（模型预测控制 / MPC）`,"settings.control_mode_hint":`MPC 会自动学习房间的热学特性，以实现最优的精准控制`,"settings.comfort_weight":`优先级权重`,"settings.comfort_weight_comfort":`注重舒适`,"settings.comfort_weight_efficiency":`注重节能`,"settings.comfort_weight_hint":`平衡温度精度与能源消耗。偏向“舒适”会更早地对温度变化做出反应，使室温紧贴目标值。偏向“节能”则允许温度有稍微更多的漂移以减少供暖/制冷的运行时间。`,"settings.weather_entity":`天气预报`,"settings.weather_entity_hint":`可选：能够根据未来的室外温度变化进行前馈温控规划，并在室外温度传感器失效时作为备用数据源`,"settings.outdoor_unavailable_notify":`室外温度不可用时发送通知`,"settings.outdoor_unavailable_notify_hint":`当室外温度传感器和天气预报实体在 30 分钟内均未上报温度时，在 Home Assistant 中发出通知。在此情况下，RoomMind 会暂停热学模型训练，以防止历史数据受损。`,"settings.prediction_enabled":`温度变化预测`,"settings.prediction_enabled_hint":`在分析图表中显示预测的温度变化趋势。如果您的设备出现运行缓慢或卡顿，请禁用此项。`,"vacation.title":`度假模式`,"vacation.hint":`将所有房间设定为设定的节能回退温度，直到度假结束。`,"vacation.active_label":`度假模式已激活`,"vacation.end_date":`结束日期与时间`,"vacation.setback_temp":`节能回退温度`,"vacation.no_end_date":`无结束日期限制`,"vacation.deactivate":`停用度假模式`,"tabs.analytics":`图表分析`,"analytics.select_room":`选择房间`,"analytics.temperature":`实际温度`,"analytics.target":`目标温度`,"analytics.prediction":`预测趋势`,"analytics.outdoor":`室外温度`,"analytics.model_status":`模型训练状态`,"analytics.confidence":`置信度 / 准备就绪度`,"analytics.heating_rate":`供暖强度`,"analytics.cooling_rate":`制冷强度`,"analytics.solar_gain":`太阳能得热因子`,"analytics.occupancy_gain":`室内人员得热因子`,"analytics.time_constant":`热耗时间常数`,"analytics.samples":`数据样本数`,"analytics.prediction_accuracy":`模型预测精度`,"analytics.avg_deviation":`平均偏差`,"analytics.data_sources":`数据源样本数`,"analytics.data_points":`训练观察点总数`,"analytics.control_mode":`控制模式`,"analytics.control_mode_mpc":`MPC 活跃中`,"analytics.control_mode_bangbang":`MPC 学习中`,"analytics.last_model_update":`模型上次更新时间`,"analytics.accuracy_idle":`预测精度 (空闲状态)`,"analytics.accuracy_heating":`预测精度 (供暖状态)`,"analytics.info.accuracy_idle":`模型在既没有供暖也没有制冷激活时预测温度的精准度。数值越低，意味着模型对您房间自然散热特性的理解越深刻。这是第一个开始提升的数值，因为空闲状态下的数据是持续收集的。`,"analytics.info.accuracy_heating":`模型在主动供暖期间预测温度的精准度。此数值在初始阶段会偏高，因为模型需要实际的供暖周期数据来进行学习。一旦您的暖气运行过几次，此数值就会下降，随后 MPC 控制功能就将变为可用状态。`,"analytics.info.confidence":`模型用于智能 MPC 控制的综合准备就绪度。它结合了两个核心要素：数据量（已收集的空闲和主动状态样本数量）以及预测精准度（温度趋势预测有多准确）。置信度从 0% 开始，并随着模型不断收集数据而上升。达到 50% 左右表示已收集足够的空闲数据，但仍在等待供暖/制冷周期的数据。超过 80% 表示模型已具备充足数据且预测准确 —— 智能 MPC 控制将自动转为可用。100% 是当预测精度达到物理学极限时的理论最大值。`,"analytics.info.time_constant":`在关闭暖气后，房间自然冷却到室温与室外温度差距的一半所需要的时间。时间常数越长，说明房屋保温隔热性能越好 —— 房间能更久地锁住热量。时间常数越短，说明房间散热较快。模型通过观察空闲时段的室温下降过程来学习此常数。`,"analytics.info.heating_rate":`您的供暖系统对房间温度的影响强度。数值越高，意味着您的供暖系统相对于房间的热容而言，加热速度越快。模型通过观察主动供暖期间温度上升的快慢来学习此项，并用它来预测供暖需要运行多长时间。`,"analytics.info.cooling_rate":`您的空调对房间温度的影响强度。数值越高，意味着空调相对于房间的热容而言，降温速度越快。模型通过观察主动制冷期间温度下降的快慢来学习此项，并用它来预测空调需要运行多长时间。`,"analytics.info.solar_gain":`太阳辐射通过窗户对房间温度的预估加热效果。模型通过在关闭暖气的晴天时段观察房间如何升温来学习此项。配有朝南大窗户的房间该数值会更高。模型会利用这个参数在预计阳光充足时减少主动供暖，以节约能源。`,"analytics.info.occupancy_gain":`当房间有人时，来自人员活动（人、宠物、运行的电脑等）的预估产热量。模型通过在配置的存在传感器被触发时观察温度的变化来学习此项。将此产热与太阳能得热区分开，可以防止人员体温产生的热量被误归因于阳光。此项仅在房间至少配置了一个存在传感器时才会显示。`,"analytics.info.data_sources":`用于热学模型训练的测量样本数量。`,"analytics.info.data_points":`模型已经过训练的观测数据点总数。更多的数据点通常会带来更精准的预测。在 RoomMind 运行时，大约每 3 分钟会收集并保存一个新数据点。`,"analytics.no_data":`暂无数据 —— 模型学习中`,"analytics.loading":`正在加载图表分析数据...`,"settings.reset_title":`重置热学模型数据`,"settings.reset_hint":`清除所有已学习的热学模型数据和历史记录。模型将从零开始重新学习。`,"settings.reset_all_label":`所有房间`,"settings.reset_all_hint":`一次性清除所有房间已学到的热学数据和历史记录。`,"settings.reset_all_btn":`重置全部`,"settings.reset_all_confirm":`确定要清除所有房间已学习的热学数据和历史记录吗？这会让所有的模型重头开始重新学习。`,"settings.reset_room_label":`单个房间`,"settings.reset_room_hint":`选择一个特定房间以清除其热学数据 and 历史记录。`,"settings.reset_room_confirm":`确定要清除此房间已学习的热学数据和历史记录吗？该模型将从零开始重新学习。`,"settings.reset_room_select":`选择房间`,"settings.reset_btn":`重置`,"settings.reset_no_rooms":`未配置房间。`,"settings.boost_title":`加速模型学习`,"settings.boost_hint":`热学模型会随时间推移来适应您的房间供暖和制冷特性。在发生重大变化（如更换了新散热器/空调、重新做了墙体保温隔热、更换了大型家具）后，现有的模型可能会失效。此操作会重置模型的不确定度，让其能更快地学习并适应新的房间状况。`,"settings.boost_label":`加速重新学习`,"settings.boost_room_select":`选择房间`,"settings.boost_btn":`启动加速`,"settings.boost_cooldown":`已启用 – 正在快速重新学习中`,"settings.boost_no_rooms":`未配置房间。`,"analytics.range_1d":`今天`,"analytics.range_2d":`2天`,"analytics.range_7d":`本周`,"analytics.range_30d":`本月`,"analytics.export":`测量数据导出`,"analytics.heating_period":`供暖时段`,"analytics.cooling_period":`制冷时段`,"analytics.blind_position":`窗帘位置`,"analytics.window_open_period":`开窗时段`,"analytics.chart_info_title":`如何阅读此图表`,"analytics.exported":`导出成功！`,"analytics.copy_diagnostics":`复制诊断信息`,"analytics.export_download":`下载文件`,"analytics.export_clipboard":`复制到剪贴板`,"analytics.copied_to_clipboard":`已成功复制到剪贴板！`,"analytics.range_from":`开始时间`,"analytics.range_to":`结束时间`,"analytics.chart_info_body":`**线条：** 橙色实线代表测量到的房间实际温度。绿色虚线代表来自您日程安排的目标温度。蓝色点线代表热学模型对房间温度趋势的预测值。

**阴影区域：** 红色阴影代表主动供暖时段，蓝色代表主动制冷时段，青色代表窗帘或窗户处于打开状态的时段。

**未来预测（“现在”时间线右侧）：** 绿色虚线展示了未来 3 小时内的日程目标温度。蓝色点线显示了预测的房间温度趋势。

**预测模式：** 当显示“MPC 已启用”时，预测将采用完整的 MPC 优化器，包含智能的前馈式预加热/预制冷控制。而当模型仍在学习期间，则会采用较为简化的仿真机制进行趋势模拟。

**限制说明：** 预测假定当前的外部环境条件（如室外温度、窗户开合状态）保持恒定。仿真精度的准确性高度依赖于热学模型对该房间的训练完备度 —— 在使用初期，预测可能会存在偏差。一旦 MPC 正式激活，预测将变得非常可靠。`,"presence.title":`存在检测 / 人体感应`,"presence.hint":`在全家离家时，自动将所有房间切换为节能温度。`,"presence.hint_detail":`启用后，一旦配置的所有成员都离开家，所有房间将立即转为节能温度。您还可以为每个房间单独定制，指定仅有哪些成员在此房间时才生效。`,"presence.add_person":`添加家庭成员`,"presence.add_entity":`添加存在感应实体`,"presence.person_label":`家庭成员`,"room.section.presence":`存在检测`,"presence.room_help_header":`单房间级存在检测如何工作？`,"presence.room_help_body":`选择与此房间相关联的成员。当所选成员全都不在房间/家时，该房间会自动切换为节能温度。如果未做任何选择，将默认遵循全局规则：全家没人时切换为节能温度。`,"presence.state_home":`在家`,"presence.state_away":`离家`,"presence.room_none_assigned":`遵循全局规则 — 没人时进入节能模式`,"presence.ignore_toggle":`忽略存在检测`,"presence.ignore_hint":`控制此房间如何对存在检测做出反应。您可以在下方分配具体的成员。当所分配的成员全都不在家时，房间会切到节能温度。您也可以使用上方的开关完全跳过检测，使其始终严格遵循日程安排。`,"presence.help_ignore_title":`“忽略存在检测”的作用是什么？`,"presence.help_ignore_body":`启用后，此房间将完全跳过存在检测逻辑。它会始终严格执行其设定的日程，而不会因为谁在家或不在家而降温或切到节能温度。这对于需要保持恒温而无需考虑是否有人在场的房间特别管用，比如服务器机房、宠物房间，或者给未在 Home Assistant 中追踪轨迹的访客居住的客房。`,"presence.tile_ignored":`已忽略存在检测。房间将始终执行设定的日程。`,"presence.away_action_label":`当无人在此/离家时的动作`,"presence.away_action_eco":`使用节能温度`,"presence.away_action_off":`彻底关闭设备`,"presence.clears_override_label":`离家时终止临时覆盖`,"presence.clears_override_hint":`当全家离家时，手动设置的临时覆盖将被暂停，房间自动执行离家设定动作。当有人返回时，临时覆盖将重新恢复，直到其原本设定的过期时间为止。`,"card.presence_away":`离家`,"valve_protection.title":`阀门保护`,"valve_protection.hint":`在非采暖季期间，定期且短暂地全开和关闭闲置的恒温阀，以防止其机械阀针卡死或结垢钙化。`,"valve_protection.interval_label":`保护触发周期`,"valve_protection.interval_suffix":`天`,"valve_protection.interval_hint":`阀门闲置多久后触发一次阀门保护循环（可选 1–90 天）`,"compressor.title":`压缩机保护与源联动`,"compressor.no_groups":`未配置压缩机联动组。`,"compressor.add_group":`添加压缩机联动组`,"compressor.group_name":`联动组名称`,"compressor.members":`室内温控单元`,"compressor.members_hint":`选择由此压缩机或热源驱动的所有温控设备（例如多联机室内分机、暖气片 TRV、风机盘管等）。`,"compressor.min_run":`最短运行时间`,"compressor.min_run_hint":`压缩机/热源一旦启动，必须维持运行的最短时长。`,"compressor.min_run_suffix":`分钟`,"compressor.min_off":`最短停机时间`,"compressor.min_off_hint":`压缩机/热源关停后，必须保持关闭的最短时长（防频繁起停）。`,"compressor.min_off_suffix":`分钟`,"compressor.delete":`删除联动组`,"compressor.delete_confirm":`确定要删除压缩机联动组“{name}”吗？`,"compressor.master_entity":`主控热源/压缩机设备`,"compressor.master_entity_hint":`为本组室内设备提供冷热源的中心主控实体，例如燃气采暖锅炉、室外热泵主机，或中央空调风管机的主控开关。RoomMind 将在有房间需要供暖或制冷时自动开启它，并在所有房间都空闲时将其关闭。若仅使用操作脚本或防频繁起停保护，可将其留空。`,"compressor.conflict_resolution":`冷热冲突解决策略`,"compressor.conflict_resolution_hint":`当组内某些房间需要供暖而另一些房间同时需要制冷时，决定如何处理。供暖优先：供暖始终胜出（对于冬季防冻最安全）。制冷优先：制冷始终胜出。多数决定：按房间数量多的一方决定模式，数量相同时供暖胜出。基于室外温度：自动根据设置中的室外最高供暖阈值来决定。`,"compressor.conflict_heating_priority":`供暖优先 (注重防冻安全)`,"compressor.conflict_cooling_priority":`制冷优先`,"compressor.conflict_majority":`少数服从多数`,"compressor.conflict_outdoor_temp":`基于室外温度自动判断`,"compressor.action_script":`操作关联脚本`,"compressor.action_script_hint":`每当本组的供暖/制冷需求发生变化时运行的 Home Assistant 脚本。这对于需要特殊指令的系统非常有用，例如取消 Vaillant 锅炉的 Quick Veto 或切换继电器。无论是否配置了主控设备，都可以运行。如果未设置主控设备，则仅触发脚本。脚本执行时将传入变量：action（heat/cool/idle）、master_entity、members、active_members。`,"compressor.enforce_uniform_mode":`强制统一工作模式`,"compressor.enforce_uniform_mode_hint":`该联动组内的所有温控器必须运行在完全相同的 HVAC 工作模式下（全部供暖或全部制冷）。与联动组解析出的全局工作模式相冲突的房间，将被强制设为空闲（待机）。这对于可以自动启动但要求所有室内分机必须运行在相同模式（不能一个制冷一个供暖）的热泵非常有用。`,"mold.title":`霉菌风险防护`,"mold.detection":`霉菌监测`,"mold.detection_desc":`当湿度条件达到霉菌易滋生范围时接收提醒通知`,"mold.threshold":`湿度报警阈值 (%)`,"mold.threshold_hint":`当房间湿度持续超过该设定值时发出警报`,"mold.sustained":`持续时间阈值 (分钟)`,"mold.sustained_hint":`仅在霉菌滋生风险持续达到此时间后才触发报警`,"mold.prevention":`防霉除湿控制`,"mold.prevention_desc":`自动提升房间设定温度以降低霉菌滋生风险`,"mold.intensity":`除湿升温强度`,"mold.intensity_light":`轻度 (+{delta}{unit})`,"mold.intensity_medium":`中度 (+{delta}{unit})`,"mold.intensity_strong":`重度 (+{delta}{unit})`,"mold.intensity_hint":`较温暖的空气能够降低冰冷墙壁表面的相对湿度。轻度升温通常足以应对中等风险，重度升温可使墙面表面湿度降低达 8–10% —— 但这会消耗明显的能源。`,"card.mold_warning":`霉菌风险`,"card.mold_critical":`霉菌危险！`,"card.mold_prevention":`防霉升温中 +{delta}{unit}`,"room.mold_surface_rh":`预估墙体表面相对湿度：{value}%`,"settings.intro.general":`基础显示与温度控制的全局设置。`,"settings.intro.sensors":`配置室外温度传感器和天气预报数据，以实现精确的前馈温控规划。`,"settings.intro.control":`选择 RoomMind 控制您的温控设备的方式，并设定温控优先级及相关温度阈值。`,"settings.intro.presence":`在您离家外出时，自动调低房间设定温度以节约电能/燃气。`,"settings.intro.vacation":`设定在您度假出行期间，所有房间所要遵循的节能回退温度。`,"settings.intro.valve":`在非采暖季节，定期且短暂地动作闲置的恒温阀门，防止阀针生锈或结垢卡死。`,"settings.intro.compressor":`管理共享同一个室外压缩机或中央采暖热源的室内温控单元联动组。您可以分配一个主控设备（例如锅炉、室外热泵主机），使其根据房间的冷热需求自动联动启停。内置的防频繁起停机制可以保护您的设备免受频繁开关导致的损坏。`,"settings.intro.mold":`持续监控房间空气和表面湿度，并在有发霉风险时自动升温防霉。`,"settings.intro.notifications":`配置接收设备通知和警告的方式与目标实体。`,"settings.intro.learning":`管理热学模型的学习与训练状态，并在房间发生重大物理结构调整后加速重新学习。`,"settings.intro.reset":`清除已学到的热学模型和历史记录。这会让模型一切归零，重新开始训练。`,"notifications.title":`系统通知`,"notifications.enabled":`启用系统通知`,"notifications.enabled_hint":`禁用后，任何温控警报将不会发送 —— 无论是发送到您的移动设备还是显示在 HA 侧边栏。`,"notifications.desc":`选择接收警报通知的手机或终端。如果未设定任何接收目标，警报将默认发送到 Home Assistant 的侧边栏通知中。`,"notifications.add_target_label":`添加通知设备实体`,"notifications.add_target_hint":"如果列表中未列出您的设备，请输入其通知实体 ID（例如 `notify.mobile_app_...`）。您可以在 HA 设置 → 设备与服务 → 您的手机 → 对应的 Notify 实体中找到它。","notifications.target_unnamed":`未命名设备`,"notifications.target_person":`家庭成员`,"notifications.target_when_always":`始终发送`,"notifications.target_when_home":`仅在在家时发送`,"notifications.cooldown":`通知发送冷却时间 (分钟)`,"notifications.cooldown_hint":`同一房间在发生重复警报时，两次推送之间的最小间隔时间`,"notifications.mold_prevention_notify":`防霉除湿激活时发送通知`,"notifications.mold_prevention_notify_hint":`当防霉保护触发（温度自动提升）时，向关联设备发送推送通知`,"room.section.heat_source":`多热源协同控制 (双源联动)`,"heat_source.toggle":`热源智能自动选择`,"heat_source.toggle_hint":`当房间内同时安装了暖气恒温阀和冷暖空调/热泵时，RoomMind 会根据当前室温差距和室外天气，智能地将供暖需求路由给最经济高效的设备。`,"heat_source.primary_delta":`主热源 (暖气) 联动启动偏差`,"heat_source.primary_delta_hint":`仅当室温与目标值的差距超过此设定温度时，才启用主热源（如散热器/燃气锅炉）。在此温差范围内，将仅使用升温响应速度极快的辅助热源（空调）。`,"heat_source.primary_delta_suffix":`°C`,"heat_source.outdoor_threshold":`室外温度偏好切换点`,"heat_source.outdoor_threshold_hint":`当室外温度高于此设定值时，优先使用空调/热泵供暖（此时热泵效率极高）。当室外温度低于此值时，优先使用燃气锅炉/暖气片供暖。`,"heat_source.outdoor_threshold_suffix":`°C`,"heat_source.ac_min_outdoor":`允许空调供暖的最寒冷室外温度`,"heat_source.ac_min_outdoor_hint":`当室外温度低于此值时，完全禁止使用空调进行供暖，以保护热泵室外机硬件免受极端低温损坏。`,"heat_source.ac_min_outdoor_suffix":`°C`,"heat_source.summary_disabled":`热源智能选择已关闭`,"common.remove":`移除`,"common.yes":`是`,"common.no":`否`,"room.section.comfort":`体感与夜间`,"hero.perceived_temp":`体感 {value}{unit}`,"hero.night_mode_active":`夜间模式已启用`,"hero.rapid_recovery_active":`快速追温中`,"airflow.hvac_output":`空调输出`,"airflow.night_capped":`夜间限速`,"airflow.skipped":`已跳过`,"airflow.confidence_observed":`已观测`,"airflow.confidence_assumed":`假定状态`,"airflow.confidence_stale":`状态过期`,"airflow.confidence_conflicting":`状态冲突`,"airflow.confidence_unknown":`未知`,"airflow.preset_mode_thermal":`制冷/制热预设`,"airflow.preset_mode_idle":`空闲预设`,"airflow.preset_mode_night":`夜间预设`,"airflow.power_sensor":`功率传感器`,"airflow.compressor_stage_observer":`压缩机观测器`,"airflow.observer_auto":`自动`,"airflow.observer_power":`功率传感器`,"airflow.observer_slope":`温度斜率`,"airflow.observer_disabled":`禁用`,"airflow.assumed_state_ttl":`假定状态保留秒数`,"airflow.fan_capacity_curve":`风速换热能力曲线`,"airflow.fan_power_curve":`风机功耗曲线`,"comfort.perceived_temp":`体感温度`,"comfort.control_target":`控制目标`,"comfort.control_target_air":`空气温度`,"comfort.control_target_perceived":`体感温度`,"comfort.night_mode":`夜间模式`,"comfort.active":`运行中`,"comfort.inactive":`未运行`,"comfort.rapid_recovery":`快速追温`,"comfort.night_controls":`夜间灯光/声音`,"comfort.room_coupling":`房间耦合`,"comfort.summary":`安静时段 {hours}；夜间风速上限 {fan}；睡眠温度缓变 {ramp}°C。`,"comfort.live_coupling":`实时房间耦合`,"comfort.gate":`通道`,"comfort.adjacent_temp":`相邻房间温度 {temp}°C`,"comfort.night_mode_hint":`安静时段自动关闭灯光、显示屏和提示音，并应用睡眠舒适策略。`,"comfort.quiet_start":`安静开始`,"comfort.quiet_end":`安静结束`,"comfort.max_fan_level_night":`夜间最大风速`,"comfort.sleep_temp_ramp":`睡眠温度缓变 (°C)`,"comfort.room_volume":`房间体积 (m³)`,"comfort.rapid_recovery_delta":`快速追温阈值 (°C)`,"comfort.night_allow_rapid_recovery":`夜间允许快速追温`,"comfort.night_allow_rapid_recovery_hint":`当温度距离目标很远时，临时突破静音风速限制。`,"comfort.no_night_controls":`还没有配置夜间灯光、显示屏或声音控制。`,"comfort.add_night_control":`添加夜间控制`,"comfort.night_control_new":`新的夜间控制`,"comfort.night_control_entity":`灯、开关、选择或数值实体`,"comfort.night_control_role":`用途`,"comfort.role_indicator_light":`指示灯`,"comfort.role_display":`显示屏`,"comfort.role_beeper":`提示音`,"comfort.role_sound":`声音`,"comfort.role_other":`其他`,"comfort.restore_after_night":`白天恢复`,"comfort.night_value":`夜间值`,"comfort.day_value":`白天值`,"comfort.adjacent_rooms":`相邻房间`,"comfort.no_adjacent_rooms":`还没有配置相邻房间。`,"comfort.add_adjacent_room":`添加相邻房间`,"comfort.adjacent_new":`新的相邻房间`,"comfort.adjacent_room":`相邻房间`,"comfort.select_room":`选择房间`,"comfort.door_sensor":`门/窗/通道传感器`,"comfort.coupling_weight":`耦合权重 k`,"comfort.allow_borrowed_conditioning":`允许借冷/借热`,"comfort.allow_borrowed_conditioning_hint":`通道打开时，允许使用相邻房间的冷量或热量影响本房间预测。`,"comfort.info_title":`体感模型`,"comfort.info_body":`RoomMind 可以控制空气温度，也可以控制估计的体感温度，体感会考虑风速和湿度。`,"comfort.info_night_title":`夜间模式`,"comfort.info_night_body":`安静时段可以限制风速、选择睡眠预设、关闭设备 LED/显示屏/提示音，并在早上恢复。`,"comfort.info_coupling_title":`房间耦合`,"comfort.info_coupling_body":`相邻房间和门传感器让模型估计开门串冷/串热，而不是把每个房间都当成孤立系统。`},xt={en:vt,de:yt,"zh-Hans":bt,zh:bt};function S(e,t,n){let r=(xt[t]??xt[t.split(`-`)[0]]??xt.en)[e]??xt.en[e]??e;if(n)for(let[e,t]of Object.entries(n))r=r.replaceAll(`{${e}}`,String(t));return r}function St(e,t){if(e.area_id)return e.area_id;if(e.device_id&&t){let n=t[e.device_id];if(n?.area_id)return n.area_id}return null}function Ct(e,t,n){return t?Object.values(t).filter(t=>St(t,n)===e):[]}function wt(e){switch(e){case`heating`:return`mode-heating`;case`cooling`:return`mode-cooling`;case`fan_only`:return`mode-idle`;case`idle`:return`mode-idle`;default:return`mode-other`}}var Tt={heating:`mode.heating`,cooling:`mode.cooling`,fan_only:`mode.fan_only`,idle:`mode.idle`};function Et(e,t){return S(Tt[e],t)}var Dt=l`
  .mode-pill {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 13px;
    font-weight: 500;
    padding: 4px 14px;
    border-radius: 16px;
  }

  .mode-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
  }

  .mode-heating {
    color: var(--warning-color, #ff9800);
    background: rgba(255, 152, 0, 0.12);
  }
  .mode-heating .mode-dot {
    background: var(--warning-color, #ff9800);
  }

  .mode-cooling {
    color: #2196f3;
    background: rgba(33, 150, 243, 0.12);
  }
  .mode-cooling .mode-dot {
    background: #2196f3;
  }

  .mode-idle {
    color: var(--secondary-text-color, #757575);
    background: rgba(0, 0, 0, 0.05);
  }
  .mode-idle .mode-dot {
    background: var(--disabled-text-color, #bdbdbd);
  }

  .mode-other {
    color: var(--secondary-text-color);
    background: rgba(0, 0, 0, 0.05);
  }
  .mode-other .mode-dot {
    background: var(--secondary-text-color);
  }
`,Ot=`M11.83,9L15,12.16C15,12.11 15,12.05 15,12A3,3 0 0,0 12,9C11.94,9 11.89,9 11.83,9M7.53,9.8L9.08,11.35C9.03,11.56 9,11.77 9,12A3,3 0 0,0 12,15C12.22,15 12.44,14.97 12.65,14.92L14.2,16.47C13.53,16.8 12.79,17 12,17A5,5 0 0,1 7,12C7,11.21 7.2,10.47 7.53,9.8M2,4.27L4.28,6.55L4.73,7C3.08,8.3 1.78,10 1,12C2.73,16.39 7,19.5 12,19.5C13.55,19.5 15.03,19.2 16.38,18.66L16.81,19.08L19.73,22L21,20.73L3.27,3M12,7A5,5 0 0,1 17,12C17,12.64 16.87,13.26 16.64,13.82L19.57,16.75C21.07,15.5 22.27,13.86 23,12C21.27,7.61 17,4.5 12,4.5C10.6,4.5 9.26,4.75 8,5.2L10.17,7.35C10.74,7.13 11.35,7 12,7Z`;function kt(e){return e.config?.unit_system?.temperature===`°F`}function C(e){return kt(e)?`°F`:`°C`}function w(e,t){return kt(t)?e*9/5+32:e}function At(e,t){return kt(t)?(e-32)*5/9:e}function T(e,t){return kt(t)?e*9/5:e}function E(e,t,n=1){return w(e,t).toFixed(n)}function D(e){return kt(e)?`1`:`0.5`}function O(e,t,n){return{min:String(Math.round(w(e,n))),max:String(Math.round(w(t,n)))}}function k(e,t,n,r){var i=arguments.length,a=i<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,o;if(typeof Reflect==`object`&&typeof Reflect.decorate==`function`)a=Reflect.decorate(e,t,n,r);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(i<3?o(a):i>3?o(t,n,a):o(t,n))||a);return i>3&&a&&Object.defineProperty(t,n,a),a}var A=t((()=>{}));_(),A();var j=class extends g{constructor(...e){super(...e),this.config=null,this.climateEntityCount=0,this.tempSensorCount=0,this.controlMode=`bangbang`,this.climateControlActive=!0,this.reordering=!1,this.canMoveUp=!1,this.canMoveDown=!1}static{this.styles=[Dt,l`
      :host {
        display: block;
      }

      ha-card {
        cursor: pointer;
        transition:
          box-shadow 0.2s ease,
          transform 0.15s ease;
        overflow: hidden;
        position: relative;
        height: 100%;
        box-sizing: border-box;
      }

      ha-card:hover {
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
        transform: translateY(-1px);
      }

      .hide-btn {
        --mdc-icon-button-size: 28px;
        --mdc-icon-size: 16px;
        color: var(--secondary-text-color);
        opacity: 0;
        transition: opacity 0.2s ease;
        position: absolute;
        top: 8px;
        right: 8px;
      }

      ha-card:hover .hide-btn {
        opacity: 0.4;
      }

      .hide-btn:hover {
        opacity: 1 !important;
      }

      /* Colored left accent based on mode */
      .accent {
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        width: 4px;
      }

      .accent-heating {
        background: var(--warning-color, #ff9800);
      }

      .accent-cooling {
        background: #2196f3;
      }

      .accent-idle {
        background: var(--disabled-text-color, #bdbdbd);
      }

      .accent-unconfigured {
        background: transparent;
      }

      .card-inner {
        padding: 20px 20px 16px;
      }

      /* Header row: name + badge */
      .card-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
      }

      .area-name {
        font-size: 15px;
        font-weight: 500;
        color: var(--primary-text-color);
        margin: 0;
        letter-spacing: 0.01em;
      }

      /* Card-specific mode-pill overrides (smaller than default) */
      .mode-pill {
        gap: 5px;
        font-size: 12px;
        padding: 3px 10px;
        border-radius: 12px;
      }

      .mode-dot {
        width: 7px;
        height: 7px;
      }

      /* Temperature display */
      .temp-section {
        display: flex;
        align-items: baseline;
        gap: 8px;
        margin: 12px 0 0 0;
      }

      .current-temp {
        font-size: 36px;
        font-weight: 300;
        color: var(--primary-text-color);
        line-height: 1;
      }

      .temp-unit {
        font-size: 18px;
        font-weight: 300;
        color: var(--secondary-text-color);
      }

      .target-info {
        font-size: 13px;
        color: var(--secondary-text-color);
        margin-left: auto;
      }

      .target-value {
        font-weight: 500;
        color: var(--primary-text-color);
      }

      .override-icon {
        --mdc-icon-size: 14px;
        vertical-align: middle;
        margin-left: 4px;
        color: var(--warning-color, #ff9800);
      }

      .window-icon {
        --mdc-icon-size: 14px;
        vertical-align: middle;
        margin-left: 4px;
        color: var(--warning-color, #ff9800);
      }

      .away-icon {
        --mdc-icon-size: 14px;
        vertical-align: middle;
        margin-left: 4px;
        color: var(--info-color, #2196f3);
      }

      /* Footer row: humidity + MPC status */
      .card-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top: 8px;
        min-height: 20px;
      }

      .humidity-info {
        font-size: 13px;
        color: var(--secondary-text-color);
      }

      .mpc-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 11px;
        font-weight: 500;
        padding: 2px 8px 2px 6px;
        border-radius: 10px;
        --mdc-icon-size: 14px;
      }

      .mpc-badge.active {
        color: var(--success-color, #4caf50);
        background: rgba(76, 175, 80, 0.12);
      }

      .mpc-badge.learning {
        color: var(--secondary-text-color);
        background: rgba(158, 158, 158, 0.1);
      }

      .mold-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 11px;
        font-weight: 500;
        padding: 2px 8px 2px 6px;
        border-radius: 10px;
        --mdc-icon-size: 14px;
      }

      .mold-badge.warning {
        color: var(--warning-color, #ff9800);
        background: rgba(255, 152, 0, 0.12);
      }

      .mold-badge.critical {
        color: var(--error-color, #db4437);
        background: rgba(219, 68, 55, 0.12);
      }

      .mold-badge.prevention {
        color: var(--info-color, #2196f3);
        background: rgba(33, 150, 243, 0.12);
      }

      .outdoor-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 11px;
        font-weight: 500;
        padding: 2px 8px 2px 6px;
        border-radius: 10px;
        --mdc-icon-size: 14px;
        color: var(--success-color, #4caf50);
        background: rgba(76, 175, 80, 0.12);
      }

      .badge-row {
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
      }

      .no-temp {
        font-size: 24px;
        font-weight: 300;
        color: var(--secondary-text-color);
        line-height: 1;
      }

      .uncontrolled-hint {
        font-size: 11px;
        color: var(--disabled-text-color, #9e9e9e);
        margin-top: 6px;
      }

      .reorder-overlay {
        position: absolute;
        inset: 0;
        z-index: 2;
        display: flex;
        pointer-events: none;
        border-radius: inherit;
        overflow: hidden;
      }

      .reorder-half {
        pointer-events: auto;
        flex: 0 0 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: background 0.15s ease;
        background: rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.05);
      }

      .reorder-half.left {
        border-radius: inherit;
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        border-right: 1px solid rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.08);
      }

      .reorder-half.right {
        border-radius: inherit;
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
        border-left: 1px solid rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.08);
        margin-left: auto;
      }

      .reorder-half:hover {
        background: rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.1);
      }

      .reorder-half ha-icon-button {
        --mdc-icon-button-size: 36px;
        --mdc-icon-size: 20px;
        color: var(--secondary-text-color);
        pointer-events: none;
      }

      .reorder-half:hover ha-icon-button {
        color: var(--primary-text-color);
      }

      .reorder-half.disabled {
        opacity: 0.25;
        cursor: default;
      }

      .reorder-half.disabled:hover {
        background: rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.05);
      }

      /* Device summary for unconfigured cards */
      .device-summary {
        font-size: 13px;
        color: var(--secondary-text-color);
        margin-top: 8px;
      }

      .device-summary.empty {
        color: var(--disabled-text-color, #9e9e9e);
        font-style: italic;
      }

      /* Configure prompt for unconfigured areas */
      .configure-prompt {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top: 12px;
        padding-top: 12px;
        border-top: 1px solid var(--divider-color, #eee);
      }

      .configure-text {
        font-size: 13px;
        color: var(--secondary-text-color);
      }

      .configure-arrow {
        font-size: 18px;
        color: var(--primary-color);
      }

      /* Waiting state */
      .waiting {
        font-size: 13px;
        color: var(--disabled-text-color, #9e9e9e);
        font-style: italic;
        margin-top: 8px;
      }
    `]}render(){let e=this.climateEntityCount>0,t=(this.config?.devices?.length??0)>0||(this.config?.thermostats?.length??0)>0||(this.config?.acs?.length??0)>0,n=this.config?.is_outdoor??!1,r=this.config!==null&&t&&!n,i=this.config?.live,a=i?.mode,o=(!r||n)&&i&&(i.current_temp!==null||i.current_humidity!==null),s=r?a===`heating`?`accent-heating`:a===`cooling`?`accent-cooling`:`accent-idle`:o?`accent-idle`:`accent-unconfigured`;return m`
      <ha-card @click=${this._onCardClick}>
        <div class="accent ${s}"></div>
        ${this.reordering?h:m`<ha-icon-button
              class="hide-btn"
              .path=${Ot}
              @click=${this._onHideClick}
            ></ha-icon-button>`}
        ${this.reordering?m`<div class="reorder-overlay">
              <div
                class="reorder-half left ${this.canMoveUp?``:`disabled`}"
                @click=${this._onMoveUp}
              >
                <ha-icon-button
                  .path=${`M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z`}
                ></ha-icon-button>
              </div>
              <div
                class="reorder-half right ${this.canMoveDown?``:`disabled`}"
                @click=${this._onMoveDown}
              >
                <ha-icon-button
                  .path=${`M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z`}
                ></ha-icon-button>
              </div>
            </div>`:h}
        <div class="card-inner">
          <div class="card-header">
            <h3 class="area-name">${this.config?.display_name||this.area.name}</h3>
            ${r&&i?m`
                  <span class="mode-pill ${wt(i.mode)}">
                    <span class="mode-dot"></span>
                    ${Et(i.mode,this.hass.language)}${i.heating_power>0&&i.heating_power<100?m` ${i.heating_power}%`:h}
                  </span>
                `:h}
          </div>

          ${r?this._renderConfigured():this.config?.live&&(this.config.live.current_temp!==null||this.config.live.current_humidity!==null)?this._renderSensorOnly():this._renderUnconfigured(e)}
        </div>
      </ha-card>
    `}_renderConfigured(){let e=this.config?.live;if(!e)return m`<div class="waiting">${S(`card.waiting`,this.hass.language)}</div>`;let t=this.controlMode===`mpc`;return m`
      <div class="temp-section">
        ${e.current_temp===null?m`<span class="no-temp">--</span>`:m`
              <span class="current-temp">${E(e.current_temp,this.hass)}</span>
              <span class="temp-unit">${C(this.hass)}</span>
            `}
        ${this._renderTargetInfo(e)}
      </div>
      <div class="card-footer">
        <span class="humidity-info">
          ${e.current_humidity===null?h:S(`card.humidity`,this.hass.language,{value:e.current_humidity.toFixed(0)})}
        </span>
        <span class="badge-row">
          ${e.mold_risk_level&&e.mold_risk_level!==`ok`?m`<span class="mold-badge ${e.mold_risk_level}">
                <ha-icon icon="mdi:water-alert"></ha-icon>
                ${e.mold_risk_level===`critical`?S(`card.mold_critical`,this.hass.language):S(`card.mold_warning`,this.hass.language)}
              </span>`:h}
          ${e.mold_prevention_active?m`<span class="mold-badge prevention">
                <ha-icon icon="mdi:shield-check"></ha-icon>
                ${S(`card.mold_prevention`,this.hass.language,{delta:T(e.mold_prevention_delta,this.hass).toFixed(0),unit:C(this.hass)})}
              </span>`:h}
          ${t?m`<span class="mpc-badge ${e.mpc_active?`active`:`learning`}">
                <ha-icon .icon=${e.mpc_active?`mdi:brain`:`mdi:school-outline`}></ha-icon>
                ${e.mpc_active?S(`card.mpc_active`,this.hass.language):S(`card.mpc_learning`,this.hass.language)}
              </span>`:h}
        </span>
      </div>
      ${!this.climateControlActive||this.config?.climate_control_enabled===!1?m`<div class="uncontrolled-hint">
            ${S(`card.not_controlled`,this.hass.language)}
          </div>`:h}
    `}_renderTargetInfo(e){if(e.target_temp===null&&e.heat_target===null)return h;let t=(this.config?.climate_mode??`auto`)===`auto`&&e.heat_target!=null&&e.cool_target!=null&&e.heat_target!==e.cool_target?m`<span class="target-value"
          >${E(e.heat_target,this.hass)} –
          ${E(e.cool_target,this.hass)}${C(this.hass)}</span
        >`:m`<span class="target-value"
          >${E(e.target_temp??e.heat_target,this.hass)}${C(this.hass)}</span
        >`;return m`
      <span class="target-info">
        ${S(`card.target`,this.hass.language)} ${t}
        ${e.override_active?m`<ha-icon class="override-icon" icon="mdi:timer-outline"></ha-icon>`:h}
        ${e.window_open?m`<ha-icon class="window-icon" icon="mdi:window-open-variant"></ha-icon>`:h}
        ${e.presence_away?m`<ha-icon class="away-icon" icon="mdi:home-off-outline"></ha-icon>`:h}
      </span>
    `}_renderSensorOnly(){let e=this.config.live,t=this.config?.is_outdoor??!1;return m`
      <div class="temp-section">
        ${e.current_temp===null?m`<span class="no-temp">--</span>`:m`
              <span class="current-temp">${E(e.current_temp,this.hass)}</span>
              <span class="temp-unit">${C(this.hass)}</span>
            `}
      </div>
      <div class="card-footer">
        <span class="humidity-info">
          ${e.current_humidity===null?h:S(`card.humidity`,this.hass.language,{value:e.current_humidity.toFixed(0)})}
        </span>
        <span class="badge-row">
          ${t?m`<span class="outdoor-badge">
                <ha-icon icon="mdi:tree"></ha-icon>
                ${S(`card.outdoor`,this.hass.language)}
              </span>`:h}
          ${e.mold_risk_level&&e.mold_risk_level!==`ok`?m`<span class="mold-badge ${e.mold_risk_level}">
                <ha-icon icon="mdi:water-alert"></ha-icon>
                ${e.mold_risk_level===`critical`?S(`card.mold_critical`,this.hass.language):S(`card.mold_warning`,this.hass.language)}
              </span>`:h}
        </span>
      </div>
    `}_renderUnconfigured(e){let t=this.hass.language;if(!e)return m`<div class="device-summary empty">${S(`card.no_climate`,t)}</div>`;let n=this.climateEntityCount,r=this.tempSensorCount;return m`
      <div class="device-summary">
        ${n}
        ${S(n===1?`card.climate_device`:`card.climate_devices`,t)}${r>0?` \u00B7 ${r} ${S(r===1?`card.temp_sensor`:`card.temp_sensors`,t)}`:``}
      </div>
      <div class="configure-prompt">
        <span class="configure-text">${S(`card.tap_configure`,t)}</span>
        <span class="configure-arrow">›</span>
      </div>
    `}_onCardClick(){this.dispatchEvent(new CustomEvent(`area-selected`,{detail:{areaId:this.area.area_id},bubbles:!0,composed:!0}))}_onMoveUp(e){e.stopPropagation(),this.canMoveUp&&this.dispatchEvent(new CustomEvent(`move-room-up`,{detail:{areaId:this.area.area_id},bubbles:!0,composed:!0}))}_onMoveDown(e){e.stopPropagation(),this.canMoveDown&&this.dispatchEvent(new CustomEvent(`move-room-down`,{detail:{areaId:this.area.area_id},bubbles:!0,composed:!0}))}_onHideClick(e){e.stopPropagation(),this.dispatchEvent(new CustomEvent(`hide-room`,{detail:{areaId:this.area.area_id},bubbles:!0,composed:!0}))}};k([y({attribute:!1})],j.prototype,`area`,void 0),k([y({attribute:!1})],j.prototype,`config`,void 0),k([y({type:Number})],j.prototype,`climateEntityCount`,void 0),k([y({type:Number})],j.prototype,`tempSensorCount`,void 0),k([y({attribute:!1})],j.prototype,`hass`,void 0),k([y({type:String})],j.prototype,`controlMode`,void 0),k([y({type:Boolean})],j.prototype,`climateControlActive`,void 0),k([y({type:Boolean})],j.prototype,`reordering`,void 0),k([y({type:Boolean})],j.prototype,`canMoveUp`,void 0),k([y({type:Boolean})],j.prototype,`canMoveDown`,void 0),j=k([v(`rs-area-card`)],j);var jt={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},Mt=e=>(...t)=>({_$litDirective$:e,values:t}),Nt=class{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,n){this._$Ct=e,this._$AM=t,this._$Ci=n}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}};$e();var Pt=class extends Nt{constructor(e){if(super(e),this.it=h,e.type!==jt.CHILD)throw Error(this.constructor.directiveName+`() can only be used in child bindings`)}render(e){if(e===h||e==null)return this._t=void 0,this.it=e;if(e===ze)return e;if(typeof e!=`string`)throw Error(this.constructor.directiveName+`() called with a non-string value`);if(e===this.it)return this._t;this.it=e;let t=[e];return t.raw=t,this._t={_$litType$:this.constructor.resultType,strings:t,values:[]}}};Pt.directiveName=`unsafeHTML`,Pt.resultType=1;var M=Mt(Pt);_(),x(),A();var Ft=class extends g{constructor(...e){super(...e),this.text=``,this.icon=`mdi:information-outline`,this._open=!1,this._style=`visibility: hidden;`,this._onDocPointer=e=>{e.composedPath().includes(this)||this._close()},this._onKey=e=>{e.key===`Escape`&&(e.stopPropagation(),this._close())},this._onScroll=()=>this._close()}disconnectedCallback(){super.disconnectedCallback(),this._removeListeners()}static{this.styles=l`
    :host {
      display: inline-flex;
      position: relative;
      vertical-align: middle;
      line-height: 0;
    }

    button {
      background: none;
      border: none;
      padding: 2px;
      margin: 0;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      color: var(--secondary-text-color);
      opacity: 0.65;
      transition:
        opacity 0.15s,
        color 0.15s,
        background 0.15s;
      border-radius: 50%;
      line-height: 0;
    }

    button:hover,
    button:focus-visible {
      opacity: 1;
      color: var(--primary-color);
      background: rgba(3, 169, 244, 0.1);
      outline: none;
    }

    button.open {
      opacity: 1;
      color: var(--primary-color);
      background: rgba(3, 169, 244, 0.12);
    }

    ha-icon {
      --mdc-icon-size: 16px;
    }

    .tooltip {
      position: fixed;
      z-index: 1100;
      max-width: 280px;
      min-width: 180px;
      width: max-content;
      padding: 10px 12px;
      background: var(--card-background-color, #1f1f1f);
      border: 1px solid var(--divider-color, rgba(255, 255, 255, 0.12));
      border-radius: 8px;
      font-size: 12px;
      font-weight: 400;
      line-height: 1.5;
      letter-spacing: normal;
      text-transform: none;
      color: var(--primary-text-color);
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
      white-space: normal;
      pointer-events: auto;
      animation: tooltip-fade 0.15s ease-out;
    }

    @keyframes tooltip-fade {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }
  `}render(){return m`
      <button
        type="button"
        class=${this._open?`open`:``}
        @click=${this._toggle}
        aria-label="Info"
        aria-expanded=${this._open?`true`:`false`}
      >
        <ha-icon .icon=${this.icon}></ha-icon>
      </button>
      ${this._open?m`<div
            class="tooltip"
            role="tooltip"
            style=${this._style}
            @click=${e=>e.stopPropagation()}
          >
            ${this.text?this.text:h}<slot></slot>
          </div>`:h}
    `}_toggle(e){e.stopPropagation(),this._open?this._close():this._openTooltip()}_openTooltip(){this._open=!0,this._style=`visibility: hidden;`,requestAnimationFrame(()=>{this._positionTooltip()}),setTimeout(()=>{document.addEventListener(`pointerdown`,this._onDocPointer,!0),document.addEventListener(`keydown`,this._onKey,!0),document.addEventListener(`scroll`,this._onScroll,!0),window.addEventListener(`resize`,this._onScroll,!0)},0)}_positionTooltip(){let e=this.renderRoot.querySelector(`.tooltip`),t=this.renderRoot.querySelector(`button`);if(!e||!t)return;let n=t.getBoundingClientRect(),r=e.getBoundingClientRect(),i=window.innerWidth,a=window.innerHeight,o=a-n.bottom,s=n.top,c;c=o>=r.height+8?n.bottom+6:s>=r.height+8?n.top-r.height-6:Math.max(8,(a-r.height)/2);let l=n.left+n.width/2-r.width/2;l=Math.max(8,Math.min(l,i-r.width-8)),this._style=`top: ${c}px; left: ${l}px;`}_close(){this._open&&(this._open=!1,this._style=`visibility: hidden;`,this._removeListeners())}_removeListeners(){document.removeEventListener(`pointerdown`,this._onDocPointer,!0),document.removeEventListener(`keydown`,this._onKey,!0),document.removeEventListener(`scroll`,this._onScroll,!0),window.removeEventListener(`resize`,this._onScroll,!0)}};k([y({type:String})],Ft.prototype,`text`,void 0),k([y({type:String})],Ft.prototype,`icon`,void 0),k([b()],Ft.prototype,`_open`,void 0),k([b()],Ft.prototype,`_style`,void 0),Ft=k([v(`rs-info-icon`)],Ft),_(),x(),A();var It=`M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z`,Lt=`M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z`,N=class extends g{constructor(...e){super(...e),this.config=null,this.climateControlActive=!0,this.isOutdoor=!1,this.overrideInfo=null,this._countdown=``,this._editingName=!1,this._nameInput=``,this._controlModeInfoExpanded=!1}static{this.styles=[Dt,l`
      :host {
        display: block;
      }

      ha-card {
        padding: 28px 24px;
        position: relative;
        overflow: hidden;
      }

      .hero-accent {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
      }

      .hero-accent-heating {
        background: linear-gradient(90deg, var(--warning-color, #ff9800), #ffb74d);
      }

      .hero-accent-cooling {
        background: linear-gradient(90deg, #2196f3, #64b5f6);
      }

      .hero-accent-idle {
        background: linear-gradient(90deg, var(--disabled-text-color, #bdbdbd), #e0e0e0);
      }

      .hero-accent-none {
        background: var(--divider-color, #e0e0e0);
      }

      .hero-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 16px;
      }

      .area-name {
        font-size: 22px;
        font-weight: 400;
        color: var(--primary-text-color);
        margin: 0;
      }

      .hero-temps {
        display: flex;
        align-items: baseline;
        gap: 8px;
      }

      .hero-current {
        font-size: 48px;
        font-weight: 300;
        color: var(--primary-text-color);
        line-height: 1;
      }

      .hero-unit {
        font-size: 24px;
        font-weight: 300;
        color: var(--secondary-text-color);
      }

      .hero-target {
        margin-left: auto;
        text-align: right;
      }

      .hero-target-label {
        font-size: 12px;
        color: var(--secondary-text-color);
        text-transform: uppercase;
        letter-spacing: 0.5px;
      }

      .hero-target-value {
        font-size: 22px;
        font-weight: 400;
        color: var(--primary-text-color);
      }

      /* Override-aware target styling */
      .hero-target-label.override-boost {
        color: var(--warning-color, #ff9800);
      }

      .hero-target-label.override-eco {
        color: #4caf50;
      }

      .hero-target-label.override-custom {
        color: #2196f3;
      }

      .hero-target-label ha-icon {
        --mdc-icon-size: 12px;
        vertical-align: middle;
      }

      .hero-target-countdown {
        font-size: 11px;
        color: var(--secondary-text-color);
        margin-top: 2px;
      }

      .hero-metric {
        display: flex;
        align-items: center;
        gap: 4px;
        font-size: 14px;
        color: var(--secondary-text-color);
        margin-top: 6px;
      }

      .hero-metric ha-icon {
        --mdc-icon-size: 16px;
        flex-shrink: 0;
      }

      .hero-metric.warning {
        color: var(--warning-color, #ff9800);
      }

      .hero-metric.critical {
        color: var(--error-color, #db4437);
      }

      .hero-metric.info {
        color: var(--info-color, #2196f3);
      }

      .hero-no-data {
        font-size: 14px;
        color: var(--disabled-text-color, #9e9e9e);
        font-style: italic;
        padding: 8px 0;
      }

      .hero-window-open {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 6px 10px;
        margin-bottom: 12px;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 500;
        color: var(--warning-color, #ff9800);
        background: rgba(255, 152, 0, 0.1);
      }

      .hero-window-open ha-icon {
        --mdc-icon-size: 18px;
      }

      .name-row {
        display: flex;
        align-items: center;
        gap: 4px;
      }

      .name-edit-btn {
        --mdc-icon-button-size: 28px;
        --mdc-icon-size: 16px;
        color: var(--secondary-text-color);
        opacity: 0;
        transition: opacity 0.15s;
      }

      .name-row:hover .name-edit-btn {
        opacity: 1;
      }

      @media (hover: none) {
        .name-edit-btn {
          opacity: 0.5;
        }
      }

      .name-edit-row {
        display: flex;
        align-items: center;
        gap: 4px;
      }

      .name-input {
        font-size: 22px;
        font-weight: 400;
        color: var(--primary-text-color);
        background: transparent;
        border: none;
        border-bottom: 2px solid var(--primary-color);
        outline: none;
        padding: 0 0 2px;
        width: 100%;
        font-family: inherit;
      }

      .name-done-btn {
        --mdc-icon-button-size: 28px;
        --mdc-icon-size: 16px;
        color: var(--primary-color);
      }

      .name-clear-btn {
        background: none;
        border: none;
        color: var(--secondary-text-color);
        font-size: 12px;
        cursor: pointer;
        padding: 2px 0;
        text-decoration: underline;
      }

      .hero-status-pills {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        gap: 2px;
        flex-shrink: 0;
      }
      .control-mode-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 11px;
        color: var(--secondary-text-color);
        cursor: pointer;
      }
      .control-mode-info-icon {
        --mdc-icon-size: 14px;
        opacity: 0.4;
      }
      .control-mode-badge:hover .control-mode-info-icon,
      .control-mode-info-icon.active {
        opacity: 0.8;
      }
      .control-mode-info-panel {
        padding: 8px 12px;
        margin-bottom: 8px;
        font-size: 12px;
        line-height: 1.5;
        color: var(--secondary-text-color);
        background: var(--secondary-background-color);
        border-radius: 8px;
      }

      .learning-paused rs-info-icon {
        margin-left: 2px;
      }

      .uncontrolled-hint {
        font-size: 12px;
        color: var(--disabled-text-color, #9e9e9e);
        margin-top: 8px;
      }
    `]}disconnectedCallback(){super.disconnectedCallback(),this._clearCountdownTimer()}updated(e){(e.has(`overrideInfo`)||e.has(`config`))&&this._updateCountdown()}_clearCountdownTimer(){this._countdownTimer&&=(clearInterval(this._countdownTimer),void 0)}_getOverrideUntil(){return this.overrideInfo?.active?this.overrideInfo.until:null}_updateCountdown(){if(this._clearCountdownTimer(),!this._getOverrideUntil()){let e=this._getEffectiveOverride();this._countdown=e?S(`hero.permanent`,this.hass?.language??`en`):``;return}let e=()=>{let e=this._getOverrideUntil();if(!e){this._countdown=``,this._clearCountdownTimer();return}let t=e-Date.now()/1e3;if(t<=0){this._countdown=``,this._clearCountdownTimer();return}let n=Math.floor(t/3600),r=Math.floor(t%3600/60);this._countdown=n>0?`${n}h ${r}m`:`${r}m`};e(),this._countdownTimer=setInterval(e,3e4)}_getEffectiveOverride(){return this.overrideInfo?.active?this.overrideInfo:null}_renderTargetSection(e){let t=e.target_temp,n=this.hass?.language??`en`,r=this._getEffectiveOverride();if(r){let e=r.type===`boost`?`mdi:fire`:r.type===`eco`?`mdi:leaf`:`mdi:thermometer`,i=r.type===`boost`?S(`override.comfort`,n):r.type===`eco`?S(`override.eco`,n):S(`override.custom`,n),a=`override-${r.type}`,o=r.temp??t;return m`
        <div class="hero-target">
          <div class="hero-target-label ${a}">
            <ha-icon icon=${e}></ha-icon>
            ${i} ${S(`hero.override`,n)}
          </div>
          <div class="hero-target-value">
            ${o===null?`--`:m`${E(o,this.hass)}${C(this.hass)}`}
          </div>
          ${this._countdown?m`<div class="hero-target-countdown">
                ${S(`hero.remaining`,n,{time:this._countdown})}
              </div>`:h}
        </div>
      `}if(t!==null||e.heat_target!=null&&e.cool_target!=null){let r=(this.config?.climate_mode??`auto`)===`auto`&&e.heat_target!=null&&e.cool_target!=null&&e.heat_target!==e.cool_target?m`${E(e.heat_target,this.hass)} –
          ${E(e.cool_target,this.hass)}${C(this.hass)}`:m`${E(t??e.heat_target,this.hass)}${C(this.hass)}`;return m`
        <div class="hero-target">
          <div class="hero-target-label">${S(`hero.target`,n)}</div>
          <div class="hero-target-value">${r}</div>
        </div>
      `}return h}_toggleControlModeInfo(){this._controlModeInfoExpanded=!this._controlModeInfoExpanded}_onEditName(){this._nameInput=this.config?.display_name||``,this._editingName=!0,this.updateComplete.then(()=>{let e=this.renderRoot.querySelector(`.name-input`);e?.focus(),e?.select()})}_onNameInput(e){this._nameInput=e.target.value}_onNameKeydown(e){e.key===`Enter`?this._onNameDone():e.key===`Escape`&&(this._editingName=!1)}_onNameDone(){let e=this._nameInput.trim();this.dispatchEvent(new CustomEvent(`display-name-changed`,{detail:{value:e},bubbles:!0,composed:!0})),this._editingName=!1}_onNameClear(){this.dispatchEvent(new CustomEvent(`display-name-changed`,{detail:{value:``},bubbles:!0,composed:!0})),this._editingName=!1,this._nameInput=``}render(){let e=this.config?.live,t=e?.mode;return m`
      <ha-card>
        <div class="hero-accent ${e?t===`heating`?`hero-accent-heating`:t===`cooling`?`hero-accent-cooling`:`hero-accent-idle`:`hero-accent-none`}"></div>
        <div class="hero-header">
          ${this._editingName?m`
                <div class="name-edit-row">
                  <input
                    class="name-input"
                    type="text"
                    .value=${this._nameInput}
                    placeholder=${S(`room.alias.placeholder`,this.hass?.language??`en`)}
                    @input=${this._onNameInput}
                    @keydown=${this._onNameKeydown}
                  />
                  <ha-icon-button
                    class="name-done-btn"
                    .path=${Lt}
                    @click=${this._onNameDone}
                  ></ha-icon-button>
                </div>
                ${this.config?.display_name?m`<button class="name-clear-btn" @click=${this._onNameClear}>
                      ${S(`room.alias.clear`,this.hass?.language??`en`)}
                    </button>`:h}
              `:m`
                <div class="name-row">
                  <h2 class="area-name">${this.config?.display_name||this.area.name}</h2>
                  <ha-icon-button
                    class="name-edit-btn"
                    .path=${It}
                    @click=${this._onEditName}
                  ></ha-icon-button>
                </div>
              `}
          ${this.isOutdoor?h:m`
                <div class="hero-status-pills">
                  ${e?m`
                        <span class="mode-pill ${wt(e.mode)}">
                          <span class="mode-dot"></span>
                          ${Et(e.mode,this.hass?.language??`en`)}${e.heating_power>0&&e.heating_power<100?m` ${e.heating_power}%`:h}
                        </span>
                      `:h}
                  ${this.config?m`
                        <span class="control-mode-badge" @click=${this._toggleControlModeInfo}>
                          ${this.config.temperature_sensor?S(`room.control_mode.full_control`,this.hass?.language??`en`):S(`room.control_mode.managed`,this.hass?.language??`en`)}
                          <ha-icon
                            class="control-mode-info-icon ${this._controlModeInfoExpanded?`active`:``}"
                            icon="mdi:information-outline"
                          ></ha-icon>
                        </span>
                      `:h}
                </div>
              `}
        </div>
        ${this._controlModeInfoExpanded&&this.config&&!this.isOutdoor?m`
              <div class="control-mode-info-panel">
                ${this.config.temperature_sensor?S(`room.control_mode.full_control_info`,this.hass?.language??`en`):S(`room.control_mode.managed_info`,this.hass?.language??`en`)}
              </div>
            `:h}
        ${e?m`
              ${e.window_open&&!this.isOutdoor?m`<div class="hero-window-open">
                    <ha-icon icon="mdi:window-open-variant"></ha-icon>
                    ${S(`hero.window_open`,this.hass?.language??`en`)}
                  </div>`:h}
              <div class="hero-temps">
                ${e.current_temp===null?m`<span class="hero-current" style="opacity: 0.3">--</span>`:m`
                      <span class="hero-current">${E(e.current_temp,this.hass)}</span>
                      <span class="hero-unit">${C(this.hass)}</span>
                    `}
                ${this.isOutdoor?h:this._renderTargetSection(e)}
              </div>
              ${e.current_humidity===null?h:m`<div class="hero-metric">
                    <ha-icon icon="mdi:water-percent"></ha-icon>
                    ${S(`hero.humidity`,this.hass?.language??`en`,{value:e.current_humidity.toFixed(0)})}
                  </div>`}
              ${e.perceived_temp!=null&&!this.isOutdoor?m`<div class="hero-metric info">
                    <ha-icon icon="mdi:human-handsup"></ha-icon>
                    ${S(`hero.perceived_temp`,this.hass?.language??`en`,{value:E(e.perceived_temp,this.hass),unit:C(this.hass)})}
                  </div>`:h}
              ${e.night_mode?.active&&!this.isOutdoor?m`<div class="hero-metric warning">
                    <ha-icon icon="mdi:weather-night"></ha-icon>
                    ${S(`hero.night_mode_active`,this.hass?.language??`en`)}
                  </div>`:h}
              ${e.rapid_recovery_active&&!this.isOutdoor?m`<div class="hero-metric warning">
                    <ha-icon icon="mdi:rocket-launch-outline"></ha-icon>
                    ${S(`hero.rapid_recovery_active`,this.hass?.language??`en`)}
                  </div>`:h}
              ${e.device_setpoint!=null&&!this.isOutdoor?m`<div class="hero-metric">
                    <ha-icon
                      icon=${e.mode===`cooling`?`mdi:snowflake`:`mdi:radiator`}
                    ></ha-icon>
                    ${S(`hero.device_setpoint`,this.hass?.language??`en`,{value:E(e.device_setpoint,this.hass),unit:C(this.hass)})}
                  </div>`:h}
              ${e.active_heat_sources&&e.active_heat_sources!==`none`&&!this.isOutdoor?m`<div class="hero-metric">
                    <ha-icon icon="mdi:swap-horizontal"></ha-icon>
                    ${e.active_heat_sources===`primary`?S(`hero.heat_source_primary`,this.hass?.language??`en`):e.active_heat_sources===`secondary`?S(`hero.heat_source_secondary`,this.hass?.language??`en`):S(`hero.heat_source_both`,this.hass?.language??`en`)}
                  </div>`:h}
              ${e.mold_surface_rh!=null&&!this.isOutdoor?m`<div
                    class="hero-metric ${e.mold_risk_level===`critical`?`critical`:e.mold_risk_level===`warning`?`warning`:``}"
                  >
                    <ha-icon icon="mdi:water-alert"></ha-icon>
                    ${S(`room.mold_surface_rh`,this.hass?.language??`en`,{value:String(e.mold_surface_rh.toFixed(0))})}
                  </div>`:h}
              ${e.mold_prevention_active&&!this.isOutdoor?m`<div class="hero-metric info">
                    <ha-icon icon="mdi:shield-check"></ha-icon>
                    ${S(`card.mold_prevention`,this.hass?.language??`en`,{delta:T(e.mold_prevention_delta,this.hass).toFixed(0),unit:C(this.hass)})}
                  </div>`:h}
              ${e.learning_paused_reason===`outdoor_unavailable`&&!this.isOutdoor?m`<div class="hero-metric warning learning-paused">
                    <ha-icon icon="mdi:school-outline"></ha-icon>
                    ${S(`hero.mpc_learning_paused`,this.hass?.language??`en`)}
                    <rs-info-icon
                      icon="mdi:information-outline"
                      .text=${S(`hero.mpc_learning_paused.outdoor_unavailable`,this.hass?.language??`en`)}
                    ></rs-info-icon>
                  </div>`:h}
              ${!this.climateControlActive&&!this.isOutdoor?m`<div class="uncontrolled-hint">
                    ${S(`card.not_controlled`,this.hass?.language??`en`)}
                  </div>`:h}
            `:this.config?m`<div class="hero-no-data">
                ${S(`hero.waiting`,this.hass?.language??`en`)}
              </div>`:m`<div class="hero-no-data">
                ${S(`hero.not_configured`,this.hass?.language??`en`)}
              </div>`}
      </ha-card>
    `}};k([y({attribute:!1})],N.prototype,`hass`,void 0),k([y({attribute:!1})],N.prototype,`area`,void 0),k([y({attribute:!1})],N.prototype,`config`,void 0),k([y({type:Boolean})],N.prototype,`climateControlActive`,void 0),k([y({type:Boolean})],N.prototype,`isOutdoor`,void 0),k([y({attribute:!1})],N.prototype,`overrideInfo`,void 0),k([b()],N.prototype,`_countdown`,void 0),k([b()],N.prototype,`_editingName`,void 0),k([b()],N.prototype,`_nameInput`,void 0),k([b()],N.prototype,`_controlModeInfoExpanded`,void 0),N=k([v(`rs-hero-status`)],N),_(),x(),A();var Rt=class extends g{constructor(...e){super(...e),this.climateMode=`auto`,this.language=`en`}static{this.styles=l`
    :host {
      display: block;
    }

    .mode-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 10px;
    }

    .mode-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
      padding: 14px 8px;
      border: 2px solid var(--divider-color, #e0e0e0);
      border-radius: 12px;
      cursor: pointer;
      transition:
        border-color 0.2s,
        background 0.2s,
        box-shadow 0.2s;
      background: transparent;
      font-family: inherit;
      color: var(--primary-text-color);
      text-align: center;
    }

    .mode-card:hover {
      border-color: var(--primary-color, #03a9f4);
      box-shadow: 0 2px 8px rgba(3, 169, 244, 0.1);
    }

    .mode-card[active] {
      border-color: var(--primary-color, #03a9f4);
      background: rgba(3, 169, 244, 0.06);
      box-shadow: 0 2px 8px rgba(3, 169, 244, 0.12);
    }

    .mode-card-icon {
      --mdc-icon-size: 24px;
    }

    .mode-card[active] .mode-card-icon {
      color: var(--primary-color, #03a9f4);
    }

    .mode-card-label {
      font-weight: 500;
      font-size: 13px;
    }

    .mode-card[active] .mode-card-label {
      color: var(--primary-color, #03a9f4);
    }
  `}render(){let e=this.language;return m`
      <div class="mode-grid">
        ${[{value:`auto`,labelKey:`mode.auto`,icon:`mdi:autorenew`},{value:`heat_only`,labelKey:`mode.heat_only`,icon:`mdi:fire`},{value:`cool_only`,labelKey:`mode.cool_only`,icon:`mdi:snowflake`}].map(t=>m`
            <button
              class="mode-card"
              ?active=${this.climateMode===t.value}
              @click=${()=>this._onModeClick(t.value)}
            >
              <ha-icon class="mode-card-icon" icon=${t.icon}></ha-icon>
              <div class="mode-card-label">${S(t.labelKey,e)}</div>
            </button>
          `)}
      </div>
    `}_onModeClick(e){this.dispatchEvent(new CustomEvent(`mode-changed`,{detail:{mode:e},bubbles:!0,composed:!0}))}};k([y({type:String})],Rt.prototype,`climateMode`,void 0),k([y({type:String})],Rt.prototype,`language`,void 0),Rt=k([v(`rs-climate-mode-selector`)],Rt);function P(e){return e.detail?.value??e.target.value??``}function F(e,t){e.dispatchEvent(new CustomEvent(`save-status`,{detail:{status:t},bubbles:!0,composed:!0}))}function zt(e,t){e.dispatchEvent(new CustomEvent(`hass-more-info`,{bubbles:!0,composed:!0,detail:{entityId:t}}))}_(),x(),A();var Bt=class e extends g{constructor(...e){super(...e),this.activeIndex=-1,this.selectorEntity=``,this.editing=!1}static{this.sharedStyles=l`
    :host {
      display: block;
    }

    .schedule-list {
      display: flex;
      flex-direction: column;
      gap: 8px;
      margin-bottom: 12px;
    }

    .schedule-row {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 14px;
      border-radius: 8px;
      transition:
        background 0.3s,
        opacity 0.3s;
    }

    .schedule-row.active {
      background: rgba(76, 175, 80, 0.1);
    }
    .schedule-row.inactive {
      background: rgba(0, 0, 0, 0.04);
    }
    .schedule-row.unreachable {
      background: rgba(0, 0, 0, 0.02);
      opacity: 0.4;
    }

    .schedule-number {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-size: 12px;
      font-weight: 500;
      width: 20px;
      height: 20px;
      border-radius: 50%;
      background: var(--divider-color, #e0e0e0);
      color: var(--primary-text-color);
      flex-shrink: 0;
    }
    .schedule-row.active .schedule-number {
      background: #4caf50;
      color: #fff;
    }

    .schedule-status-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      flex-shrink: 0;
    }
    .schedule-row.active .schedule-status-dot {
      background: #4caf50;
      box-shadow: 0 0 6px rgba(76, 175, 80, 0.5);
    }
    .schedule-row.inactive .schedule-status-dot {
      background: var(--disabled-text-color, #bdbdbd);
    }
    .schedule-row.unreachable .schedule-status-dot {
      background: var(--disabled-text-color, #bdbdbd);
    }

    .schedule-name {
      flex: 1;
      font-size: 14px;
      font-weight: 500;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .schedule-link {
      cursor: pointer;
    }
    .schedule-link:hover {
      text-decoration: underline;
    }
    .schedule-row.active .schedule-name {
      color: var(--primary-text-color);
    }
    .schedule-row.inactive .schedule-name {
      color: var(--secondary-text-color);
    }
    .schedule-row.unreachable .schedule-name {
      color: var(--secondary-text-color);
    }

    .schedule-status {
      font-size: 12px;
      white-space: nowrap;
    }
    .schedule-row.active .schedule-status {
      color: #2e7d32;
    }
    .schedule-row.inactive .schedule-status {
      color: var(--secondary-text-color);
    }
    .schedule-row.unreachable .schedule-status {
      color: var(--secondary-text-color);
    }

    .schedule-controls {
      display: flex;
      align-items: center;
      gap: 2px;
      flex-shrink: 0;
    }
    .schedule-controls ha-icon-button {
      --mdc-icon-button-size: 28px;
      --mdc-icon-size: 16px;
    }

    .add-schedule-row {
      margin-top: 4px;
    }
    .add-schedule-row ha-select {
      width: 100%;
    }

    .helper-link {
      display: inline-block;
      margin-top: 4px;
      font-size: 12px;
      color: var(--primary-color);
      text-decoration: none;
    }
    .helper-link:hover {
      text-decoration: underline;
    }

    .no-schedules {
      font-size: 13px;
      color: var(--secondary-text-color);
      padding: 12px 0;
      text-align: center;
    }

    .form-label {
      display: block;
      font-size: 13px;
      font-weight: 500;
      color: var(--secondary-text-color);
      margin-bottom: 6px;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }

    .selector-section {
      margin-top: 16px;
    }

    .selector-value {
      font-size: 12px;
      color: var(--secondary-text-color);
      margin-top: 4px;
      padding-left: 4px;
    }

    .selector-warning {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-top: 8px;
      padding: 10px 14px;
      border-radius: 8px;
      background: rgba(255, 152, 0, 0.08);
      color: var(--warning-color, #ff9800);
      font-size: 13px;
    }
    .selector-warning ha-icon {
      --mdc-icon-size: 18px;
      flex-shrink: 0;
    }

    .section-hint {
      font-size: 12px;
      color: var(--secondary-text-color);
      line-height: 1.5;
      margin-bottom: 12px;
    }
  `}static{this.ICON_CLOSE=`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}static{this.ICON_UP=`M7.41,15.41L12,10.83L16.59,15.41L18,14L12,8L6,14L7.41,15.41Z`}static{this.ICON_DOWN=`M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z`}_getScheduleState(e,t){if(t===0)return`inactive`;if(e===this.activeIndex)return`active`;if(!this.selectorEntity)return e===0?`active`:`unreachable`;let n=this.hass?.states?.[this.selectorEntity];if(!n)return`inactive`;if(this.selectorEntity.startsWith(`input_boolean.`))return e<=1?`inactive`:`unreachable`;if(this.selectorEntity.startsWith(`input_number.`)){let r=Number(n.attributes?.min??1),i=Number(n.attributes?.max??t);return e+1>=r&&e+1<=i?`inactive`:`unreachable`}return`inactive`}_getAvailableEntities(e){return this.hass?.states?Object.keys(this.hass.states).filter(t=>t.startsWith(`schedule.`)&&!e.has(t)):[]}_getFriendlyName(e){return this.hass?.states?.[e]?.attributes?.friendly_name||e}_renderAddRow(e,t,n,r){return m`
      <div class="add-schedule-row">
        <ha-select
          .value=${``}
          .label=${e}
          .options=${t.map(e=>({value:e,label:this._getFriendlyName(e)}))}
          @selected=${e=>{let t=P(e);t&&(n(t),requestAnimationFrame(()=>{e.target.value=``}))}}
          @closed=${e=>e.stopPropagation()}
          fixedMenuPosition
          naturalMenuWidth
        >
          ${t.map(e=>m`
              <ha-list-item value=${e}>${this._getFriendlyName(e)}</ha-list-item>
            `)}
        </ha-select>
        <a href="/config/helpers" target="_top" class="helper-link"> ${r} </a>
      </div>
    `}_renderSelectorSection(e,t,n,r,i){if(e<2)return h;let a=this.selectorEntity?this.hass?.states?.[this.selectorEntity]:null;return m`
      <div class="selector-section">
        <label class="form-label">${t}</label>
        <ha-entity-picker
          .hass=${this.hass}
          .value=${this.selectorEntity}
          .includeDomains=${[`input_boolean`,`input_number`]}
          allow-custom-entity
          @value-changed=${e=>{e.stopPropagation(),i(e.detail?.value??``)}}
        ></ha-entity-picker>
        ${this.selectorEntity&&a?m`
              <div class="selector-value">
                ${this.selectorEntity.startsWith(`input_boolean.`)?S(`schedule.selector_value_boolean`,this.hass.language,{value:a.state===`on`?`On`:`Off`}):S(`schedule.selector_value_number`,this.hass.language,{value:a.state})}
              </div>
            `:h}
        <div class="section-hint" style="margin-top:4px">${n}</div>
        ${e>1&&!this.selectorEntity?m`
              <div class="selector-warning">
                <ha-icon icon="mdi:alert-outline"></ha-icon>
                ${r}
              </div>
            `:h}
      </div>
    `}_renderScheduleControls(t,n,r,i){let a=n>=2;return m`
      <span class="schedule-controls">
        ${a&&t>0?m`
              <ha-icon-button
                .path=${e.ICON_UP}
                @click=${()=>r(t,-1)}
              ></ha-icon-button>
            `:h}
        ${a&&t<n-1?m`
              <ha-icon-button
                .path=${e.ICON_DOWN}
                @click=${()=>r(t,1)}
              ></ha-icon-button>
            `:h}
        <ha-icon-button
          .path=${e.ICON_CLOSE}
          @click=${()=>i(t)}
        ></ha-icon-button>
      </span>
    `}_openEntityInfo(e){zt(this,e)}};k([y({attribute:!1})],Bt.prototype,`hass`,void 0),k([y({type:Number})],Bt.prototype,`activeIndex`,void 0),k([y({type:String})],Bt.prototype,`selectorEntity`,void 0),k([y({type:Boolean})],Bt.prototype,`editing`,void 0),_();var I=l`
  ha-textfield,
  ha-select,
  ha-entity-picker,
  ha-combo-box {
    --mdc-shape-small: 8px;
    --mdc-shape-medium: 8px;
    --md-filled-text-field-container-shape: 8px;
    --md-outlined-text-field-container-shape: 8px;
    display: block;
    border-radius: 8px;
    overflow: hidden;
    isolation: isolate;
    /* clip-path is more reliable than overflow:hidden for shape clipping
       on the bottom corners of MDC filled inputs. */
    clip-path: inset(0 round 8px);
  }

  /* ha-entity-picker wraps an inner ha-combo-box that doesn't always
     reach the host's bottom edge. Use a tighter clip so the visible
     input's bottom matches the inner's top radius. */
  ha-entity-picker {
    clip-path: inset(0 round 8px 8px 4px 4px);
  }
`;_(),x(),A();var L=class extends Bt{constructor(...e){super(...e),this.schedules=[],this.comfortHeat=21,this.comfortCool=24,this.ecoHeat=17,this.ecoCool=27,this.climateMode=`auto`}set scheduleSelectorEntity(e){this.selectorEntity=e}get scheduleSelectorEntity(){return this.selectorEntity}set activeScheduleIndex(e){this.activeIndex=e}get activeScheduleIndex(){return this.activeIndex}static{this.styles=[Bt.sharedStyles,I,l`
      .fallback-hint {
        font-size: 11px;
        color: var(--secondary-text-color);
        margin-top: 4px;
        font-style: italic;
      }

      .temp-inputs {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
        margin-top: 16px;
      }

      .temp-input-group {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      ha-textfield {
        flex: 1;
      }

      .view-temps {
        display: flex;
        gap: 16px;
        font-size: 13px;
        color: var(--secondary-text-color);
        margin-top: 12px;
        padding-top: 12px;
        border-top: 1px solid var(--divider-color, #eee);
      }

      .view-temps span {
        font-weight: 500;
        color: var(--primary-text-color);
      }

      .view-selector-info {
        font-size: 12px;
        color: var(--secondary-text-color);
        margin-top: 8px;
      }

      .temp-grid-auto {
        display: grid;
        grid-template-columns: auto 1fr 1fr;
        gap: 8px 12px;
        align-items: center;
        margin-top: 16px;
      }
      .temp-grid-header {
        font-size: 12px;
        font-weight: 600;
        color: var(--secondary-text-color);
        text-transform: uppercase;
        letter-spacing: 0.3px;
        text-align: center;
      }
      .temp-grid-row-label {
        display: flex;
        align-items: center;
        gap: 4px;
        font-size: 13px;
        font-weight: 500;
        color: var(--secondary-text-color);
        white-space: nowrap;
      }

      @media (max-width: 600px) {
        .temp-grid-auto {
          grid-template-columns: 1fr 1fr;
        }
        .temp-grid-row-label {
          grid-column: 1 / -1;
          margin-top: 8px;
        }
        .temp-grid-header {
          display: none;
        }
      }
    `]}render(){return this.editing?this._renderEditMode():this._renderViewMode()}_renderViewMode(){let e=this.hass.language,t=this.schedules.length>=2;return m`
      ${this.schedules.length>0?m`
            <div class="schedule-list">
              ${this.schedules.map((e,n)=>{let r=this._getScheduleState(n,this.schedules.length);return m`
                  <div class="schedule-row ${r}">
                    ${t?m`<span class="schedule-number">${n+1}</span>`:h}
                    <span class="schedule-status-dot"></span>
                    <span
                      class="schedule-name schedule-link"
                      @click=${()=>this._openEntityInfo(e.entity_id)}
                      >${this._getFriendlyName(e.entity_id)}</span
                    >
                    <span class="schedule-status">${this._getStatusText(n,r)}</span>
                  </div>
                `})}
            </div>
          `:m`<div class="no-schedules">${S(`schedule.no_schedules`,e)}</div>`}
      ${this.climateMode===`auto`?m`
            <div class="view-temps">
              ${S(`schedule.view_heat`,e,{comfort:E(this.comfortHeat,this.hass),eco:E(this.ecoHeat,this.hass),unit:C(this.hass)})}
               · 
              ${S(`schedule.view_cool`,e,{comfort:E(this.comfortCool,this.hass),eco:E(this.ecoCool,this.hass),unit:C(this.hass)})}
            </div>
          `:m`
            <div class="view-temps">
              ${S(`schedule.view_comfort`,e,{temp:E(this.climateMode===`cool_only`?this.comfortCool:this.comfortHeat,this.hass),unit:C(this.hass)})}
               · 
              ${S(`schedule.view_eco`,e,{temp:E(this.climateMode===`cool_only`?this.ecoCool:this.ecoHeat,this.hass),unit:C(this.hass)})}
            </div>
          `}
      ${this.scheduleSelectorEntity?m`<div class="view-selector-info">
            ${S(`schedule.view_selector_prefix`,e)}
            <span
              class="schedule-link"
              @click=${()=>this._openEntityInfo(this.scheduleSelectorEntity)}
              >${this._getFriendlyName(this.scheduleSelectorEntity)}</span
            >
          </div>`:h}
    `}_renderEditMode(){let e=this.hass.language,t=this.schedules.length,n=new Set(this.schedules.map(e=>e.entity_id));return m`
      ${this._renderScheduleList()}
      ${this._renderAddRow(S(`schedule.select_schedule`,e),this._getAvailableEntities(n),e=>this._addSchedule(e),S(`schedule.create_helper_hint`,e))}
      ${this._renderSelectorSection(t,S(`schedule.selector_label`,e),this.scheduleSelectorEntity?this._getSelectorValueText(e):``,S(`schedule.selector_warning`,e),e=>this._onSelectorEntityChange(e))}
      ${this._renderTemperatureInputs(e)}
    `}_renderScheduleList(){let e=this.hass.language,t=this.schedules.length;return t===0?m`<div class="no-schedules">${S(`schedule.no_schedules`,e)}</div>`:m`
      <div class="schedule-list">
        ${this.schedules.map((e,n)=>{let r=this._getScheduleState(n,t);return m`
            <div class="schedule-row ${r}">
              ${t>=2?m`<span class="schedule-number">${n+1}</span>`:h}
              <span class="schedule-status-dot"></span>
              <span class="schedule-name">${this._getFriendlyName(e.entity_id)}</span>
              <span class="schedule-status">${this._getStatusText(n,r)}</span>
              ${this._renderScheduleControls(n,t,(e,t)=>this._moveSchedule(e,t),e=>this._removeSchedule(e))}
            </div>
          `})}
      </div>
    `}_renderTemperatureInputs(e){return this.climateMode===`auto`?m`
        <div class="temp-grid-auto">
          <div class="temp-grid-header"></div>
          <div class="temp-grid-header">${S(`schedule.column_comfort`,e)}</div>
          <div class="temp-grid-header">${S(`schedule.column_eco`,e)}</div>
          <div class="temp-grid-row-label">
            <ha-icon icon="mdi:fire" style="--mdc-icon-size:16px"></ha-icon>
            ${S(`schedule.row_heat`,e)}
          </div>
          <ha-textfield
            type="number"
            .value=${String(w(this.comfortHeat,this.hass))}
            suffix=${C(this.hass)}
            step=${D(this.hass)}
            min=${O(5,35,this.hass).min}
            max=${O(5,35,this.hass).max}
            @change=${this._onComfortHeatChange}
          ></ha-textfield>
          <ha-textfield
            type="number"
            .value=${String(w(this.ecoHeat,this.hass))}
            suffix=${C(this.hass)}
            step=${D(this.hass)}
            min=${O(5,35,this.hass).min}
            max=${O(5,35,this.hass).max}
            @change=${this._onEcoHeatChange}
          ></ha-textfield>
          <div class="temp-grid-row-label">
            <ha-icon icon="mdi:snowflake" style="--mdc-icon-size:16px"></ha-icon>
            ${S(`schedule.row_cool`,e)}
          </div>
          <ha-textfield
            type="number"
            .value=${String(w(this.comfortCool,this.hass))}
            suffix=${C(this.hass)}
            step=${D(this.hass)}
            min=${O(5,35,this.hass).min}
            max=${O(5,35,this.hass).max}
            @change=${this._onComfortCoolChange}
          ></ha-textfield>
          <ha-textfield
            type="number"
            .value=${String(w(this.ecoCool,this.hass))}
            suffix=${C(this.hass)}
            step=${D(this.hass)}
            min=${O(5,35,this.hass).min}
            max=${O(5,35,this.hass).max}
            @change=${this._onEcoCoolChange}
          ></ha-textfield>
        </div>
      `:m`
      <div class="temp-inputs">
        <div class="temp-input-group">
          <ha-textfield
            type="number"
            label=${S(`schedule.comfort_label`,e)}
            suffix=${C(this.hass)}
            step=${D(this.hass)}
            .value=${String(w(this.climateMode===`cool_only`?this.comfortCool:this.comfortHeat,this.hass))}
            min=${O(5,35,this.hass).min}
            max=${O(5,35,this.hass).max}
            @change=${this.climateMode===`cool_only`?this._onComfortCoolChange:this._onComfortHeatChange}
          ></ha-textfield>
        </div>
        <div class="temp-input-group">
          <ha-textfield
            type="number"
            label=${S(`schedule.eco_label`,e)}
            suffix=${C(this.hass)}
            step=${D(this.hass)}
            .value=${String(w(this.climateMode===`cool_only`?this.ecoCool:this.ecoHeat,this.hass))}
            min=${O(5,35,this.hass).min}
            max=${O(5,35,this.hass).max}
            @change=${this.climateMode===`cool_only`?this._onEcoCoolChange:this._onEcoHeatChange}
          ></ha-textfield>
        </div>
      </div>
      <div class="fallback-hint">${S(`schedule.comfort_hint`,e)}</div>
    `}_getSelectorValueText(e){let t=this.hass?.states?.[this.scheduleSelectorEntity];return t?this.scheduleSelectorEntity.startsWith(`input_boolean.`)?S(`schedule.selector_value_boolean`,e,{value:t.state===`on`?`On`:`Off`}):S(`schedule.selector_value_number`,e,{value:t.state}):``}_getStatusText(e,t){let n=this.hass.language;if(t===`unreachable`)return S(`schedule.state_unreachable`,n);if(t===`inactive`)return S(`schedule.state_inactive`,n);let r=this.schedules[e],i=this.hass?.states?.[r.entity_id];if(!i)return S(`schedule.state_active`,n);if(i.state===`on`){let e=i.attributes??{},t=e.temperature;if(t!=null)return S(`schedule.from_schedule`,n,{temp:String(t),unit:C(this.hass)});let r=e.heat_temperature,a=e.cool_temperature;return r!=null||a!=null?S(`schedule.from_schedule_split`,n,{heat:String(r??this.comfortHeat),cool:String(a??this.comfortCool),unit:C(this.hass)}):S(`schedule.fallback`,n,{temp:E(this.climateMode===`cool_only`?this.comfortCool:this.comfortHeat,this.hass),unit:C(this.hass)})}return S(`schedule.eco_detail`,n,{temp:E(this.climateMode===`cool_only`?this.ecoCool:this.ecoHeat,this.hass),unit:C(this.hass)})}_addSchedule(e){this._emitSchedules([...this.schedules,{entity_id:e}])}_removeSchedule(e){this._emitSchedules(this.schedules.filter((t,n)=>n!==e))}_moveSchedule(e,t){let n=e+t;if(n<0||n>=this.schedules.length)return;let r=[...this.schedules];[r[e],r[n]]=[r[n],r[e]],this._emitSchedules(r)}_emitSchedules(e){this.dispatchEvent(new CustomEvent(`schedules-changed`,{detail:{value:e},bubbles:!0,composed:!0}))}_onSelectorEntityChange(e){this.dispatchEvent(new CustomEvent(`schedule-selector-changed`,{detail:{value:e},bubbles:!0,composed:!0}))}_onComfortHeatChange(e){let t=e.target,n=At(parseFloat(t.value)||w(21,this.hass),this.hass);this.dispatchEvent(new CustomEvent(`comfort-heat-changed`,{detail:{value:n},bubbles:!0,composed:!0})),this.comfortCool<n&&this.dispatchEvent(new CustomEvent(`comfort-cool-changed`,{detail:{value:n},bubbles:!0,composed:!0}))}_onComfortCoolChange(e){let t=e.target,n=At(parseFloat(t.value)||w(24,this.hass),this.hass);this.dispatchEvent(new CustomEvent(`comfort-cool-changed`,{detail:{value:n},bubbles:!0,composed:!0})),this.comfortHeat>n&&this.dispatchEvent(new CustomEvent(`comfort-heat-changed`,{detail:{value:n},bubbles:!0,composed:!0}))}_onEcoHeatChange(e){let t=e.target,n=At(parseFloat(t.value)||w(17,this.hass),this.hass);this.dispatchEvent(new CustomEvent(`eco-heat-changed`,{detail:{value:n},bubbles:!0,composed:!0})),this.ecoCool<n&&this.dispatchEvent(new CustomEvent(`eco-cool-changed`,{detail:{value:n},bubbles:!0,composed:!0}))}_onEcoCoolChange(e){let t=e.target,n=At(parseFloat(t.value)||w(27,this.hass),this.hass);this.dispatchEvent(new CustomEvent(`eco-cool-changed`,{detail:{value:n},bubbles:!0,composed:!0})),this.ecoHeat>n&&this.dispatchEvent(new CustomEvent(`eco-heat-changed`,{detail:{value:n},bubbles:!0,composed:!0}))}};k([y({attribute:!1})],L.prototype,`schedules`,void 0),k([y({type:String})],L.prototype,`scheduleSelectorEntity`,null),k([y({type:Number})],L.prototype,`activeScheduleIndex`,null),k([y({type:Number})],L.prototype,`comfortHeat`,void 0),k([y({type:Number})],L.prototype,`comfortCool`,void 0),k([y({type:Number})],L.prototype,`ecoHeat`,void 0),k([y({type:Number})],L.prototype,`ecoCool`,void 0),k([y({type:String})],L.prototype,`climateMode`,void 0),L=k([v(`rs-schedule-settings`)],L);var Vt={underfloor:2,radiator:1,"":0};function Ht(e){let t=``;for(let n of e){if(n.type!==`trv`)continue;let e=n.heating_system_type??``;(Vt[e]??0)>(Vt[t]??0)&&(t=e)}return t}_();var Ut=l`
  .master {
    display: flex;
    flex-direction: column;
    gap: 12px;
    min-width: 0;
  }

  .master-list {
    display: flex;
    flex-direction: column;
    gap: 4px;
    min-width: 0;
  }

  .master-row {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 10px;
    border-radius: 10px;
    cursor: pointer;
    transition:
      background 0.15s,
      border-color 0.15s;
    border: 1px solid transparent;
    min-width: 0;
  }

  .master-row:hover {
    background: rgba(255, 255, 255, 0.03);
  }

  .master-row.focused {
    background: rgba(3, 169, 244, 0.08);
    border-color: rgba(3, 169, 244, 0.5);
  }

  .master-row ha-checkbox {
    flex-shrink: 0;
    margin-left: -8px;
  }

  .master-info {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .master-name-row {
    display: flex;
    align-items: center;
    gap: 6px;
    min-width: 0;
  }

  .master-name {
    font-size: 14px;
    font-weight: 450;
    color: var(--primary-text-color);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    min-width: 0;
  }

  .master-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
  }

  .type-pill,
  .meta-pill {
    display: inline-block;
    font-size: 10px;
    font-weight: 500;
    padding: 1px 8px;
    border-radius: 8px;
    letter-spacing: 0.3px;
    text-transform: uppercase;
    color: var(--secondary-text-color);
    background: rgba(255, 255, 255, 0.05);
  }

  .type-pill {
    color: var(--primary-color);
    background: rgba(3, 169, 244, 0.12);
  }

  .external-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: 10px;
    font-weight: 500;
    color: var(--warning-color, #ff9800);
    background: rgba(255, 152, 0, 0.1);
    padding: 2px 8px;
    border-radius: 10px;
    letter-spacing: 0.3px;
    text-transform: uppercase;
    flex-shrink: 0;
  }

  .detail-panel {
    display: flex;
    flex-direction: column;
    gap: 12px;
    padding: 12px 16px;
    background: rgba(255, 255, 255, 0.02);
    border: 1px solid var(--divider-color, rgba(255, 255, 255, 0.08));
    border-radius: 12px;
    min-width: 0;
    min-height: 200px;
  }

  .empty-detail {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 10px;
    flex: 1;
    min-height: 180px;
    color: var(--secondary-text-color);
    font-size: 13px;
    font-style: italic;
    opacity: 0.7;
    text-align: center;
  }

  .empty-detail ha-icon {
    --mdc-icon-size: 28px;
    opacity: 0.6;
  }

  .detail-head {
    display: flex;
    flex-direction: column;
    gap: 2px;
    padding-bottom: 6px;
    border-bottom: 1px solid var(--divider-color, rgba(255, 255, 255, 0.06));
  }

  .detail-title {
    font-size: 15px;
    font-weight: 500;
    color: var(--primary-text-color);
  }

  .detail-entity-id {
    font-family: var(--code-font-family, monospace);
    font-size: 11px;
    color: var(--secondary-text-color);
    opacity: 0.7;
  }

  .detail-field {
    display: flex;
    flex-direction: column;
  }

  .detail-field ha-select {
    width: 100%;
  }

  .detail-field.with-info {
    flex-direction: row;
    align-items: center;
    gap: 6px;
  }

  .detail-field.with-info ha-select,
  .detail-field.with-info ha-textfield {
    flex: 1;
    min-width: 0;
  }

  .detail-field.with-info rs-info-icon {
    flex-shrink: 0;
  }

  .detail-hint {
    font-size: 12px;
    color: var(--secondary-text-color);
    line-height: 1.5;
  }

  .detail-toggle-row {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 8px 0;
  }

  .detail-toggle-row ha-checkbox {
    margin-top: -8px;
    margin-left: -8px;
  }

  .detail-toggle-label {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 14px;
    color: var(--primary-text-color);
  }

  .detail-toggle-label ha-icon {
    --mdc-icon-size: 16px;
    color: var(--secondary-text-color);
  }

  .inline-hint {
    margin-top: 2px;
  }

  .block {
    margin-top: 4px;
  }

  .block-divider {
    height: 1px;
    background: var(--divider-color, rgba(255, 255, 255, 0.08));
    margin: 16px 0 8px;
  }

  .block-title {
    font-size: 12px;
    font-weight: 500;
    color: var(--secondary-text-color);
    text-transform: uppercase;
    letter-spacing: 0.4px;
    margin-bottom: 8px;
  }

  .empty-list {
    color: var(--secondary-text-color);
    font-size: 13px;
    font-style: italic;
    padding: 12px 14px;
  }

  ha-entity-picker {
    width: 100%;
  }

  .picker-wrap {
    margin-top: 8px;
  }
`;_(),x(),A();var Wt=class extends g{constructor(...e){super(...e),this.masterWidth=`260px`,this.breakpoint=720}static{this.styles=l`
    :host {
      display: block;
      container-type: inline-size;
    }

    .wrap {
      display: grid;
      grid-template-columns: var(--rs-master-width, 260px) minmax(0, 1fr);
      gap: 20px;
      align-items: start;
    }

    @container (max-width: 720px) {
      .wrap {
        grid-template-columns: minmax(0, 1fr);
      }
    }

    /* Fallback for browsers without container queries */
    @media (max-width: 720px) {
      .wrap {
        grid-template-columns: minmax(0, 1fr);
      }
    }

    ::slotted([slot="master"]) {
      min-width: 0;
    }

    ::slotted([slot="detail"]) {
      min-width: 0;
    }
  `}render(){return m`
      <div class="wrap" style="--rs-master-width: ${this.masterWidth};">
        <div class="master"><slot name="master"></slot></div>
        <div class="detail"><slot name="detail"></slot></div>
      </div>
    `}};k([y({type:String})],Wt.prototype,`masterWidth`,void 0),k([y({type:Number})],Wt.prototype,`breakpoint`,void 0),Wt=k([v(`rs-master-detail`)],Wt),_(),x(),A();var R=class extends g{constructor(...e){super(...e),this.devices=[],this.selectedTempSensor=``,this.valveProtectionExclude=new Set,this.valveProtectionEnabled=!1,this.editing=!1,this._systemTypeInfoExpanded=!1,this._showBoostHint=!1,this._selectedThermostats=new Set,this._selectedCoolingDevices=new Set,this._heatingSystemType=``,this._selectedForEdit=``,this._entityFilter=e=>{let t=e.entity_id;return t.substring(t.indexOf(`.`)+1).startsWith(`roommind_`)||this.devices.some(e=>e.entity_id===t)?!1:t.startsWith(`climate.`)}}willUpdate(e){if(e.has(`devices`)){this._selectedThermostats=new Set(this.devices.filter(e=>e.type===`trv`).map(e=>e.entity_id)),this._selectedCoolingDevices=new Set(this.devices.filter(e=>e.type===`ac`).map(e=>e.entity_id)),this._heatingSystemType=Ht(this.devices);let e=new Set(this.devices.map(e=>e.entity_id));this._selectedForEdit&&!e.has(this._selectedForEdit)&&(this._selectedForEdit=``),!this._selectedForEdit&&this.devices.length>0&&(this._selectedForEdit=this.devices[0].entity_id)}}static{this.styles=[Ut,I,l`
      :host {
        display: block;
      }

      .section-subtitle {
        font-size: 12px;
        font-weight: 500;
        color: var(--secondary-text-color);
        margin: 12px 0 8px 0;
        text-transform: uppercase;
        letter-spacing: 0.4px;
      }

      .section-subtitle:first-child {
        margin-top: 0;
      }

      .device-group {
        padding: 4px 0;
      }

      .device-group + .device-group {
        margin-top: 8px;
        padding-top: 12px;
        border-top: 1px solid var(--divider-color, #eee);
      }

      .device-list-scroll {
        max-height: 168px;
        overflow-y: auto;
        overflow-x: hidden;
        scrollbar-width: thin;
      }

      /* Device rows */
      .device-row {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 8px 14px;
        font-size: 14px;
        color: var(--primary-text-color);
        border-radius: 10px;
        margin-bottom: 2px;
        transition: background 0.15s;
      }

      .device-row:last-child {
        margin-bottom: 0;
      }

      .device-row:hover {
        background: rgba(0, 0, 0, 0.02);
      }

      .device-row.selected {
        background: rgba(3, 169, 244, 0.035);
      }

      .device-row ha-checkbox,
      .device-row ha-radio {
        flex-shrink: 0;
      }

      .device-info {
        flex: 1;
        min-width: 0;
      }

      .device-name-row {
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .device-name {
        font-size: 14px;
        font-weight: 450;
        color: var(--primary-text-color);
      }

      .device-value {
        margin-left: auto;
        font-size: 14px;
        font-weight: 500;
        color: var(--primary-text-color);
        flex-shrink: 0;
      }

      .device-entity {
        font-family: var(--code-font-family, monospace);
        font-size: 11px;
        color: var(--secondary-text-color);
        margin-top: 2px;
        opacity: 0.7;
      }

      .external-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 10px;
        font-weight: 500;
        color: var(--warning-color, #ff9800);
        background: rgba(255, 152, 0, 0.1);
        padding: 2px 8px;
        border-radius: 10px;
        letter-spacing: 0.3px;
        text-transform: uppercase;
        flex-shrink: 0;
      }

      .device-type-select {
        flex-shrink: 0;
        --ha-select-min-width: 90px;
      }

      .no-devices {
        color: var(--secondary-text-color);
        font-size: 13px;
        font-style: italic;
        padding: 12px 14px;
      }

      .entity-picker-wrap {
        margin-top: 12px;
        padding-top: 12px;
        border-top: 1px solid var(--divider-color, #eee);
      }

      .subtitle-row {
        display: flex;
        align-items: center;
        gap: 4px;
      }

      .info-icon {
        --mdc-icon-size: 16px;
        color: var(--secondary-text-color);
        cursor: pointer;
        opacity: 0.6;
      }
      .info-icon:hover,
      .info-icon.info-active {
        opacity: 1;
        color: var(--primary-color);
      }

      .system-type-info {
        font-size: 12px;
        line-height: 1.5;
        color: var(--secondary-text-color);
        padding: 8px 14px 4px;
      }

      .boost-hint {
        display: flex;
        align-items: flex-start;
        gap: 8px;
        margin-top: 8px;
        padding: 8px 12px;
        background: rgba(var(--rgb-primary-color, 3, 169, 244), 0.08);
        border-radius: 8px;
        font-size: 13px;
        color: var(--primary-text-color);
        line-height: 1.4;
        --mdc-icon-size: 18px;
      }
      .boost-hint ha-icon {
        color: var(--primary-color);
        flex-shrink: 0;
        margin-top: 1px;
      }

      .idle-action-row {
        display: flex;
        gap: 12px;
        padding: 4px 14px 4px 42px;
      }

      .idle-action-row ha-select {
        flex: 1;
        min-width: 0;
      }

      .setpoint-mode-row {
        display: flex;
        gap: 12px;
        padding: 4px 14px 4px 42px;
      }

      .setpoint-mode-row ha-select {
        flex: 1;
        min-width: 0;
      }

      .setpoint-mode-hint {
        font-size: 12px;
        color: var(--secondary-text-color);
        padding: 2px 14px 4px 42px;
      }

      .valve-exclude-row {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 2px 14px 2px 42px;
        font-size: 12px;
        color: var(--secondary-text-color);
      }

      .valve-exclude-row ha-icon {
        --mdc-icon-size: 14px;
        color: var(--secondary-text-color);
      }

      .valve-exclude-row ha-checkbox {
        --mdc-checkbox-unchecked-color: var(--secondary-text-color);
        margin: -8px -4px -8px -8px;
      }

      .valve-exclude-badge {
        display: inline-flex;
        align-items: center;
        gap: 3px;
        font-size: 10px;
        font-weight: 500;
        color: var(--secondary-text-color);
        background: var(--secondary-background-color);
        padding: 2px 6px;
        border-radius: 8px;
        --mdc-icon-size: 12px;
      }

      /* View mode styles */
      .view-row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 8px 14px;
        font-size: 14px;
        color: var(--primary-text-color);
      }

      .view-name {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .entity-link {
        cursor: pointer;
      }

      .entity-link:hover {
        text-decoration: underline;
      }

      .view-value {
        font-weight: 500;
        flex-shrink: 0;
      }
    `]}render(){return this.editing?this._renderEditMode():this._renderViewMode()}_renderViewMode(){return m`
      ${this._selectedThermostats.size>0||this._selectedCoolingDevices.size>0?m`
            <div class="device-group">
              <div class="section-subtitle">
                ${S(`devices.climate_entities`,this.hass.language)}
              </div>
              ${[...this._selectedThermostats].map(e=>this._renderViewRow(e,`climate`))}
              ${[...this._selectedCoolingDevices].map(e=>this._renderViewRow(e,`climate`))}
            </div>
          `:h}
      ${this._heatingSystemType?m`
            <div class="device-group">
              <div class="section-subtitle">
                ${S(`devices.heating_system_type`,this.hass.language)}
              </div>
              <div class="view-row">
                <span class="view-name"
                  >${this._heatingSystemType===`radiator`?S(`devices.system_type_radiator`,this.hass.language):this._heatingSystemType===`underfloor`?S(`devices.system_type_underfloor`,this.hass.language):this._heatingSystemType}</span
                >
              </div>
            </div>
          `:h}
    `}_renderViewRow(e,t){let n=this.hass.states[e],r=n?.attributes?.friendly_name||e,i=n?.state,a=n?.attributes??{},o=``;if(t===`climate`){let e=a.current_temperature;e!=null&&(o=`${e.toFixed(1)}${C(this.hass)}`)}else if(t===`temp`){let t=e.startsWith(`climate.`)?a.current_temperature:i;t!=null&&t!==``&&t!==`unknown`&&t!==`unavailable`&&(o=`${Number(t).toFixed(1)}${C(this.hass)}`)}else i&&i!==`unknown`&&i!==`unavailable`&&(o=`${Math.round(Number(i))}%`);let s=t===`climate`&&this.valveProtectionEnabled&&this.valveProtectionExclude.has(e),c=t===`climate`?this.devices.find(t=>t.entity_id===e):void 0,l=c?.idle_action===`fan_only`||c?.idle_action===`setback`||c?.idle_action===`low`,u=c?.setpoint_mode===`direct`&&!!this.selectedTempSensor;return m`
      <div class="view-row">
        <span class="view-name entity-link" @click=${()=>zt(this,e)}
          >${r}</span
        >
        ${l?m`<span class="valve-exclude-badge">
              ${c.idle_action===`fan_only`?m`${S(`devices.idle_action_fan_only`,this.hass.language)}${c.idle_fan_mode?` (${c.idle_fan_mode})`:h}`:c.idle_action===`low`?S(`devices.idle_action_low`,this.hass.language):S(`devices.idle_action_setback`,this.hass.language)}
            </span>`:h}
        ${u?m`<span class="valve-exclude-badge">
              ${S(`devices.setpoint_mode_direct`,this.hass.language)}
            </span>`:h}
        ${s?m`<span class="valve-exclude-badge">
              <ha-icon icon="mdi:shield-off-outline"></ha-icon>
              ${S(`devices.valve_protection_excluded`,this.hass.language)}
            </span>`:h}
        ${o?m`<span class="view-value">${o}</span>`:h}
      </div>
    `}_renderEditMode(){let e=Ct(this.area.area_id,this.hass?.entities,this.hass?.devices).filter(e=>!e.entity_id.substring(e.entity_id.indexOf(`.`)+1).startsWith(`roommind_`)).filter(e=>e.entity_id.startsWith(`climate.`)),t=new Set(e.map(e=>e.entity_id)),n=new Set(this.devices.map(e=>e.entity_id)),r=[...n].filter(e=>!t.has(e)),i=e=>n.has(e),a=this._selectedForEdit;return m`
      <rs-master-detail>
        <div slot="master" class="master">
          <div class="section-subtitle">
            ${S(`devices.climate_entities`,this.hass.language)}
          </div>
          <div class="master-list">
            ${e.length>0?e.map(e=>this._renderMasterRow(e.entity_id,!1)):m`<div class="no-devices">
                  ${S(`devices.no_climate`,this.hass.language)}
                </div>`}
            ${r.map(e=>this._renderMasterRow(e,!0))}
          </div>
          <div class="entity-picker-wrap">
            <ha-entity-picker
              .hass=${this.hass}
              .includeDomains=${[`climate`]}
              .entityFilter=${this._entityFilter}
              .value=${``}
              label=${S(`devices.add_entity`,this.hass.language)}
              @value-changed=${this._onEntityPicked}
            ></ha-entity-picker>
          </div>
        </div>

        <div slot="detail" class="detail-panel">
          ${a&&i(a)?this._renderDeviceDetail(a):m`<div class="empty-detail">
                <ha-icon icon="mdi:gesture-tap"></ha-icon>
                <span>${S(`devices.select_to_configure`,this.hass.language)}</span>
              </div>`}
        </div>
      </rs-master-detail>

      ${this._selectedThermostats.size>0?m`
            <div class="block-divider"></div>
            <div class="block">
              <div class="subtitle-row">
                <div class="section-subtitle">
                  ${S(`devices.heating_system_type`,this.hass.language)}
                </div>
                <ha-icon
                  class="info-icon ${this._systemTypeInfoExpanded?`info-active`:``}"
                  icon="mdi:information-outline"
                  @click=${()=>{this._systemTypeInfoExpanded=!this._systemTypeInfoExpanded}}
                ></ha-icon>
              </div>
              ${this._systemTypeInfoExpanded?m`
                    <div class="system-type-info">
                      ${S(`devices.heating_system_type_info`,this.hass.language)}
                    </div>
                  `:h}
              <ha-select
                .value=${this._heatingSystemType||`standard`}
                .options=${[{value:`standard`,label:S(`devices.system_type_none`,this.hass.language)},{value:`radiator`,label:S(`devices.system_type_radiator`,this.hass.language)},{value:`underfloor`,label:S(`devices.system_type_underfloor`,this.hass.language)}]}
                @selected=${this._onHeatingSystemTypeChange}
                @closed=${e=>e.stopPropagation()}
                fixedMenuPosition
                style="width: 100%;"
              >
                <ha-list-item value="standard"
                  >${S(`devices.system_type_none`,this.hass.language)}</ha-list-item
                >
                <ha-list-item value="radiator"
                  >${S(`devices.system_type_radiator`,this.hass.language)}</ha-list-item
                >
                <ha-list-item value="underfloor"
                  >${S(`devices.system_type_underfloor`,this.hass.language)}</ha-list-item
                >
              </ha-select>
              ${this._showBoostHint?m`
                    <div class="boost-hint">
                      <ha-icon icon="mdi:information-outline"></ha-icon>
                      <span
                        >${S(`devices.heating_system_type_boost_hint`,this.hass.language)}</span
                      >
                    </div>
                  `:h}
            </div>
          `:h}
    `}_renderMasterRow(e,t){let n=this._selectedThermostats.has(e),r=this._selectedCoolingDevices.has(e),i=n||r,a=this._selectedForEdit===e,o=this.hass.states[e]?.attributes?.friendly_name||e,s=this.devices.find(t=>t.entity_id===e),c=n?S(`devices.type_thermostat`,this.hass.language):r?S(`devices.type_ac`,this.hass.language):``;return m`
      <div
        class="master-row ${a?`focused`:``} ${i?`in-room`:``}"
        @click=${()=>this._onSelectForEdit(e)}
      >
        <ha-checkbox
          .checked=${i}
          @click=${e=>e.stopPropagation()}
          @change=${t=>{let n=t.target;this._onClimateToggle(e,n.checked),n.checked&&(this._selectedForEdit=e)}}
        ></ha-checkbox>
        <div class="master-info">
          <div class="master-name-row">
            <span class="master-name">${o}</span>
            ${t?m`<span class="external-badge"
                  >${S(`devices.other_area`,this.hass.language)}</span
                >`:h}
          </div>
          <div class="master-meta">
            ${c?m`<span class="type-pill">${c}</span>`:h}
            ${s?.idle_action&&s.idle_action!==`off`?m`<span class="meta-pill"
                  >${S(`devices.idle_action_${s.idle_action}`,this.hass.language)}</span
                >`:h}
            ${s?.setpoint_mode===`direct`&&this.selectedTempSensor?m`<span class="meta-pill"
                  >${S(`devices.setpoint_mode_direct`,this.hass.language)}</span
                >`:h}
          </div>
        </div>
      </div>
    `}_onSelectForEdit(e){this._selectedForEdit=e}_renderDeviceDetail(e){let t=this.devices.find(t=>t.entity_id===e);if(!t)return h;let n=t.type===`trv`,r=t.type===`ac`,i=this.hass.states[e],a=i?.attributes?.friendly_name||e,o=(i?.attributes?.hvac_modes??[]).includes(`fan_only`),s=this.valveProtectionExclude.has(e),c=this.hass.language;return m`
      <div class="detail-head">
        <div class="detail-title">${a}</div>
        <div class="detail-entity-id">${e}</div>
      </div>

      <div class="detail-field">
        <ha-select
          .label=${S(`devices.type_label`,c)||`Type`}
          .value=${this._getDeviceDisplayType(e)}
          .options=${[{value:`thermostat`,label:S(`devices.type_thermostat`,c)},{value:`ac`,label:S(`devices.type_ac`,c)}]}
          @selected=${t=>this._onDeviceTypeChange(e,P(t))}
          @closed=${e=>e.stopPropagation()}
          fixedMenuPosition
        >
          <ha-list-item value="thermostat"
            >${S(`devices.type_thermostat`,c)}</ha-list-item
          >
          <ha-list-item value="ac">${S(`devices.type_ac`,c)}</ha-list-item>
        </ha-select>
      </div>

      ${r?m`
            <div class="detail-field">
              <ha-select
                .label=${S(`devices.idle_action`,c)}
                .value=${t.idle_action??`off`}
                .options=${[{value:`off`,label:S(`devices.idle_action_off`,c)},...o?[{value:`fan_only`,label:S(`devices.idle_action_fan_only`,c)}]:[],{value:`setback`,label:S(`devices.idle_action_setback`,c)}]}
                @selected=${t=>this._onIdleActionChange(e,P(t))}
                @closed=${e=>e.stopPropagation()}
                fixedMenuPosition
              >
                <ha-list-item value="off"
                  >${S(`devices.idle_action_off`,c)}</ha-list-item
                >
                ${o?m`<ha-list-item value="fan_only"
                      >${S(`devices.idle_action_fan_only`,c)}</ha-list-item
                    >`:h}
                <ha-list-item value="setback"
                  >${S(`devices.idle_action_setback`,c)}</ha-list-item
                >
              </ha-select>
            </div>
            ${t.idle_action===`fan_only`?m`<div class="detail-field">
                  <ha-select
                    .label=${S(`devices.idle_fan_mode`,c)}
                    .value=${t.idle_fan_mode??``}
                    .options=${[{value:``,label:S(`devices.idle_fan_mode_keep`,c)},...(i?.attributes?.fan_modes??[]).map(e=>({value:e,label:e}))]}
                    @selected=${t=>{let n=P(t);this._onIdleFanModeChange(e,n??``)}}
                    @closed=${e=>e.stopPropagation()}
                    fixedMenuPosition
                  >
                    <ha-list-item value=""
                      >${S(`devices.idle_fan_mode_keep`,c)}</ha-list-item
                    >
                    ${(i?.attributes?.fan_modes??[]).map(e=>m`<ha-list-item value="${e}">${e}</ha-list-item>`)}
                  </ha-select>
                </div>`:h}
          `:h}
      ${n?m`
            <div class="detail-field with-info">
              <ha-select
                .label=${S(`devices.idle_action`,c)}
                .value=${t.idle_action??`off`}
                .options=${[{value:`off`,label:S(`devices.idle_action_off`,c)},{value:`low`,label:S(`devices.idle_action_low`,c)}]}
                @selected=${t=>this._onIdleActionChange(e,P(t))}
                @closed=${e=>e.stopPropagation()}
                fixedMenuPosition
              >
                <ha-list-item value="off"
                  >${S(`devices.idle_action_off`,c)}</ha-list-item
                >
                <ha-list-item value="low"
                  >${S(`devices.idle_action_low`,c)}</ha-list-item
                >
              </ha-select>
              ${t.idle_action===`low`?m`<rs-info-icon
                    .text=${S(`devices.idle_action_low_hint`,c)}
                  ></rs-info-icon>`:h}
            </div>
          `:h}
      ${this.selectedTempSensor?m`
            <div class="detail-field with-info">
              <ha-select
                .label=${S(`devices.setpoint_mode`,c)}
                .value=${t.setpoint_mode??`proportional`}
                .options=${[{value:`proportional`,label:S(`devices.setpoint_mode_proportional`,c)},{value:`direct`,label:S(`devices.setpoint_mode_direct`,c)}]}
                @selected=${t=>this._onSetpointModeChange(e,P(t))}
                @closed=${e=>e.stopPropagation()}
                fixedMenuPosition
              >
                <ha-list-item value="proportional"
                  >${S(`devices.setpoint_mode_proportional`,c)}</ha-list-item
                >
                <ha-list-item value="direct"
                  >${S(`devices.setpoint_mode_direct`,c)}</ha-list-item
                >
              </ha-select>
              <rs-info-icon .text=${S(`devices.setpoint_mode_hint`,c)}></rs-info-icon>
            </div>
          `:h}
      ${n&&this.valveProtectionEnabled?m`
            <div class="detail-toggle-row">
              <ha-checkbox
                .checked=${s}
                @change=${t=>{let n=t.target;this._onValveProtectionExcludeToggle(e,n.checked)}}
              ></ha-checkbox>
              <div class="detail-toggle-label">
                <ha-icon icon="mdi:shield-off-outline"></ha-icon>
                ${S(`devices.valve_protection_excluded`,c)}
                <rs-info-icon
                  .text=${S(`devices.valve_protection_exclude_hint`,c)}
                ></rs-info-icon>
              </div>
            </div>
          `:h}
    `}_detectClimateType(e){return(this.hass.states[e]?.attributes?.hvac_modes??[]).some(e=>[`cool`,`heat_cool`].includes(e))?`ac`:`thermostat`}_getDeviceDisplayType(e){let t=this.devices.find(t=>t.entity_id===e);return t&&t.type===`ac`?`ac`:`thermostat`}_onClimateToggle(e,t){let n;if(t){let t=this._detectClimateType(e)===`thermostat`?`trv`:`ac`;n=[...this.devices,{entity_id:e,type:t,role:`auto`}]}else n=this.devices.filter(t=>t.entity_id!==e);this._fireDeviceChanged(n)}_onDeviceTypeChange(e,t){let n=t===`thermostat`?`trv`:`ac`,r=this.devices.map(t=>{if(t.entity_id!==e)return t;let r={...t,type:n};return n===`ac`&&r.idle_action===`low`&&(r.idle_action=`off`),r});this._fireDeviceChanged(r)}_onValveProtectionExcludeToggle(e,t){this.dispatchEvent(new CustomEvent(`valve-protection-exclude-toggle`,{detail:{entityId:e,excluded:t},bubbles:!0,composed:!0}))}_onIdleActionChange(e,t){let n=this.devices.map(n=>{if(n.entity_id!==e)return n;let r={...n,idle_action:t};return t===`fan_only`&&!n.idle_fan_mode&&(r.idle_fan_mode=`low`),r});this._fireDeviceChanged(n)}_onIdleFanModeChange(e,t){let n=this.devices.map(n=>n.entity_id===e?{...n,idle_fan_mode:t}:n);this._fireDeviceChanged(n)}_onSetpointModeChange(e,t){let n=this.devices.map(n=>n.entity_id===e?{...n,setpoint_mode:t}:n);this._fireDeviceChanged(n)}_onHeatingSystemTypeChange(e){let t=P(e)??``,n=t===`standard`?``:t;this._showBoostHint=!0;let r=this.devices.map(e=>e.type===`trv`?{...e,heating_system_type:n}:e);this._fireDeviceChanged(r)}_fireDeviceChanged(e){this.dispatchEvent(new CustomEvent(`device-changed`,{detail:{devices:e},bubbles:!0,composed:!0}))}_onEntityPicked(e){let t=e.detail?.value,n=e.target;if(n.value=``,!t||!t.startsWith(`climate.`)||this.devices.some(e=>e.entity_id===t))return;let r=this._detectClimateType(t)===`thermostat`?`trv`:`ac`,i=[...this.devices,{entity_id:t,type:r,role:`auto`}];this._fireDeviceChanged(i)}};k([y({attribute:!1})],R.prototype,`hass`,void 0),k([y({attribute:!1})],R.prototype,`area`,void 0),k([y({attribute:!1})],R.prototype,`devices`,void 0),k([y({type:String})],R.prototype,`selectedTempSensor`,void 0),k([y({attribute:!1})],R.prototype,`valveProtectionExclude`,void 0),k([y({type:Boolean})],R.prototype,`valveProtectionEnabled`,void 0),k([y({type:Boolean})],R.prototype,`editing`,void 0),k([b()],R.prototype,`_systemTypeInfoExpanded`,void 0),k([b()],R.prototype,`_showBoostHint`,void 0),k([b()],R.prototype,`_selectedThermostats`,void 0),k([b()],R.prototype,`_selectedCoolingDevices`,void 0),k([b()],R.prototype,`_heatingSystemType`,void 0),k([b()],R.prototype,`_selectedForEdit`,void 0),R=k([v(`rs-device-section`)],R),_(),x(),A();var z=class extends g{constructor(...e){super(...e),this.temperatureSensor=``,this.temperatureSensors=new Set,this.humiditySensor=``,this.occupancySensors=new Set,this.windowSensors=new Set,this.windowOpenDelay=0,this.windowCloseDelay=0,this.heatingSystemType=``,this.editing=!1,this.language=`en`,this._pickerOpen=!1,this._collapsed={},this._globalEntityFilter=e=>{let t=e.entity_id;if(t.substring(t.indexOf(`.`)+1).startsWith(`roommind_`)||this.temperatureSensor===t||this.temperatureSensors.has(t)||this.humiditySensor===t||this.occupancySensors.has(t)||this.windowSensors.has(t))return!1;if(t.startsWith(`sensor.`)){let e=this.hass.states[t]?.attributes?.device_class;return e===`temperature`||e===`humidity`}if(t.startsWith(`binary_sensor.`)){let e=this.hass.states[t]?.attributes?.device_class;return e===`occupancy`||e===`motion`||e===`presence`||e===`window`||e===`door`||e===`opening`}return t.startsWith(`climate.`)?this.hass.states[t]?.attributes?.current_temperature!=null:t.startsWith(`input_number.`)||t.startsWith(`input_boolean.`)},this._onGlobalPickerValueChanged=e=>{let t=e.detail?.value,n=e.target;if(n.value=``,t){if(t.startsWith(`binary_sensor.`)){let e=this.hass.states[t]?.attributes?.device_class;e===`window`||e===`door`||e===`opening`?this.windowSensors.has(t)||this._onWindowToggle(t,!0):this.occupancySensors.has(t)||this._onOccupancyToggle(t,!0)}else if(t.startsWith(`input_boolean.`))this.occupancySensors.has(t)||this._onOccupancyToggle(t,!0);else if(t.startsWith(`input_number.`)){let e=this.hass.states[t]?.attributes?.unit_of_measurement;this._onSensorSelected(t,e===`%`?`humidity`:`temp`)}else if(t.startsWith(`climate.`))this._onSensorSelected(t,`temp`);else{let e=this.hass.states[t]?.attributes?.device_class;this._onSensorSelected(t,e===`humidity`?`humidity`:`temp`)}this._pickerOpen=!1}},this._onWindowOpenDelayChange=e=>{let t=Math.max(0,parseInt(e.target.value)||0);this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:`window_open_delay`,value:t},bubbles:!0,composed:!0}))},this._onWindowCloseDelayChange=e=>{let t=Math.max(0,parseInt(e.target.value)||0);this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:`window_close_delay`,value:t},bubbles:!0,composed:!0}))}}static{this.styles=[I,l`
      :host {
        display: block;
      }

      .sensor-block {
        display: flex;
        flex-direction: column;
        gap: 6px;
        padding: 12px 14px;
        background: rgba(255, 255, 255, 0.02);
        border: 1px solid var(--divider-color, rgba(255, 255, 255, 0.08));
        border-radius: 12px;
      }

      .sensor-block + .sensor-block {
        margin-top: 12px;
      }

      .block-header {
        display: flex;
        align-items: center;
        gap: 8px;
        padding-bottom: 6px;
        cursor: pointer;
        user-select: none;
      }

      .block-header:hover .block-title {
        color: var(--primary-color);
      }

      .block-header ha-icon {
        --mdc-icon-size: 18px;
        color: var(--secondary-text-color);
      }

      .chevron {
        --mdc-icon-size: 18px;
        color: var(--secondary-text-color);
        transition: transform 0.2s ease;
      }

      .chevron.collapsed {
        transform: rotate(-90deg);
      }

      .block-body {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .sensor-block.collapsed .block-header {
        padding-bottom: 0;
      }

      .block-title {
        font-size: 13px;
        font-weight: 500;
        color: var(--primary-text-color);
        letter-spacing: 0.2px;
        flex: 1;
      }

      .count-chip {
        font-size: 11px;
        font-weight: 500;
        padding: 1px 7px;
        border-radius: 10px;
        background: rgba(255, 255, 255, 0.06);
        color: var(--secondary-text-color);
      }

      .count-chip.has-selection {
        background: rgba(3, 169, 244, 0.15);
        color: var(--primary-color);
      }

      .row-list {
        display: flex;
        flex-direction: column;
        gap: 2px;
        max-height: 168px;
        overflow-y: auto;
        overflow-x: hidden;
        scrollbar-width: thin;
      }

      .row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 6px 8px;
        border-radius: 8px;
        cursor: pointer;
        border-left: 2px solid transparent;
        transition:
          background 0.15s,
          border-color 0.15s;
        min-width: 0;
      }

      .row:hover {
        background: rgba(255, 255, 255, 0.03);
      }

      .row.selected {
        background: rgba(3, 169, 244, 0.08);
        border-left-color: var(--primary-color);
      }

      .row ha-checkbox,
      .row ha-radio {
        flex-shrink: 0;
        margin: -4px 0;
      }

      .temp-controls {
        display: flex;
        align-items: center;
        gap: 4px;
        flex-shrink: 0;
      }

      .temp-role {
        font-size: 10px;
        color: var(--secondary-text-color);
        text-transform: uppercase;
        letter-spacing: 0.4px;
        min-width: 28px;
      }

      .row-info {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 1px;
      }

      .row-name-line {
        display: flex;
        align-items: center;
        gap: 6px;
        min-width: 0;
      }

      .row-name {
        font-size: 13px;
        font-weight: 450;
        color: var(--primary-text-color);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .row-eid {
        font-family: var(--code-font-family, monospace);
        font-size: 10.5px;
        color: var(--secondary-text-color);
        opacity: 0.65;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .external-badge {
        display: inline-flex;
        align-items: center;
        font-size: 9.5px;
        font-weight: 500;
        color: var(--warning-color, #ff9800);
        background: rgba(255, 152, 0, 0.1);
        padding: 1px 6px;
        border-radius: 8px;
        letter-spacing: 0.3px;
        text-transform: uppercase;
        flex-shrink: 0;
      }

      .value-chip {
        flex-shrink: 0;
        font-size: 12px;
        font-weight: 500;
        padding: 3px 9px;
        border-radius: 10px;
        background: rgba(255, 255, 255, 0.05);
        color: var(--primary-text-color);
        font-variant-numeric: tabular-nums;
      }

      .row.selected .value-chip {
        background: rgba(3, 169, 244, 0.15);
        color: var(--primary-color);
      }

      .occupancy-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        flex-shrink: 0;
        transition: background 0.2s;
      }

      .occupancy-dot.on {
        background: var(--success-color, #4caf50);
        box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.18);
      }

      .occupancy-dot.off {
        background: rgba(255, 255, 255, 0.2);
      }

      .window-dot.on {
        background: var(--warning-color, #ff9800);
        box-shadow: 0 0 0 3px rgba(255, 152, 0, 0.18);
      }

      .window-dot.off {
        background: rgba(255, 255, 255, 0.2);
      }

      .delay-fields {
        display: flex;
        gap: 8px;
        margin-top: 8px;
      }

      .delay-fields ha-textfield {
        flex: 1;
      }

      .delay-hint {
        display: flex;
        align-items: flex-start;
        gap: 6px;
        font-size: 11.5px;
        line-height: 1.5;
        color: var(--warning-color, #ff9800);
        margin-top: 6px;
      }

      .delay-hint ha-icon {
        --mdc-icon-size: 16px;
        flex-shrink: 0;
        margin-top: 1px;
      }

      .delay-view {
        font-size: 12px;
        color: var(--secondary-text-color);
        padding-top: 4px;
      }

      .empty-row {
        color: var(--secondary-text-color);
        font-size: 12.5px;
        font-style: italic;
        padding: 6px 4px;
        opacity: 0.7;
      }

      .add-row,
      .global-add {
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .global-add {
        margin-top: 12px;
      }

      .add-row ha-entity-picker,
      .global-add ha-entity-picker {
        flex: 1;
      }

      .add-button {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 10px;
        margin: 12px 0 0 0;
        background: none;
        border: none;
        cursor: pointer;
        color: var(--secondary-text-color);
        font-size: 12px;
        font-weight: 500;
        border-radius: 6px;
        transition:
          color 0.15s,
          background 0.15s;
      }

      .add-button:hover,
      .add-button:focus-visible {
        color: var(--primary-color);
        background: rgba(3, 169, 244, 0.08);
        outline: none;
      }

      .add-button ha-icon {
        --mdc-icon-size: 16px;
      }

      .picker-close {
        --mdc-icon-button-size: 32px;
        --mdc-icon-size: 18px;
        color: var(--secondary-text-color);
        flex-shrink: 0;
      }

      /* View mode rows */
      .view-row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 6px 0;
        font-size: 14px;
        color: var(--primary-text-color);
      }

      .view-name {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .entity-link {
        cursor: pointer;
      }

      .entity-link:hover {
        text-decoration: underline;
      }

      .view-value {
        font-weight: 500;
        flex-shrink: 0;
      }

      .section-subtitle {
        font-size: 12px;
        font-weight: 500;
        color: var(--secondary-text-color);
        margin: 12px 0 4px 0;
        text-transform: uppercase;
        letter-spacing: 0.4px;
      }

      .section-subtitle:first-child {
        margin-top: 0;
      }
    `]}render(){return this.editing?this._renderEditMode():this._renderViewMode()}_renderViewMode(){let e=this._temperatureSensorIds(),t=e.length>0,n=!!this.humiditySensor,r=this.occupancySensors.size>0,i=this.windowSensors.size>0;if(!t&&!n&&!r&&!i)return h;let a=this.hass.language;return m`
      ${t?m`
            <div class="section-subtitle">${S(`devices.temp_sensors`,a)}</div>
            ${e.map(e=>this._renderSensorViewRow(e,`temp`))}
          `:h}
      ${n?m`
            <div class="section-subtitle">${S(`devices.humidity_sensors`,a)}</div>
            ${this._renderSensorViewRow(this.humiditySensor,`humidity`)}
          `:h}
      ${r?m`
            <div class="section-subtitle">${S(`devices.occupancy_sensors`,a)}</div>
            ${[...this.occupancySensors].map(e=>this._renderOccupancyViewRow(e))}
          `:h}
      ${i?m`
            <div class="section-subtitle">${S(`devices.window_sensors`,a)}</div>
            ${[...this.windowSensors].map(e=>this._renderWindowViewRow(e))}
            ${this.windowOpenDelay||this.windowCloseDelay?m`<div class="delay-view">
                  ${this.windowOpenDelay?m`${S(`devices.window_open_delay`,a)}: ${this.windowOpenDelay}s`:h}
                  ${this.windowOpenDelay&&this.windowCloseDelay?` · `:h}
                  ${this.windowCloseDelay?m`${S(`devices.window_close_delay`,a)}:
                      ${this.windowCloseDelay}s`:h}
                </div>`:h}
          `:h}
    `}_renderWindowViewRow(e){let t=this.hass.states[e];return m`
      <div class="view-row">
        <span class="view-name entity-link" @click=${()=>zt(this,e)}
          >${t?.attributes?.friendly_name||e}</span
        >
        <span class="occupancy-dot window-dot ${t?.state===`on`?`on`:`off`}"></span>
      </div>
    `}_renderSensorViewRow(e,t){let n=this.hass.states[e],r=n?.attributes?.friendly_name||e,i=n?.state,a=n?.attributes??{},o=``;if(t===`temp`){let t=e.startsWith(`climate.`)?a.current_temperature:i;t!=null&&t!==``&&t!==`unknown`&&t!==`unavailable`&&(o=`${Number(t).toFixed(1)}${C(this.hass)}`)}else i&&i!==`unknown`&&i!==`unavailable`&&(o=`${Math.round(Number(i))}%`);return m`
      <div class="view-row">
        <span class="view-name entity-link" @click=${()=>zt(this,e)}
          >${r}</span
        >
        ${o?m`<span class="view-value">${o}</span>`:h}
      </div>
    `}_renderOccupancyViewRow(e){let t=this.hass.states[e];return m`
      <div class="view-row">
        <span class="view-name entity-link" @click=${()=>zt(this,e)}
          >${t?.attributes?.friendly_name||e}</span
        >
        <span class="occupancy-dot ${t?.state===`on`?`on`:`off`}"></span>
      </div>
    `}_renderEditMode(){let e=Ct(this.area.area_id,this.hass?.entities,this.hass?.devices).filter(e=>!e.entity_id.substring(e.entity_id.indexOf(`.`)+1).startsWith(`roommind_`)),t=this.hass?.states?e.filter(e=>e.entity_id.startsWith(`sensor.`)&&this.hass.states[e.entity_id]?.attributes?.device_class===`temperature`||e.entity_id.startsWith(`climate.`)&&this.hass.states[e.entity_id]?.attributes?.current_temperature!=null):[],n=this.hass?.states?e.filter(e=>e.entity_id.startsWith(`sensor.`)&&this.hass.states[e.entity_id]?.attributes?.device_class===`humidity`):[],r=this.hass?.states?e.filter(e=>e.entity_id.startsWith(`binary_sensor.`)&&[`occupancy`,`motion`,`presence`].includes(this.hass.states[e.entity_id]?.attributes?.device_class)||e.entity_id.startsWith(`input_boolean.`)):[],i=new Set(t.map(e=>e.entity_id)),a=this._temperatureSensorIds().filter(e=>!i.has(e)),o=new Set(n.map(e=>e.entity_id)),s=this.humiditySensor&&!o.has(this.humiditySensor)?this.humiditySensor:null,c=new Set(r.map(e=>e.entity_id)),l=[...this.occupancySensors].filter(e=>!c.has(e)),u=this.hass?.states?e.filter(e=>e.entity_id.startsWith(`binary_sensor.`)&&[`window`,`door`,`opening`].includes(this.hass.states[e.entity_id]?.attributes?.device_class)):[],d=new Set(u.map(e=>e.entity_id)),f=[...this.windowSensors].filter(e=>!d.has(e)),p=this.hass.language;return m`
      ${this._renderBlock({kind:`temp`,icon:`mdi:thermometer`,title:S(`devices.temp_sensors`,p),emptyText:S(`devices.no_temp_sensors`,p),areaSensors:t,externalSensors:a,selectedCount:this._temperatureSensorIds().length})}
      ${this._renderBlock({kind:`humidity`,icon:`mdi:water-percent`,title:S(`devices.humidity_sensors`,p),emptyText:S(`devices.no_humidity_sensors`,p),areaSensors:n,externalSensors:s?[s]:[],selectedCount:+!!this.humiditySensor})}
      ${this._renderBlock({kind:`occupancy`,icon:`mdi:account-eye`,title:S(`devices.occupancy_sensors`,p),emptyText:S(`devices.no_occupancy_sensors`,p),areaSensors:r,externalSensors:l,selectedCount:this.occupancySensors.size})}
      ${this._renderBlock({kind:`window`,icon:`mdi:window-open-variant`,title:S(`devices.window_sensors`,p),emptyText:S(`devices.no_window_sensors`,p),areaSensors:u,externalSensors:f,selectedCount:this.windowSensors.size,extras:this._renderWindowExtras(p)})}
      ${this._renderGlobalAdd(p)}
    `}_renderWindowExtras(e){return this.windowSensors.size===0?h:m`
      <div class="delay-fields">
        <ha-textfield
          type="number"
          min="0"
          suffix="s"
          .label=${S(`devices.window_open_delay`,e)}
          .value=${String(this.windowOpenDelay)}
          @change=${this._onWindowOpenDelayChange}
        ></ha-textfield>
        <ha-textfield
          type="number"
          min="0"
          suffix="s"
          .label=${S(`devices.window_close_delay`,e)}
          .value=${String(this.windowCloseDelay)}
          @change=${this._onWindowCloseDelayChange}
        ></ha-textfield>
      </div>
      ${this.heatingSystemType===`underfloor`&&this.windowOpenDelay<300?m`
            <div class="delay-hint">
              <ha-icon icon="mdi:information-outline"></ha-icon>
              ${S(`devices.underfloor_delay_hint`,e)}
            </div>
          `:h}
    `}_renderGlobalAdd(e){return this._pickerOpen?m`
        <div class="global-add">
          <ha-entity-picker
            .hass=${this.hass}
            .includeDomains=${[`sensor`,`binary_sensor`,`climate`,`input_number`,`input_boolean`]}
            .entityFilter=${this._globalEntityFilter}
            .value=${``}
            .autofocus=${!0}
            label=${S(`devices.add_entity`,e)}
            @value-changed=${this._onGlobalPickerValueChanged}
          ></ha-entity-picker>
          <ha-icon-button
            class="picker-close"
            .path=${`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}
            @click=${()=>this._pickerOpen=!1}
          ></ha-icon-button>
        </div>
      `:m`
      <button type="button" class="add-button global" @click=${()=>this._pickerOpen=!0}>
        <ha-icon icon="mdi:plus"></ha-icon>
        ${S(`devices.add_entity`,e)}
      </button>
    `}_renderBlock(e){let t=e.areaSensors.length+e.externalSensors.length,n=this._collapsed[e.kind]??!0;return m`
      <div class="sensor-block ${n?`collapsed`:``}">
        <div class="block-header" @click=${()=>this._toggleBlock(e.kind)}>
          <ha-icon icon=${e.icon}></ha-icon>
          <div class="block-title">${e.title}</div>
          ${e.selectedCount>0?m`<span class="count-chip has-selection">${e.selectedCount}</span>`:t>0?m`<span class="count-chip">${t}</span>`:h}
          <ha-icon
            class="chevron ${n?`collapsed`:``}"
            icon="mdi:chevron-down"
          ></ha-icon>
        </div>
        ${n?h:m`
              <div class="block-body">
                <div class="row-list">
                  ${e.areaSensors.length>0||e.externalSensors.length>0?m`
                        ${e.areaSensors.map(t=>this._renderEditRow(t.entity_id,e.kind,!1))}
                        ${e.externalSensors.map(t=>this._renderEditRow(t,e.kind,!0))}
                      `:m`<div class="empty-row">${e.emptyText}</div>`}
                </div>
                ${e.extras??h}
              </div>
            `}
      </div>
    `}_toggleBlock(e){let t=this._collapsed[e]??!0;this._collapsed={...this._collapsed,[e]:!t}}_renderEditRow(e,t,n){let r=this.hass.states[e],i=r?.attributes?.friendly_name||e,a=this.hass.language;if(t===`occupancy`||t===`window`){let o=(t===`occupancy`?this.occupancySensors:this.windowSensors).has(e),s=r?.state===`on`,c=t===`window`?`occupancy-dot window-dot`:`occupancy-dot`,l=n=>t===`occupancy`?this._onOccupancyToggle(e,n):this._onWindowToggle(e,n);return m`
        <div
          class="row ${o?`selected`:``}"
          @click=${e=>{e.target.tagName!==`HA-CHECKBOX`&&l(!o)}}
        >
          <ha-checkbox
            .checked=${o}
            @change=${e=>{let t=e.target;l(t.checked)}}
          ></ha-checkbox>
          <div class="row-info">
            <div class="row-name-line">
              <span class="row-name">${i}</span>
              ${n?m`<span class="external-badge">${S(`devices.other_area`,a)}</span>`:h}
            </div>
            <div class="row-eid">${e}</div>
          </div>
          <span class="${c} ${s?`on`:`off`}"></span>
        </div>
      `}let o=(t===`temp`?this.temperatureSensor:this.humiditySensor)===e,s=this.temperatureSensors.has(e)||o,c=t===`temp`?C(this.hass):`%`,l=e.startsWith(`climate.`)?r?.attributes?.current_temperature:r?.state,u=l&&l!==`unknown`&&l!==`unavailable`?`${t===`humidity`?Math.round(Number(l)):Number(l).toFixed(1)}${c}`:``;return m`
      <div
        class="row ${o||t===`temp`&&s?`selected`:``}"
        @click=${n=>{n.target.tagName!==`HA-CHECKBOX`&&this._onSensorSelected(o?``:e,t)}}
      >
        ${t===`temp`?m`
              <div class="temp-controls">
                <ha-radio .checked=${o} name="temp-sensor"></ha-radio>
                <span class="temp-role">${S(`devices.primary_sensor`,a)}</span>
                <ha-checkbox
                  .checked=${s}
                  @change=${t=>{let n=t.target;this._onTemperatureSensorToggle(e,n.checked)}}
                ></ha-checkbox>
              </div>
            `:m`<ha-radio .checked=${o} name="${t}-sensor"></ha-radio>`}
        <div class="row-info">
          <div class="row-name-line">
            <span class="row-name">${i}</span>
            ${n?m`<span class="external-badge">${S(`devices.other_area`,a)}</span>`:h}
          </div>
          <div class="row-eid">${e}</div>
        </div>
        ${u?m`<span class="value-chip">${u}</span>`:h}
      </div>
    `}_onSensorSelected(e,t){let n=t===`temp`?`temperature_sensor`:`humidity_sensor`;this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:n,value:e},bubbles:!0,composed:!0})),t===`temp`&&(e?this._onTemperatureSensorToggle(e,!0):this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:`temperature_sensors`,value:[]},bubbles:!0,composed:!0})))}_onTemperatureSensorToggle(e,t){let n=new Set(this.temperatureSensors);t?n.add(e):n.delete(e),this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:`temperature_sensors`,value:[...n]},bubbles:!0,composed:!0}))}_temperatureSensorIds(){let e=[];this.temperatureSensor&&e.push(this.temperatureSensor);for(let t of this.temperatureSensors)t&&!e.includes(t)&&e.push(t);return e}_onOccupancyToggle(e,t){let n=new Set(this.occupancySensors);t?n.add(e):n.delete(e),this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:`occupancy_sensors`,value:[...n]},bubbles:!0,composed:!0}))}_onWindowToggle(e,t){let n=new Set(this.windowSensors);t?n.add(e):n.delete(e),this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:`window_sensors`,value:[...n]},bubbles:!0,composed:!0}))}};k([y({attribute:!1})],z.prototype,`hass`,void 0),k([y({attribute:!1})],z.prototype,`area`,void 0),k([y({type:String})],z.prototype,`temperatureSensor`,void 0),k([y({attribute:!1})],z.prototype,`temperatureSensors`,void 0),k([y({type:String})],z.prototype,`humiditySensor`,void 0),k([y({attribute:!1})],z.prototype,`occupancySensors`,void 0),k([y({attribute:!1})],z.prototype,`windowSensors`,void 0),k([y({type:Number})],z.prototype,`windowOpenDelay`,void 0),k([y({type:Number})],z.prototype,`windowCloseDelay`,void 0),k([y({type:String})],z.prototype,`heatingSystemType`,void 0),k([y({type:Boolean})],z.prototype,`editing`,void 0),k([y()],z.prototype,`language`,void 0),k([b()],z.prototype,`_pickerOpen`,void 0),k([b()],z.prototype,`_collapsed`,void 0),z=k([v(`rs-sensor-section`)],z),_(),x(),A();var B=``,V=class extends g{constructor(...e){super(...e),this.airflowDevices=[],this.statuses=[],this.commandStatuses=[],this.hvacOutputStatus=null,this.qFanMix=0,this.qVent=0,this.airflowAch=0,this.planLevel=0,this.mixPlanLevel=0,this.ventPlanLevel=0,this.active=!1,this.editing=!1,this.language=`en`,this._selectedForEdit=``,this._onEntityPicked=e=>{let t=e.detail?.value,n=e.target;if(n.value=``,!t||this.airflowDevices.some(e=>e.entity_id===t))return;let r=[...this.airflowDevices,this._defaultDevice(t)];this._selectedForEdit=t,this._emit(r)},this._entityFilter=e=>{let t=e.entity_id;return this.airflowDevices.some(e=>e.entity_id===t)?!1:this._isAirflowCandidate(t)}}willUpdate(e){if(e.has(`airflowDevices`)){let e=new Set(this.airflowDevices.map(e=>e.entity_id));this._selectedForEdit&&!e.has(this._selectedForEdit)&&(this._selectedForEdit=``),!this._selectedForEdit&&this.airflowDevices.length>0&&(this._selectedForEdit=this.airflowDevices[0].entity_id)}}static{this.styles=[Ut,I,l`
      :host {
        display: block;
      }

      .summary {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 8px;
        margin-bottom: 10px;
      }

      .summary-item {
        min-width: 0;
        padding: 8px 10px;
        border-radius: 8px;
        background: rgba(255, 255, 255, 0.04);
      }

      .summary-label {
        font-size: 10px;
        font-weight: 600;
        color: var(--secondary-text-color);
        text-transform: uppercase;
        letter-spacing: 0.4px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .summary-value {
        margin-top: 2px;
        font-size: 14px;
        font-weight: 600;
        color: var(--primary-text-color);
        font-variant-numeric: tabular-nums;
      }

      .view-row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 6px 0;
        font-size: 14px;
        color: var(--primary-text-color);
      }

      .view-name {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .entity-link {
        cursor: pointer;
      }

      .entity-link:hover {
        text-decoration: underline;
      }

      .pill,
      .meta-pill {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 10px;
        font-weight: 500;
        padding: 1px 7px;
        border-radius: 8px;
        background: rgba(255, 255, 255, 0.05);
        color: var(--secondary-text-color);
        letter-spacing: 0.3px;
        text-transform: uppercase;
        flex-shrink: 0;
      }

      .pill.active {
        background: rgba(3, 169, 244, 0.12);
        color: var(--primary-color);
      }

      .pill.warning {
        background: rgba(255, 152, 0, 0.1);
        color: var(--warning-color, #ff9800);
      }

      .view-value {
        font-weight: 600;
        font-variant-numeric: tabular-nums;
        flex-shrink: 0;
      }

      .no-items,
      .empty-list {
        color: var(--secondary-text-color);
        font-size: 13px;
        padding: 8px 0;
      }

      .external-badge {
        display: inline-flex;
        align-items: center;
        font-size: 10px;
        font-weight: 500;
        color: var(--secondary-text-color);
        background: var(--divider-color, rgba(0, 0, 0, 0.06));
        padding: 1px 6px;
        border-radius: 4px;
        white-space: nowrap;
      }

      .picker-wrap {
        margin-top: 12px;
      }

      ha-entity-picker {
        width: 100%;
      }

      .detail-toggle-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 8px 0;
      }

      .toggle-text {
        min-width: 0;
      }

      .toggle-title {
        font-size: 14px;
        font-weight: 500;
        color: var(--primary-text-color);
      }

      .toggle-hint {
        margin-top: 2px;
        font-size: 12px;
        line-height: 1.4;
        color: var(--secondary-text-color);
      }

      .native-textarea {
        width: 100%;
        min-height: 68px;
        box-sizing: border-box;
        border: 1px solid var(--divider-color);
        border-radius: 8px;
        padding: 8px;
        color: var(--primary-text-color);
        background: var(--card-background-color);
        font: inherit;
      }

      .detail-field + .detail-field,
      .detail-field + .detail-toggle-row,
      .detail-toggle-row + .detail-toggle-row,
      .detail-toggle-row + .detail-field {
        margin-top: 12px;
      }

      @media (max-width: 520px) {
        .summary {
          grid-template-columns: 1fr;
        }
      }
    `]}render(){return this.editing?this._renderEdit():this._renderView()}_renderView(){let e=this.language;return this.airflowDevices.length===0?m`<p class="no-items">${S(`airflow.no_devices`,e)}</p>`:m`
      <div class="summary">
        <div class="summary-item">
          <div class="summary-label">${S(`airflow.mix_factor`,e)}</div>
          <div class="summary-value">${this._percent(this.qFanMix)}</div>
        </div>
        <div class="summary-item">
          <div class="summary-label">${S(`airflow.vent_factor`,e)}</div>
          <div class="summary-value">${this._percent(this.qVent)}</div>
        </div>
        <div class="summary-item">
          <div class="summary-label">${S(`airflow.ach`,e)}</div>
          <div class="summary-value">${this.airflowAch.toFixed(2)}/h</div>
        </div>
        <div class="summary-item">
          <div class="summary-label">${S(`airflow.mix_plan_level`,e)}</div>
          <div class="summary-value">${this._percent(this.mixPlanLevel)}</div>
        </div>
        <div class="summary-item">
          <div class="summary-label">${S(`airflow.vent_plan_level`,e)}</div>
          <div class="summary-value">${this._percent(this.ventPlanLevel)}</div>
        </div>
        ${this.hvacOutputStatus?m`<div class="summary-item">
              <div class="summary-label">${S(`airflow.hvac_output`,e)}</div>
              <div class="summary-value">
                ${this.hvacOutputStatus.stage} ·
                ${this.hvacOutputStatus.delivered_capacity_factor.toFixed(2)}x
              </div>
            </div>`:h}
      </div>
      ${this.airflowDevices.map(e=>this._renderViewRow(e))}
    `}_renderViewRow(e){let t=this.language,n=e.entity_id,r=this.hass.states[n],i=this._statusFor(n),a=this._commandFor(n),o=r?.attributes?.friendly_name||n,s=i&&!i.available,c=i?.q??0,l=a?.planned_level??(e.role===`ventilation`?this.ventPlanLevel:this.mixPlanLevel),u=a?.observed_q??c,d=a?this._commandLabel(a):``,f=a&&a.outcome!==`applied`;return m`
      <div class="view-row">
        <span class="view-name entity-link" @click=${()=>zt(this,n)}
          >${o}</span
        >
        <span class="pill">${this._roleLabel(e.role)}</span>
        ${e.control_enabled?m`<span class="pill active"
              >${S(`airflow.control_enabled_short`,t)}</span
            >`:e.controllable?m`<span class="pill">${S(`airflow.controllable_short`,t)}</span>`:h}
        ${s?m`<span class="pill warning">${S(`airflow.unavailable`,t)}</span>`:m`
              <span class="pill"
                >${S(`airflow.planned_level`,t)} ${this._percent(l)}</span
              >
              <span class="view-value"
                >${S(`airflow.actual_level`,t)} ${this._percent(u)}</span
              >
            `}
        ${f?m`<span class="pill warning" title=${a?.skip_reason??``}
              >${d}</span
            >`:h}
        ${a?.night_capped?m`<span class="pill warning">${S(`airflow.night_capped`,t)}</span>`:h}
        ${a?.assumed_state_confidence&&a.assumed_state_confidence!==`observed`?m`<span class="pill warning"
              >${this._confidenceLabel(a.assumed_state_confidence)}</span
            >`:h}
        ${a?.skipped_services?.length?m`<span
              class="pill warning"
              title=${a.skipped_services.map(e=>`${e.service}: ${e.reason}`).join(`
`)}
              >${a.skipped_services.length} ${S(`airflow.skipped`,t)}</span
            >`:h}
      </div>
    `}_renderEdit(){let e=this.language,t=Ct(this.area.area_id,this.hass?.entities,this.hass?.devices).filter(e=>!e.entity_id.substring(e.entity_id.indexOf(`.`)+1).startsWith(`roommind_`)).filter(e=>this._isAirflowCandidate(e.entity_id)),n=new Set(t.map(e=>e.entity_id)),r=this.airflowDevices.map(e=>e.entity_id).filter(e=>!n.has(e)),i=this._selectedForEdit,a=i&&this.airflowDevices.some(e=>e.entity_id===i);return m`
      <rs-master-detail>
        <div slot="master" class="master">
          <div class="block-title">${S(`airflow.devices`,e)}</div>
          <div class="master-list">
            ${t.length>0?t.map(e=>this._renderMasterRow(e.entity_id,!1)):m`<div class="empty-list">${S(`airflow.no_candidates`,e)}</div>`}
            ${r.map(e=>this._renderMasterRow(e,!0))}
          </div>
          <div class="picker-wrap">
            <ha-entity-picker
              .hass=${this.hass}
              .includeDomains=${[`fan`,`climate`]}
              .entityFilter=${this._entityFilter}
              .value=${``}
              .label=${S(`airflow.add_entity`,e)}
              @value-changed=${this._onEntityPicked}
            ></ha-entity-picker>
          </div>
        </div>

        <div slot="detail" class="detail-panel">
          ${a?this._renderDeviceDetail(i):m`<div class="empty-detail">
                <ha-icon icon="mdi:gesture-tap"></ha-icon>
                <span>${S(`devices.select_to_configure`,e)}</span>
              </div>`}
        </div>
      </rs-master-detail>
    `}_renderMasterRow(e,t){let n=this.airflowDevices.find(t=>t.entity_id===e),r=!!n,i=this._selectedForEdit===e,a=this.hass.states[e]?.attributes?.friendly_name||e,o=this._statusFor(e)?.q??0,s=this.language;return m`
      <div
        class="master-row ${i?`focused`:``} ${r?`in-room`:``}"
        @click=${()=>this._selectedForEdit=e}
      >
        <ha-checkbox
          .checked=${r}
          @click=${e=>e.stopPropagation()}
          @change=${t=>{let n=t.target;this._onToggle(e,n.checked),n.checked&&(this._selectedForEdit=e)}}
        ></ha-checkbox>
        <div class="master-info">
          <div class="master-name-row">
            <span class="master-name">${a}</span>
            ${t?m`<span class="external-badge">${S(`devices.other_area`,s)}</span>`:h}
          </div>
          <div class="master-meta">
            ${n?m`<span class="meta-pill">${this._roleLabel(n.role)}</span>`:h}
            ${n?.control_enabled?m`<span class="meta-pill"
                  >${S(`airflow.control_enabled_short`,s)}</span
                >`:h}
            ${o>0?m`<span class="meta-pill">${this._percent(o)}</span>`:h}
          </div>
        </div>
      </div>
    `}_renderDeviceDetail(e){let t=this.airflowDevices.find(t=>t.entity_id===e);if(!t)return h;let n=this.language,r=this.hass.states[e]?.attributes??{},i=r.friendly_name||e,a=e.startsWith(`fan.`),o=e.startsWith(`climate.`),s=this._stringArray(r.preset_modes),c=this._stringArray(r.swing_modes),l=this._stringArray(r.swing_horizontal_modes);return m`
      <div class="detail-head">
        <div class="detail-title">${i}</div>
        <div class="detail-entity-id">${e}</div>
      </div>

      <div class="detail-field">
        <ha-select
          .label=${S(`airflow.role`,n)}
          .value=${t.role}
          .options=${this._roleOptions()}
          @selected=${t=>this._updateDevice(e,{role:P(t)})}
          @closed=${e=>e.stopPropagation()}
          fixedMenuPosition
        >
          <ha-list-item value="circulation"
            >${S(`airflow.role_circulation`,n)}</ha-list-item
          >
          <ha-list-item value="ventilation"
            >${S(`airflow.role_ventilation`,n)}</ha-list-item
          >
          <ha-list-item value="hvac_fan">${S(`airflow.role_hvac_fan`,n)}</ha-list-item>
        </ha-select>
      </div>

      <div class="detail-toggle-row">
        <div class="toggle-text">
          <div class="toggle-title">${S(`airflow.controllable`,n)}</div>
          <div class="toggle-hint">${S(`airflow.controllable_hint`,n)}</div>
        </div>
        <ha-switch
          .checked=${t.controllable}
          @change=${n=>{let r=n.target.checked;this._updateDevice(e,{controllable:r,control_enabled:r?t.control_enabled:!1})}}
        ></ha-switch>
      </div>

      ${t.controllable?m`
            <div class="detail-toggle-row">
              <div class="toggle-text">
                <div class="toggle-title">${S(`airflow.control_enabled`,n)}</div>
                <div class="toggle-hint">${S(`airflow.control_enabled_hint`,n)}</div>
              </div>
              <ha-switch
                .checked=${t.control_enabled}
                @change=${t=>this._updateDevice(e,{control_enabled:t.target.checked})}
              ></ha-switch>
            </div>
          `:h}
      ${a?this._renderFanPrefs(e,t,s):h}
      ${o?this._renderClimatePrefs(e,t,s,c,l):h}
      ${this._renderAdvancedPrefs(e,t)}
    `}_renderFanPrefs(e,t,n){let r=this.language,i=t.preferred_oscillating===!0?`true`:t.preferred_oscillating===!1?`false`:B;return m`
      ${n.length>0?m`
            <div class="detail-field">
              <ha-select
                .label=${S(`airflow.preset_mode`,r)}
                .value=${t.preferred_preset_mode||B}
                @selected=${t=>{let n=P(t);this._updateDevice(e,{preferred_preset_mode:n===B?``:n})}}
                @closed=${e=>e.stopPropagation()}
                fixedMenuPosition
              >
                <ha-list-item value=${B}>${S(`airflow.keep`,r)}</ha-list-item>
                ${n.map(e=>m`<ha-list-item value=${e}>${e}</ha-list-item>`)}
              </ha-select>
            </div>
          `:h}
      <div class="detail-field">
        <ha-select
          .label=${S(`airflow.direction`,r)}
          .value=${t.preferred_direction||B}
          @selected=${t=>{let n=P(t);this._updateDevice(e,{preferred_direction:n===B?``:n})}}
          @closed=${e=>e.stopPropagation()}
          fixedMenuPosition
        >
          <ha-list-item value=${B}>${S(`airflow.keep`,r)}</ha-list-item>
          <ha-list-item value="forward"
            >${S(`airflow.direction_forward`,r)}</ha-list-item
          >
          <ha-list-item value="reverse"
            >${S(`airflow.direction_reverse`,r)}</ha-list-item
          >
        </ha-select>
      </div>
      <div class="detail-field">
        <ha-select
          .label=${S(`airflow.oscillating`,r)}
          .value=${i}
          @selected=${t=>{let n=P(t);this._updateDevice(e,{preferred_oscillating:n===B?null:n===`true`?!0:n===`false`?!1:null})}}
          @closed=${e=>e.stopPropagation()}
          fixedMenuPosition
        >
          <ha-list-item value=${B}>${S(`airflow.keep`,r)}</ha-list-item>
          <ha-list-item value="true">${S(`airflow.on`,r)}</ha-list-item>
          <ha-list-item value="false">${S(`airflow.off`,r)}</ha-list-item>
        </ha-select>
      </div>
    `}_renderClimatePrefs(e,t,n,r,i){let a=this.language;return m`
      ${n.length>0?m`
            ${this._renderPresetSelect(e,t,`preferred_preset_mode_thermal`,`airflow.preset_mode_thermal`,n)}
            ${this._renderPresetSelect(e,t,`preferred_preset_mode_idle`,`airflow.preset_mode_idle`,n)}
            ${this._renderPresetSelect(e,t,`preferred_preset_mode_night`,`airflow.preset_mode_night`,n)}
          `:h}
      ${r.length>0?m`
            <div class="detail-field">
              <ha-select
                .label=${S(`airflow.swing_mode`,a)}
                .value=${t.preferred_swing_mode||B}
                @selected=${t=>{let n=P(t);this._updateDevice(e,{preferred_swing_mode:n===B?``:n})}}
                @closed=${e=>e.stopPropagation()}
                fixedMenuPosition
              >
                <ha-list-item value=${B}>${S(`airflow.keep`,a)}</ha-list-item>
                ${r.map(e=>m`<ha-list-item value=${e}>${e}</ha-list-item>`)}
              </ha-select>
            </div>
          `:h}
      ${i.length>0?m`
            <div class="detail-field">
              <ha-select
                .label=${S(`airflow.swing_horizontal_mode`,a)}
                .value=${t.preferred_swing_horizontal_mode||B}
                @selected=${t=>{let n=P(t);this._updateDevice(e,{preferred_swing_horizontal_mode:n===B?``:n})}}
                @closed=${e=>e.stopPropagation()}
                fixedMenuPosition
              >
                <ha-list-item value=${B}>${S(`airflow.keep`,a)}</ha-list-item>
                ${i.map(e=>m`<ha-list-item value=${e}>${e}</ha-list-item>`)}
              </ha-select>
            </div>
          `:h}
    `}_renderPresetSelect(e,t,n,r,i){return m`
      <div class="detail-field">
        <ha-select
          .label=${S(r,this.language)}
          .value=${t[n]||B}
          @selected=${t=>{let r=P(t);this._updateDevice(e,{[n]:r===B?``:r})}}
          @closed=${e=>e.stopPropagation()}
          fixedMenuPosition
        >
          <ha-list-item value=${B}>${S(`airflow.keep`,this.language)}</ha-list-item>
          ${i.map(e=>m`<ha-list-item value=${e}>${e}</ha-list-item>`)}
        </ha-select>
      </div>
    `}_renderAdvancedPrefs(e,t){let n=this.language;return m`
      <div class="detail-field">
        <ha-entity-picker
          .hass=${this.hass}
          .includeDomains=${[`sensor`,`number`,`input_number`]}
          .value=${t.power_sensor_entity||``}
          .label=${S(`airflow.power_sensor`,n)}
          @value-changed=${t=>this._updateDevice(e,{power_sensor_entity:t.detail?.value||``})}
        ></ha-entity-picker>
      </div>
      <div class="detail-field">
        <ha-select
          .label=${S(`airflow.compressor_stage_observer`,n)}
          .value=${t.compressor_stage_observer||`auto`}
          @selected=${t=>this._updateDevice(e,{compressor_stage_observer:P(t)})}
          @closed=${e=>e.stopPropagation()}
          fixedMenuPosition
        >
          <ha-list-item value="auto">${S(`airflow.observer_auto`,n)}</ha-list-item>
          <ha-list-item value="power_sensor"
            >${S(`airflow.observer_power`,n)}</ha-list-item
          >
          <ha-list-item value="thermal_slope"
            >${S(`airflow.observer_slope`,n)}</ha-list-item
          >
          <ha-list-item value="disabled"
            >${S(`airflow.observer_disabled`,n)}</ha-list-item
          >
        </ha-select>
      </div>
      <div class="detail-field">
        <ha-textfield
          .label=${S(`airflow.assumed_state_ttl`,n)}
          type="number"
          min="0"
          max="3600"
          .value=${String(t.assumed_state_ttl_s??t.assumed_state_ttl??120)}
          @input=${t=>this._updateDevice(e,{assumed_state_ttl_s:Number(t.target.value)})}
        ></ha-textfield>
      </div>
      <div class="detail-field">
        <label class="summary-label">${S(`airflow.fan_capacity_curve`,n)}</label>
        <textarea
          class="native-textarea"
          .value=${this._curveToText(t.fan_capacity_curve,`capacity_factor`)}
          placeholder="0:1, 0.5:1.12, 1:1.25"
          @input=${t=>this._updateDevice(e,{fan_capacity_curve:this._parseCurveText(t.target.value,`capacity_factor`)})}
        ></textarea>
      </div>
      <div class="detail-field">
        <label class="summary-label">${S(`airflow.fan_power_curve`,n)}</label>
        <textarea
          class="native-textarea"
          .value=${this._curveToText(t.fan_power_curve,`power_w`)}
          placeholder="0:0, 0.5:18, 1:45"
          @input=${t=>this._updateDevice(e,{fan_power_curve:this._parseCurveText(t.target.value,`power_w`)})}
        ></textarea>
      </div>
    `}_onToggle(e,t){let n;if(t){if(this.airflowDevices.some(t=>t.entity_id===e))return;n=[...this.airflowDevices,this._defaultDevice(e)]}else n=this.airflowDevices.filter(t=>t.entity_id!==e);this._emit(n)}_updateDevice(e,t){let n=this.airflowDevices.map(n=>n.entity_id===e?{...n,...t}:n);this._emit(n)}_emit(e){this.dispatchEvent(new CustomEvent(`airflow-devices-changed`,{detail:{devices:e},bubbles:!0,composed:!0}))}_defaultDevice(e){return{entity_id:e,role:e.startsWith(`climate.`)?`hvac_fan`:`circulation`,controllable:!1,control_enabled:!1,preferred_direction:``,preferred_oscillating:null,preferred_preset_mode:``,preferred_preset_mode_thermal:``,preferred_preset_mode_idle:``,preferred_preset_mode_night:``,preferred_preset_mode_away:``,preferred_swing_mode:``,preferred_swing_horizontal_mode:``,effect_weight:1,airflow_m3h:null,power_sensor_entity:``,assumed_state_ttl:null,assumed_state_ttl_s:120,compressor_stage_observer:`auto`,fan_capacity_curve:[],fan_power_curve:[]}}_isAirflowCandidate(e){if(e.startsWith(`fan.`))return!0;if(!e.startsWith(`climate.`))return!1;let t=this.hass.states[e]?.attributes??{};return this._stringArray(t.fan_modes).length>0||this._stringArray(t.swing_modes).length>0||this._stringArray(t.swing_horizontal_modes).length>0}_roleOptions(){return[{value:`circulation`,label:this._roleLabel(`circulation`)},{value:`ventilation`,label:this._roleLabel(`ventilation`)},{value:`hvac_fan`,label:this._roleLabel(`hvac_fan`)}]}_roleLabel(e){return S(e===`ventilation`?`airflow.role_ventilation`:e===`hvac_fan`?`airflow.role_hvac_fan`:`airflow.role_circulation`,this.language)}_statusFor(e){return this.statuses.find(t=>t.entity_id===e)}_commandFor(e){return this.commandStatuses.find(t=>t.entity_id===e)}_commandLabel(e){return S(e.outcome===`unsupported_fan_only`?`airflow.command_unsupported_fan_only`:e.outcome===`skipped_off_climate`?`airflow.command_skipped_off_climate`:e.outcome===`blocked_by_mode`&&e.skip_reason===`control_disabled`?`airflow.command_control_disabled`:e.outcome===`blocked_by_mode`?`airflow.command_blocked_by_mode`:e.outcome===`failed`?`airflow.command_failed`:`airflow.command_applied`,this.language)}_percent(e){return`${Math.round(Math.max(0,Math.min(1,Number(e??0)))*100)}%`}_confidenceLabel(e){return S(e===`assumed`?`airflow.confidence_assumed`:e===`stale`?`airflow.confidence_stale`:e===`conflicting`?`airflow.confidence_conflicting`:e===`observed`?`airflow.confidence_observed`:`airflow.confidence_unknown`,this.language)}_curveToText(e,t){return(e??[]).filter(e=>Number.isFinite(e.level)&&Number.isFinite(Number(e[t]))).map(e=>`${e.level}:${Number(e[t]).toFixed(t===`power_w`?0:2)}`).join(`, `)}_parseCurveText(e,t){return e.split(/[,\n]/).map(e=>e.trim()).filter(Boolean).map(e=>{let[n,r]=e.split(`:`).map(e=>e.trim()),i=Number(n),a=Number(r);return!Number.isFinite(i)||!Number.isFinite(a)?null:{level:Math.max(0,Math.min(1,i)),[t]:a}}).filter(e=>!!e).sort((e,t)=>e.level-t.level)}_stringArray(e){return Array.isArray(e)?e.map(e=>String(e)):[]}};k([y({attribute:!1})],V.prototype,`hass`,void 0),k([y({attribute:!1})],V.prototype,`area`,void 0),k([y({attribute:!1})],V.prototype,`airflowDevices`,void 0),k([y({attribute:!1})],V.prototype,`statuses`,void 0),k([y({attribute:!1})],V.prototype,`commandStatuses`,void 0),k([y({attribute:!1})],V.prototype,`hvacOutputStatus`,void 0),k([y({type:Number})],V.prototype,`qFanMix`,void 0),k([y({type:Number})],V.prototype,`qVent`,void 0),k([y({type:Number})],V.prototype,`airflowAch`,void 0),k([y({type:Number})],V.prototype,`planLevel`,void 0),k([y({type:Number})],V.prototype,`mixPlanLevel`,void 0),k([y({type:Number})],V.prototype,`ventPlanLevel`,void 0),k([y({type:Boolean})],V.prototype,`active`,void 0),k([y({type:Boolean})],V.prototype,`editing`,void 0),k([y()],V.prototype,`language`,void 0),k([b()],V.prototype,`_selectedForEdit`,void 0),V=k([v(`rs-airflow-section`)],V),_(),x(),A();var H=class extends g{constructor(...e){super(...e),this.editing=!1,this.currentTemp=null,this.perceivedTemp=null,this.currentHumidity=null,this.controlTarget=`air_temperature`,this.roomVolumeM3=null,this.quietHours=null,this.nightModeEnabled=!0,this.maxFanLevelNight=.5,this.sleepTempRampC=0,this.nightAllowRapidRecovery=!0,this.rapidRecoveryDeltaC=2,this.nightMode=null,this.nightControls=[],this.nightControlStatus=[],this.adjacentRooms=[],this.couplingStatus=[],this.rapidRecoveryActive=!1,this.language=`en`,this._addNightControl=()=>{let e=[...this.nightControls,{entity_id:``,role:`indicator_light`,enabled:!0,night_value:`off`,restore_after_night:!0}];this._emit(`night_controls`,e)},this._addAdjacent=()=>{let e=Object.values(this.hass.areas??{}).find(e=>e.area_id!==this.area.area_id),t=[...this.adjacentRooms,{area_id:e?.area_id??``,enabled:!0,allow_borrowed_conditioning:!0}];this._emit(`adjacent_rooms`,t)}}static{this.styles=[I,l`
      :host {
        display: block;
      }

      .summary-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 8px;
        margin-bottom: 12px;
      }

      .summary-item,
      .config-card,
      .list-item {
        border-radius: 10px;
        background: rgba(255, 255, 255, 0.04);
        border: 1px solid var(--divider-color, rgba(0, 0, 0, 0.08));
      }

      .summary-item {
        padding: 9px 11px;
        min-width: 0;
      }

      .summary-label {
        font-size: 10px;
        font-weight: 600;
        color: var(--secondary-text-color);
        text-transform: uppercase;
        letter-spacing: 0.35px;
      }

      .summary-value {
        margin-top: 3px;
        font-size: 14px;
        font-weight: 600;
        color: var(--primary-text-color);
        font-variant-numeric: tabular-nums;
      }

      .summary-value.warning {
        color: var(--warning-color, #ff9800);
      }

      .muted,
      .empty {
        color: var(--secondary-text-color);
        font-size: 13px;
        line-height: 1.5;
      }

      .section-title {
        margin: 18px 0 8px;
        font-size: 13px;
        font-weight: 600;
        color: var(--primary-text-color);
      }

      .config-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
      }

      .config-card {
        padding: 12px;
      }

      .toggle-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
      }

      .toggle-title {
        font-size: 14px;
        font-weight: 500;
      }

      .toggle-hint {
        margin-top: 3px;
        color: var(--secondary-text-color);
        font-size: 12px;
        line-height: 1.4;
      }

      .field-row {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 10px;
        margin-top: 10px;
      }

      ha-textfield,
      ha-select,
      ha-entity-picker {
        width: 100%;
      }

      .list {
        display: flex;
        flex-direction: column;
        gap: 10px;
      }

      .list-item {
        padding: 12px;
      }

      .item-head {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 10px;
      }

      .item-title {
        flex: 1;
        min-width: 0;
        font-weight: 600;
        color: var(--primary-text-color);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .item-title.entity-link {
        cursor: pointer;
      }

      .item-title.entity-link:hover {
        text-decoration: underline;
      }

      .pill {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 1px 7px;
        border-radius: 8px;
        font-size: 10px;
        font-weight: 600;
        text-transform: uppercase;
        color: var(--secondary-text-color);
        background: rgba(255, 255, 255, 0.06);
      }

      .pill.active {
        color: var(--primary-color);
        background: rgba(3, 169, 244, 0.12);
      }

      .remove-btn,
      .add-btn {
        border: none;
        background: none;
        color: var(--primary-color);
        cursor: pointer;
        font: inherit;
        padding: 4px 0;
      }

      .remove-btn {
        color: var(--error-color, #d32f2f);
      }

      .mode-text {
        margin-top: 6px;
      }

      @media (max-width: 720px) {
        .summary-grid,
        .config-grid,
        .field-row {
          grid-template-columns: 1fr;
        }
      }
    `]}render(){return this.editing?this._renderEdit():this._renderView()}_renderView(){let e=this.language,t=this.nightMode?.active??!1,n=this.controlTarget===`perceived_temperature`?S(`comfort.control_target_perceived`,e):S(`comfort.control_target_air`,e),r=this.couplingStatus.filter(e=>e.gate>0&&e.k>0).length,i=this.nightControlStatus.filter(e=>e.outcome===`applied`).length;return m`
      <div class="summary-grid">
        <div class="summary-item">
          <div class="summary-label">${S(`comfort.perceived_temp`,e)}</div>
          <div class="summary-value">
            ${this.perceivedTemp==null?`--`:`${this.perceivedTemp.toFixed(1)}°`}
          </div>
        </div>
        <div class="summary-item">
          <div class="summary-label">${S(`comfort.control_target`,e)}</div>
          <div class="summary-value">${n}</div>
        </div>
        <div class="summary-item">
          <div class="summary-label">${S(`comfort.night_mode`,e)}</div>
          <div class="summary-value ${t?`warning`:``}">
            ${S(t?`comfort.active`:`comfort.inactive`,e)}
          </div>
        </div>
        <div class="summary-item">
          <div class="summary-label">${S(`comfort.rapid_recovery`,e)}</div>
          <div class="summary-value ${this.rapidRecoveryActive?`warning`:``}">
            ${this.rapidRecoveryActive?S(`comfort.active`,e):S(`comfort.inactive`,e)}
          </div>
        </div>
        <div class="summary-item">
          <div class="summary-label">${S(`comfort.night_controls`,e)}</div>
          <div class="summary-value">${i}/${this.nightControls.length}</div>
        </div>
        <div class="summary-item">
          <div class="summary-label">${S(`comfort.room_coupling`,e)}</div>
          <div class="summary-value">${r}/${this.adjacentRooms.length}</div>
        </div>
      </div>
      <div class="muted">
        ${S(`comfort.summary`,e,{hours:this.quietHours?`${this.quietHours.start}–${this.quietHours.end}`:`--`,fan:this._percent(this.maxFanLevelNight),ramp:this.sleepTempRampC.toFixed(1)})}
      </div>
      ${this.couplingStatus.length?m`
            <div class="section-title">${S(`comfort.live_coupling`,e)}</div>
            <div class="list">
              ${this.couplingStatus.map(e=>this._renderCouplingView(e))}
            </div>
          `:h}
    `}_renderCouplingView(e){let t=this.language;return m`<div class="list-item">
      <div class="item-head">
        <span class="item-title">${this._areaName(e.area_id)}</span>
        <span class="pill ${e.gate>0?`active`:``}">
          ${S(`comfort.gate`,t)} ${e.gate.toFixed(1)}
        </span>
        <span class="pill">k ${e.k.toFixed(3)}</span>
      </div>
      <div class="muted">
        ${S(`comfort.adjacent_temp`,t,{temp:e.temperature.toFixed(1)})}
      </div>
    </div>`}_renderEdit(){let e=this.language;return m`
      <div class="config-grid">
        <div class="config-card">
          <div class="toggle-row">
            <div>
              <div class="toggle-title">${S(`comfort.night_mode`,e)}</div>
              <div class="toggle-hint">${S(`comfort.night_mode_hint`,e)}</div>
            </div>
            <ha-switch
              .checked=${this.nightModeEnabled}
              @change=${e=>this._emit(`night_mode_enabled`,e.target.checked)}
            ></ha-switch>
          </div>
          <div class="field-row">
            <ha-textfield
              .label=${S(`comfort.quiet_start`,e)}
              .value=${this.quietHours?.start??`22:00`}
              @input=${e=>this._updateQuiet(`start`,e.target.value)}
            ></ha-textfield>
            <ha-textfield
              .label=${S(`comfort.quiet_end`,e)}
              .value=${this.quietHours?.end??`07:00`}
              @input=${e=>this._updateQuiet(`end`,e.target.value)}
            ></ha-textfield>
          </div>
          <div class="field-row">
            ${this._numberField(`comfort.max_fan_level_night`,`max_fan_level_night`,this.maxFanLevelNight,0,1,.05)}
            ${this._numberField(`comfort.sleep_temp_ramp`,`sleep_temp_ramp_c`,this.sleepTempRampC,0,4,.1)}
          </div>
        </div>

        <div class="config-card">
          <ha-select
            .label=${S(`comfort.control_target`,e)}
            .value=${this.controlTarget}
            @selected=${e=>this._emit(`control_target`,P(e))}
            @closed=${e=>e.stopPropagation()}
            fixedMenuPosition
          >
            <ha-list-item value="air_temperature"
              >${S(`comfort.control_target_air`,e)}</ha-list-item
            >
            <ha-list-item value="perceived_temperature"
              >${S(`comfort.control_target_perceived`,e)}</ha-list-item
            >
          </ha-select>
          <div class="field-row">
            ${this._numberField(`comfort.room_volume`,`room_volume_m3`,this.roomVolumeM3??0,0,600,1)}
            ${this._numberField(`comfort.rapid_recovery_delta`,`rapid_recovery_delta_c`,this.rapidRecoveryDeltaC,.5,6,.1)}
          </div>
          <div class="toggle-row mode-text">
            <div>
              <div class="toggle-title">
                ${S(`comfort.night_allow_rapid_recovery`,e)}
              </div>
              <div class="toggle-hint">
                ${S(`comfort.night_allow_rapid_recovery_hint`,e)}
              </div>
            </div>
            <ha-switch
              .checked=${this.nightAllowRapidRecovery}
              @change=${e=>this._emit(`night_allow_rapid_recovery`,e.target.checked)}
            ></ha-switch>
          </div>
        </div>
      </div>

      <div class="section-title">${S(`comfort.night_controls`,e)}</div>
      <div class="list">
        ${this.nightControls.length?this.nightControls.map((e,t)=>this._renderNightControlEdit(e,t)):m`<div class="empty">${S(`comfort.no_night_controls`,e)}</div>`}
      </div>
      <button class="add-btn" @click=${this._addNightControl}>
        + ${S(`comfort.add_night_control`,e)}
      </button>

      <div class="section-title">${S(`comfort.adjacent_rooms`,e)}</div>
      <div class="list">
        ${this.adjacentRooms.length?this.adjacentRooms.map((e,t)=>this._renderAdjacentEdit(e,t)):m`<div class="empty">${S(`comfort.no_adjacent_rooms`,e)}</div>`}
      </div>
      <button class="add-btn" @click=${this._addAdjacent}>
        + ${S(`comfort.add_adjacent_room`,e)}
      </button>
    `}_renderNightControlEdit(e,t){let n=this.language;return m`<div class="list-item">
      <div class="item-head">
        <div
          class="item-title ${e.entity_id?`entity-link`:``}"
          @click=${()=>e.entity_id&&zt(this,e.entity_id)}
        >
          ${e.entity_id||S(`comfort.night_control_new`,n)}
        </div>
        <ha-switch
          .checked=${e.enabled!==!1}
          @change=${e=>this._updateNightControl(t,{enabled:e.target.checked})}
        ></ha-switch>
        <button class="remove-btn" @click=${()=>this._removeNightControl(t)}>
          ${S(`common.remove`,n)}
        </button>
      </div>
      <ha-entity-picker
        .hass=${this.hass}
        .includeDomains=${[`light`,`switch`,`select`,`input_select`,`number`,`input_number`]}
        .value=${e.entity_id??``}
        .label=${S(`comfort.night_control_entity`,n)}
        @value-changed=${e=>this._updateNightControl(t,{entity_id:e.detail?.value||``})}
      ></ha-entity-picker>
      <div class="field-row">
        <ha-select
          .label=${S(`comfort.night_control_role`,n)}
          .value=${e.role??`other`}
          @selected=${e=>this._updateNightControl(t,{role:P(e)})}
          @closed=${e=>e.stopPropagation()}
          fixedMenuPosition
        >
          <ha-list-item value="indicator_light"
            >${S(`comfort.role_indicator_light`,n)}</ha-list-item
          >
          <ha-list-item value="display">${S(`comfort.role_display`,n)}</ha-list-item>
          <ha-list-item value="beeper">${S(`comfort.role_beeper`,n)}</ha-list-item>
          <ha-list-item value="sound">${S(`comfort.role_sound`,n)}</ha-list-item>
          <ha-list-item value="other">${S(`comfort.role_other`,n)}</ha-list-item>
        </ha-select>
        <ha-select
          .label=${S(`comfort.restore_after_night`,n)}
          .value=${e.restore_after_night===!1?`false`:`true`}
          @selected=${e=>this._updateNightControl(t,{restore_after_night:P(e)!==`false`})}
          @closed=${e=>e.stopPropagation()}
          fixedMenuPosition
        >
          <ha-list-item value="true">${S(`common.yes`,n)}</ha-list-item>
          <ha-list-item value="false">${S(`common.no`,n)}</ha-list-item>
        </ha-select>
      </div>
      <div class="field-row">
        <ha-textfield
          .label=${S(`comfort.night_value`,n)}
          .value=${String(e.night_value??`off`)}
          @input=${e=>this._updateNightControl(t,{night_value:e.target.value})}
        ></ha-textfield>
        <ha-textfield
          .label=${S(`comfort.day_value`,n)}
          .value=${String(e.day_value??``)}
          @input=${e=>this._updateNightControl(t,{day_value:e.target.value})}
        ></ha-textfield>
      </div>
    </div>`}_renderAdjacentEdit(e,t){let n=this.language,r=Object.values(this.hass.areas??{}).filter(e=>e.area_id!==this.area.area_id);return m`<div class="list-item">
      <div class="item-head">
        <div class="item-title">
          ${e.area_id?this._areaName(e.area_id):S(`comfort.adjacent_new`,n)}
        </div>
        <ha-switch
          .checked=${e.enabled!==!1}
          @change=${e=>this._updateAdjacent(t,{enabled:e.target.checked})}
        ></ha-switch>
        <button class="remove-btn" @click=${()=>this._removeAdjacent(t)}>
          ${S(`common.remove`,n)}
        </button>
      </div>
      <ha-select
        .label=${S(`comfort.adjacent_room`,n)}
        .value=${e.area_id??``}
        @selected=${e=>this._updateAdjacent(t,{area_id:P(e)})}
        @closed=${e=>e.stopPropagation()}
        fixedMenuPosition
      >
        <ha-list-item value="">${S(`comfort.select_room`,n)}</ha-list-item>
        ${r.map(e=>m`<ha-list-item value=${e.area_id}>${e.name}</ha-list-item>`)}
      </ha-select>
      <div class="field-row">
        <ha-entity-picker
          .hass=${this.hass}
          .includeDomains=${[`binary_sensor`,`input_boolean`,`sensor`]}
          .value=${e.door_sensor_entity||e.link_sensor_entity||``}
          .label=${S(`comfort.door_sensor`,n)}
          @value-changed=${e=>this._updateAdjacent(t,{door_sensor_entity:e.detail?.value||``,link_sensor_entity:e.detail?.value||``})}
        ></ha-entity-picker>
        ${this._numberField(`comfort.coupling_weight`,`adjacent:${t}:coupling_weight`,e.coupling_weight??0,0,2,.01)}
      </div>
      <div class="toggle-row mode-text">
        <div>
          <div class="toggle-title">${S(`comfort.allow_borrowed_conditioning`,n)}</div>
          <div class="toggle-hint">
            ${S(`comfort.allow_borrowed_conditioning_hint`,n)}
          </div>
        </div>
        <ha-switch
          .checked=${e.allow_borrowed_conditioning!==!1}
          @change=${e=>this._updateAdjacent(t,{allow_borrowed_conditioning:e.target.checked})}
        ></ha-switch>
      </div>
    </div>`}_numberField(e,t,n,r,i,a){return m`<ha-textfield
      .label=${S(e,this.language)}
      type="number"
      .min=${String(r)}
      .max=${String(i)}
      .step=${String(a)}
      .value=${String(n)}
      @input=${e=>this._onNumberInput(t,e)}
    ></ha-textfield>`}_onNumberInput(e,t){let n=Number(t.target.value);if(!Number.isFinite(n))return;if(e.startsWith(`adjacent:`)){let[,t,r]=e.split(`:`);this._updateAdjacent(Number(t),{[r]:n});return}let r=e===`room_volume_m3`&&n<=0?null:n;this._emit(e,r)}_updateQuiet(e,t){let n={start:this.quietHours?.start??`22:00`,end:this.quietHours?.end??`07:00`,[e]:t};this._emit(`quiet_hours`,n)}_updateNightControl(e,t){let n=this.nightControls.map((n,r)=>r===e?{...n,...t}:n);this._emit(`night_controls`,n)}_removeNightControl(e){this._emit(`night_controls`,this.nightControls.filter((t,n)=>n!==e))}_updateAdjacent(e,t){let n=this.adjacentRooms.map((n,r)=>r===e?{...n,...t}:n);this._emit(`adjacent_rooms`,n)}_removeAdjacent(e){this._emit(`adjacent_rooms`,this.adjacentRooms.filter((t,n)=>n!==e))}_emit(e,t){this.dispatchEvent(new CustomEvent(`setting-changed`,{detail:{key:e,value:t},bubbles:!0,composed:!0}))}_areaName(e){return this.hass.areas?.[e]?.name??e}_percent(e){return`${Math.round(Math.max(0,Math.min(1,Number(e??0)))*100)}%`}};k([y({attribute:!1})],H.prototype,`hass`,void 0),k([y({attribute:!1})],H.prototype,`area`,void 0),k([y({type:Boolean})],H.prototype,`editing`,void 0),k([y({type:Number})],H.prototype,`currentTemp`,void 0),k([y({type:Number})],H.prototype,`perceivedTemp`,void 0),k([y({type:Number})],H.prototype,`currentHumidity`,void 0),k([y()],H.prototype,`controlTarget`,void 0),k([y({type:Number})],H.prototype,`roomVolumeM3`,void 0),k([y({attribute:!1})],H.prototype,`quietHours`,void 0),k([y({type:Boolean})],H.prototype,`nightModeEnabled`,void 0),k([y({type:Number})],H.prototype,`maxFanLevelNight`,void 0),k([y({type:Number})],H.prototype,`sleepTempRampC`,void 0),k([y({type:Boolean})],H.prototype,`nightAllowRapidRecovery`,void 0),k([y({type:Number})],H.prototype,`rapidRecoveryDeltaC`,void 0),k([y({attribute:!1})],H.prototype,`nightMode`,void 0),k([y({attribute:!1})],H.prototype,`nightControls`,void 0),k([y({attribute:!1})],H.prototype,`nightControlStatus`,void 0),k([y({attribute:!1})],H.prototype,`adjacentRooms`,void 0),k([y({attribute:!1})],H.prototype,`couplingStatus`,void 0),k([y({type:Boolean})],H.prototype,`rapidRecoveryActive`,void 0),k([y()],H.prototype,`language`,void 0),H=k([v(`rs-comfort-section`)],H),_(),x(),A();var Gt=class extends g{constructor(...e){super(...e),this.label=``,this.hint=``}static{this.styles=l`
    :host {
      display: inline-block;
    }

    .badge {
      font-size: 10px;
      font-weight: 600;
      color: var(--primary-color);
      background: color-mix(in srgb, var(--primary-color) 12%, transparent);
      padding: 2px 6px;
      border-radius: 4px;
      letter-spacing: 0.5px;
      text-transform: uppercase;
      cursor: default;
    }
  `}render(){return m`<span class="badge" title=${this.hint}>${this.label}</span>`}};k([y({type:String})],Gt.prototype,`label`,void 0),k([y({type:String})],Gt.prototype,`hint`,void 0),Gt=k([v(`rs-badge`)],Gt),_(),x(),A();var Kt=`M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z`,qt=class extends g{constructor(...e){super(...e),this.icon=``,this.heading=``,this.badge=``,this.badgeHint=``,this.editable=!1}static{this.styles=l`
    :host {
      display: block;
    }

    ha-card {
      overflow: hidden;
      min-width: 0;
    }

    .section-header {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 16px 20px 12px;
    }

    .section-icon {
      --mdc-icon-size: 18px;
      opacity: 0.7;
    }

    .section-title {
      font-size: 15px;
      font-weight: 500;
      color: var(--primary-text-color);
      margin: 0;
      flex: 1;
    }

    .edit-btn {
      --mdc-icon-button-size: 32px;
      --mdc-icon-size: 18px;
      color: var(--secondary-text-color);
      margin: -4px -8px -4px 0;
      transition: opacity 0.15s ease;
    }

    @media (hover: hover) {
      .edit-btn {
        opacity: 0;
      }

      ha-card:hover .edit-btn,
      ha-card:focus-within .edit-btn {
        opacity: 1;
      }
    }

    .section-body {
      padding: 0 20px 20px;
    }
  `}render(){return m`
      <ha-card>
        <div class="section-header">
          <ha-icon class="section-icon" icon=${this.icon}></ha-icon>
          <h3 class="section-title">${this.heading}</h3>
          ${this.badge?m`<rs-badge .label=${this.badge} .hint=${this.badgeHint}></rs-badge>`:h}
          <slot name="header-extras"></slot>
          ${this.editable?m`
                <ha-icon-button
                  class="edit-btn"
                  .path=${Kt}
                  @click=${this._onEditClick}
                ></ha-icon-button>
              `:h}
        </div>
        <div class="section-body">
          <slot></slot>
        </div>
      </ha-card>
    `}_onEditClick(){this.dispatchEvent(new CustomEvent(`edit-click`,{bubbles:!0,composed:!0}))}};k([y({type:String})],qt.prototype,`icon`,void 0),k([y({type:String})],qt.prototype,`heading`,void 0),k([y({type:String})],qt.prototype,`badge`,void 0),k([y({type:String})],qt.prototype,`badgeHint`,void 0),k([y({type:Boolean})],qt.prototype,`editable`,void 0),qt=k([v(`rs-section-card`)],qt),_(),x(),A();var U=class extends g{constructor(...e){super(...e),this.climateMode=`auto`,this.comfortHeat=21,this.comfortCool=24,this.ecoHeat=17,this.ecoCool=27,this.language=`en`,this._overridePending=null,this._overrideCustomTemp=21,this._overrideError=``,this._optimisticOverride=null,this._optimisticClear=!1}static{this.styles=[I,l`
      :host {
        display: block;
      }

      .override-divider {
        border: none;
        border-top: 1px solid var(--divider-color, #e0e0e0);
        margin: 16px 0 12px;
      }

      .override-label {
        font-size: 13px;
        font-weight: 500;
        color: var(--secondary-text-color);
        margin-bottom: 10px;
      }

      .override-presets {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
      }

      .override-preset {
        cursor: pointer;
        border: 1px solid var(--divider-color, #e0e0e0);
        border-radius: 8px;
        padding: 6px 12px;
        font-size: 13px;
        background: transparent;
        color: var(--primary-text-color);
        display: flex;
        align-items: center;
        gap: 6px;
        transition:
          background 0.15s,
          border-color 0.15s;
      }

      .override-preset:hover {
        background: rgba(0, 0, 0, 0.04);
      }

      .override-preset.pending {
        border-color: var(--primary-color);
        background: rgba(var(--rgb-primary-color, 33, 150, 243), 0.08);
      }

      .override-preset.active.boost {
        border-color: var(--warning-color, #ff9800);
        background: rgba(255, 152, 0, 0.15);
        color: var(--warning-color, #ff9800);
      }

      .override-preset.active.eco {
        border-color: #4caf50;
        background: rgba(76, 175, 80, 0.15);
        color: #4caf50;
      }

      .override-preset.active.custom {
        border-color: #2196f3;
        background: rgba(33, 150, 243, 0.15);
        color: #2196f3;
      }

      .override-preset:disabled {
        opacity: 0.35;
        cursor: default;
      }

      .override-preset:disabled:hover {
        background: transparent;
      }

      .override-preset ha-icon {
        --mdc-icon-size: 16px;
      }

      .override-target {
        display: block;
        width: 160px;
        margin-top: 12px;
      }

      .override-duration {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 12px;
        align-items: center;
      }

      .override-duration-label {
        font-size: 13px;
        font-weight: 500;
        color: var(--secondary-text-color);
      }

      .override-dur-chips {
        display: flex;
        gap: 6px;
      }

      .override-dur-chip {
        cursor: pointer;
        border: 1px solid var(--divider-color);
        border-radius: 8px;
        padding: 6px 14px;
        font-size: 13px;
        font-weight: 500;
        background: var(--card-background-color);
        color: var(--primary-text-color);
        transition:
          border-color 0.15s ease,
          background 0.15s ease;
      }

      .override-dur-chip:hover {
        background: rgba(255, 255, 255, 0.04);
        border-color: rgba(3, 169, 244, 0.4);
      }

      .override-dur-chip:disabled {
        opacity: 0.5;
        pointer-events: none;
      }

      .override-error {
        color: var(--error-color, #d32f2f);
        font-size: 12px;
        margin-top: 6px;
      }
    `]}updated(e){if(e.has(`config`)&&this.config?.live){let e=this.config.live;this._optimisticOverride&&e.override_active&&(this._optimisticOverride=null),this._optimisticClear&&!e.override_active&&(this._optimisticClear=!1)}}getEffectiveOverride(){if(this._optimisticClear)return{active:!1,type:null,temp:null,until:null};if(this._optimisticOverride)return{active:!0,type:this._optimisticOverride.type,temp:this._optimisticOverride.temp,until:this._optimisticOverride.until};let e=this.config?.live;return e?.override_active&&e.override_type?{active:!0,type:e.override_type,temp:e.override_temp,until:e.override_until}:{active:!1,type:null,temp:null,until:null}}render(){let e=this.getEffectiveOverride();return m`
      <hr class="override-divider" />
      <div class="override-label">${S(`override.label`,this.language)}</div>
      ${this._renderOverrideButtons(e)}
      ${this._overrideError?m`<div class="override-error">${this._overrideError}</div>`:h}
    `}_renderOverrideButtons(e){let t=e.active?e.type:null,n=!t&&this._overridePending;return m`
      <div class="override-presets">
        ${[`boost`,`eco`,`custom`].map(e=>{let n=t===e,r=t!==null&&!n,i=!t&&this._overridePending===e;return m`
            <button
              class="override-preset ${e} ${n?`active`:``} ${i?`pending`:``}"
              ?disabled=${r}
              @click=${()=>n?this._onClearOverride():this._onOverridePreset(e)}
            >
              <ha-icon
                icon=${e===`boost`?`mdi:fire`:e===`eco`?`mdi:leaf`:`mdi:thermometer`}
              ></ha-icon>
              ${S(e===`boost`?`override.comfort`:e===`eco`?`override.eco`:`override.custom`,this.language)}
            </button>
          `})}
      </div>
      ${n?m`
            ${this._overridePending===`custom`?m`
                  <ha-textfield
                    class="override-target"
                    type="number"
                    .label=${S(`override.target`,this.language)}
                    .suffix=${C(this.hass)}
                    min=${O(5,35,this.hass).min}
                    max=${O(5,35,this.hass).max}
                    step=${D(this.hass)}
                    .value=${String(w(this._overrideCustomTemp,this.hass))}
                    @input=${this._onOverrideCustomTempInput}
                  ></ha-textfield>
                `:h}
            <div class="override-duration">
              <span class="override-duration-label"
                >${S(`override.activate_for`,this.language)}</span
              >
              <div class="override-dur-chips">
                ${[{label:`1h`,hours:1},{label:`2h`,hours:2},{label:`4h`,hours:4}].map(e=>m`
                    <button
                      class="override-dur-chip"
                      @click=${()=>this._onOverrideActivate(e.hours)}
                    >
                      ${e.label}
                    </button>
                  `)}
              </div>
            </div>
          `:h}
    `}_onOverridePreset(e){this._overridePending===e?this._overridePending=null:(this._overridePending=e,e===`custom`&&(this._overrideCustomTemp=this.climateMode===`cool_only`?this.comfortCool:this.comfortHeat)),this._overrideError=``}_onOverrideCustomTempInput(e){this._overrideCustomTemp=At(Number(e.target.value)||w(21,this.hass),this.hass)}async _onOverrideActivate(e){if(!this._overridePending||!this.config)return;let t=this._overridePending,n;n=t===`boost`?this.climateMode===`cool_only`?this.comfortCool:this.comfortHeat:t===`eco`?this.climateMode===`cool_only`?this.ecoCool:this.ecoHeat:this._overrideCustomTemp,this._optimisticOverride={type:t,temp:n,until:Date.now()/1e3+e*3600},this._optimisticClear=!1,this._overridePending=null,this._overrideError=``;let r={type:`roommind/override/set`,area_id:this.config.area_id,override_type:t,duration:e};t===`custom`&&(r.temperature=n);try{await this.hass.callWS(r),this._fireRoomUpdated()}catch(e){this._optimisticOverride=null,this._overrideError=e instanceof Error?e.message:S(`override.error_set`,this.language),console.error(`Override set failed:`,e)}}async _onClearOverride(){if(this.config){this._optimisticClear=!0,this._optimisticOverride=null,this._overrideError=``;try{await this.hass.callWS({type:`roommind/override/clear`,area_id:this.config.area_id}),this._fireRoomUpdated()}catch(e){this._optimisticClear=!1,this._overrideError=e instanceof Error?e.message:S(`override.error_clear`,this.language),console.error(`Override clear failed:`,e)}}}_fireRoomUpdated(){this.dispatchEvent(new CustomEvent(`room-updated`,{bubbles:!0,composed:!0}))}};k([y({attribute:!1})],U.prototype,`hass`,void 0),k([y({attribute:!1})],U.prototype,`config`,void 0),k([y()],U.prototype,`climateMode`,void 0),k([y({type:Number})],U.prototype,`comfortHeat`,void 0),k([y({type:Number})],U.prototype,`comfortCool`,void 0),k([y({type:Number})],U.prototype,`ecoHeat`,void 0),k([y({type:Number})],U.prototype,`ecoCool`,void 0),k([y()],U.prototype,`language`,void 0),k([b()],U.prototype,`_overridePending`,void 0),k([b()],U.prototype,`_overrideCustomTemp`,void 0),k([b()],U.prototype,`_overrideError`,void 0),k([b()],U.prototype,`_optimisticOverride`,void 0),k([b()],U.prototype,`_optimisticClear`,void 0),U=k([v(`rs-override-section`)],U),_(),x(),A();var Jt=class extends g{constructor(...e){super(...e),this.label=``,this.hint=``,this.checked=!1,this.disabled=!1}static{this.styles=l`
    :host {
      display: block;
    }

    .toggle-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 16px;
    }

    .toggle-text {
      display: flex;
      align-items: center;
      gap: 4px;
      min-width: 0;
    }

    .toggle-label {
      font-weight: 500;
    }

    ha-switch {
      flex-shrink: 0;
    }
  `}render(){return m`
      <div class="toggle-row">
        <div class="toggle-text">
          <span class="toggle-label">${this.label}</span>
          ${this.hint?m`<rs-info-icon .text=${this.hint}></rs-info-icon>`:h}
        </div>
        <ha-switch
          .checked=${this.checked}
          .disabled=${this.disabled}
          @change=${this._onToggle}
        ></ha-switch>
      </div>
    `}_onToggle(e){this.dispatchEvent(new CustomEvent(`toggle-changed`,{detail:e.target.checked,bubbles:!0,composed:!0}))}};k([y({type:String})],Jt.prototype,`label`,void 0),k([y({type:String})],Jt.prototype,`hint`,void 0),k([y({type:Boolean})],Jt.prototype,`checked`,void 0),k([y({type:Boolean})],Jt.prototype,`disabled`,void 0),Jt=k([v(`rs-toggle-row`)],Jt),_(),x(),A();var W=class extends g{constructor(...e){super(...e),this.presenceEnabled=!1,this.presencePersons=[],this.selectedPresencePersons=[],this.ignorePresence=!1,this.editing=!1,this.language=`en`}static{this.styles=l`
    :host {
      display: block;
    }

    .presence-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      gap: 8px;
      margin-top: 12px;
    }

    .presence-card {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px 8px 6px;
      border: 1px solid var(--divider-color);
      border-radius: 10px;
      background: var(--card-background-color);
      cursor: pointer;
      transition:
        border-color 0.15s ease,
        background 0.15s ease;
      user-select: none;
    }

    .presence-card:hover {
      background: rgba(255, 255, 255, 0.03);
    }

    .presence-card.active {
      border-color: rgba(3, 169, 244, 0.4);
      background: rgba(3, 169, 244, 0.08);
    }

    .presence-card ha-checkbox {
      flex-shrink: 0;
    }

    .person-icon {
      --mdc-icon-size: 18px;
      color: var(--secondary-text-color);
      flex-shrink: 0;
    }

    .presence-card.active .person-icon {
      color: var(--primary-color);
    }

    .person-name {
      flex: 1;
      font-size: 14px;
      font-weight: 450;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .presence-list {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .presence-row {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 14px;
      border-radius: 8px;
      transition: background 0.3s;
    }

    .presence-row.home {
      background: rgba(76, 175, 80, 0.1);
    }

    .presence-row.away {
      background: rgba(0, 0, 0, 0.04);
    }

    .presence-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      flex-shrink: 0;
    }

    .presence-row.home .presence-dot {
      background: #4caf50;
      box-shadow: 0 0 6px rgba(76, 175, 80, 0.5);
    }

    .presence-row.away .presence-dot {
      background: var(--disabled-text-color, #bdbdbd);
    }

    .presence-name {
      flex: 1;
      font-size: 14px;
      font-weight: 500;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .presence-row.home .presence-name {
      color: var(--primary-text-color);
    }

    .presence-row.away .presence-name {
      color: var(--secondary-text-color);
    }

    .presence-state {
      font-size: 12px;
      white-space: nowrap;
    }

    .presence-row.home .presence-state {
      color: #2e7d32;
    }

    .presence-row.away .presence-state {
      color: var(--secondary-text-color);
    }

    .section-divider {
      border-top: 1px solid var(--divider-color, #e0e0e0);
      margin: 8px 0;
    }

    .field-hint {
      color: var(--secondary-text-color);
      font-size: 12px;
    }
  `}render(){return!this.presenceEnabled||this.presencePersons.length===0?h:this.editing?m`
      <rs-toggle-row
        .label=${S(`presence.ignore_toggle`,this.language)}
        .checked=${this.ignorePresence}
        @toggle-changed=${this._onIgnoreToggle}
      ></rs-toggle-row>
      ${this.ignorePresence?h:m`<div class="section-divider"></div>
            ${this._renderEditMode()}`}
    `:this.ignorePresence?m`<span class="field-hint"
          >${S(`presence.tile_ignored`,this.language)}</span
        >`:this._renderViewMode()}_renderEditMode(){return m`
      <div class="presence-grid">
        ${this.presencePersons.map(e=>{let t=this.selectedPresencePersons.includes(e),n=this.hass.states[e]?.attributes?.friendly_name??e.split(`.`).slice(1).join(`.`);return m`
            <div
              class="presence-card ${t?`active`:``}"
              role="checkbox"
              tabindex="0"
              aria-checked=${t}
              @click=${()=>this._onTogglePerson(e,t)}
              @keydown=${n=>{(n.key===`Enter`||n.key===` `)&&(n.preventDefault(),this._onTogglePerson(e,t))}}
            >
              <ha-checkbox
                .checked=${t}
                tabindex="-1"
                @click=${e=>e.stopPropagation()}
                @change=${()=>this._onTogglePerson(e,t)}
              ></ha-checkbox>
              <ha-icon class="person-icon" icon="mdi:account"></ha-icon>
              <span class="person-name">${n}</span>
            </div>
          `})}
      </div>
    `}_renderViewMode(){return this.selectedPresencePersons.length===0?m`<span class="field-hint"
        >${S(`presence.room_none_assigned`,this.language)}</span
      >`:m`
      <div class="presence-list">
        ${this.selectedPresencePersons.map(e=>{let t=this.hass.states[e]?.attributes?.friendly_name??e.split(`.`).slice(1).join(`.`),n=this.hass.states[e]?.state,r=e.startsWith(`person.`)||e.startsWith(`device_tracker.`)?n===`home`:n===`on`;return m`
            <div class="presence-row ${r?`home`:`away`}">
              <span class="presence-dot"></span>
              <span class="presence-name">${t}</span>
              <span class="presence-state"
                >${S(r?`presence.state_home`:`presence.state_away`,this.language)}</span
              >
            </div>
          `})}
      </div>
    `}_onIgnoreToggle(e){this.dispatchEvent(new CustomEvent(`ignore-presence-changed`,{detail:e.detail,bubbles:!0,composed:!0}))}_onTogglePerson(e,t){let n;n=t?this.selectedPresencePersons.filter(t=>t!==e):[...this.selectedPresencePersons,e],this.dispatchEvent(new CustomEvent(`presence-persons-changed`,{detail:n,bubbles:!0,composed:!0}))}};k([y({attribute:!1})],W.prototype,`hass`,void 0),k([y({type:Boolean})],W.prototype,`presenceEnabled`,void 0),k([y({attribute:!1})],W.prototype,`presencePersons`,void 0),k([y({attribute:!1})],W.prototype,`selectedPresencePersons`,void 0),k([y({type:Boolean})],W.prototype,`ignorePresence`,void 0),k([y({type:Boolean})],W.prototype,`editing`,void 0),k([y()],W.prototype,`language`,void 0),W=k([v(`rs-presence-section`)],W),_(),x(),A();var Yt=class extends g{constructor(...e){super(...e),this.label=``,this.suffix=``,this.hint=``}static{this.styles=[I,l`
      :host {
        display: block;
      }

      .row {
        display: flex;
        align-items: center;
        gap: 6px;
      }

      ha-textfield {
        display: block;
        flex: 1;
        min-width: 0;
      }

      rs-info-icon {
        flex-shrink: 0;
      }
    `]}render(){return m`
      <div class="row">
        <ha-textfield
          .label=${this.label}
          .suffix=${this.suffix}
          .value=${this.value==null?``:String(this.value)}
          .min=${this.min==null?``:String(this.min)}
          .max=${this.max==null?``:String(this.max)}
          .step=${this.step==null?``:String(this.step)}
          type="number"
          @input=${this._onInput}
        ></ha-textfield>
        ${this.hint?m`<rs-info-icon .text=${this.hint}></rs-info-icon>`:h}
      </div>
    `}_onInput(e){let t=parseFloat(e.target.value);isNaN(t)||this.dispatchEvent(new CustomEvent(`value-changed`,{detail:t,bubbles:!0,composed:!0}))}};k([y({type:String})],Yt.prototype,`label`,void 0),k([y({type:String})],Yt.prototype,`suffix`,void 0),k([y({type:Number})],Yt.prototype,`value`,void 0),k([y({type:Number})],Yt.prototype,`min`,void 0),k([y({type:Number})],Yt.prototype,`max`,void 0),k([y({type:Number})],Yt.prototype,`step`,void 0),k([y({type:String})],Yt.prototype,`hint`,void 0),Yt=k([v(`rs-threshold-field`)],Yt),_(),x(),A();var Xt=class extends Bt{constructor(...e){super(...e),this.schedules=[]}static{this.styles=[Bt.sharedStyles,I,l`
      .pos-badge {
        font-size: 0.8em;
        padding: 1px 6px;
        border-radius: 10px;
        background: var(--primary-color);
        color: var(--text-primary-color);
        flex-shrink: 0;
      }
      .gate-badge {
        font-size: 0.8em;
        padding: 1px 6px;
        border-radius: 10px;
        background: var(--accent-color, var(--primary-color));
        color: var(--text-primary-color);
        opacity: 0.8;
        flex-shrink: 0;
      }
      .mode-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 8px;
        padding: 4px 0 0;
      }
      @media (max-width: 480px) {
        .mode-row {
          grid-template-columns: 1fr;
        }
      }
      .mode-option {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 6px 12px;
        font-size: 13px;
        cursor: pointer;
        color: var(--primary-text-color);
        border: 1px solid var(--divider-color);
        border-radius: 8px;
        background: var(--card-background-color);
        transition:
          border-color 0.15s ease,
          background 0.15s ease;
      }
      .mode-option.active {
        border-color: rgba(3, 169, 244, 0.4);
        background: rgba(3, 169, 244, 0.08);
      }
    `]}render(){return this.editing?this._renderEdit():this._renderView()}_renderView(){let e=this.hass.language;if(this.schedules.length===0)return h;let t=this.schedules.length>=2;return m`
      <div class="schedule-list">
        ${this.schedules.map((n,r)=>{let i=this._getScheduleState(r,this.schedules.length),a=n.mode===`gate`,o=a?null:this._getBlockPosition(n.entity_id);return m`
            <div class="schedule-row ${i}">
              ${t?m`<span class="schedule-number">${r+1}</span>`:h}
              <span class="schedule-status-dot"></span>
              <span
                class="schedule-name schedule-link"
                @click=${()=>this._openEntityInfo(n.entity_id)}
                >${this._getFriendlyName(n.entity_id)}</span
              >
              ${a?m`<span class="gate-badge"
                    >${S(`covers.schedule_mode_gate_short`,e)}</span
                  >`:o===null?h:m`<span class="pos-badge">${o}%</span>`}
              <span class="schedule-status">${this._statusText(i,e)}</span>
            </div>
          `})}
      </div>
    `}_renderEdit(){let e=this.hass.language,t=this.schedules.length,n=new Set(this.schedules.map(e=>e.entity_id));return m`
      ${t>0?m`
            <div class="schedule-list">
              ${this.schedules.map((n,r)=>{let i=this._getScheduleState(r,t);return m`
                  <div class="schedule-row ${i}">
                    ${t>=2?m`<span class="schedule-number">${r+1}</span>`:h}
                    <span class="schedule-status-dot"></span>
                    <span class="schedule-name">${this._getFriendlyName(n.entity_id)}</span>
                    <span class="schedule-status">${this._statusText(i,e)}</span>
                    ${this._renderScheduleControls(r,t,(e,t)=>this._moveSchedule(e,t),e=>this._removeSchedule(e))}
                  </div>
                  <div class="mode-row">
                    <div
                      class="mode-option ${(n.mode??`force`)===`force`?`active`:``}"
                      role="radio"
                      tabindex="0"
                      aria-checked=${(n.mode??`force`)===`force`}
                      @click=${()=>this._updateMode(r,`force`)}
                      @keydown=${e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),this._updateMode(r,`force`))}}
                    >
                      <ha-radio
                        .checked=${(n.mode??`force`)===`force`}
                        tabindex="-1"
                      ></ha-radio>
                      ${S(`covers.schedule_mode_force`,e)}
                    </div>
                    <div
                      class="mode-option ${n.mode===`gate`?`active`:``}"
                      role="radio"
                      tabindex="0"
                      aria-checked=${n.mode===`gate`}
                      @click=${()=>this._updateMode(r,`gate`)}
                      @keydown=${e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),this._updateMode(r,`gate`))}}
                    >
                      <ha-radio .checked=${n.mode===`gate`} tabindex="-1"></ha-radio>
                      ${S(`covers.schedule_mode_gate`,e)}
                    </div>
                  </div>
                `})}
            </div>
          `:h}
      ${this._renderAddRow(S(`covers.add_schedule`,e),this._getAvailableEntities(n),e=>this._addSchedule(e),S(`covers.schedule_create_link`,e))}
      ${this._renderSelectorSection(t,S(`covers.schedule_selector`,e),S(`covers.schedule_selector_hint`,e),S(`covers.schedule_selector_warning`,e),e=>this._emitSelectorChanged(e))}
    `}_getBlockPosition(e){let t=this.hass?.states?.[e];if(!t||t.state!==`on`)return null;let n=t.attributes?.position;return n==null?null:Number(n)}_statusText(e,t){return S(e===`active`?`covers.schedule_state_active`:e===`unreachable`?`covers.schedule_state_unreachable`:`covers.schedule_state_inactive`,t)}_addSchedule(e){this._emitSchedules([...this.schedules,{entity_id:e,mode:`force`}])}_removeSchedule(e){this._emitSchedules(this.schedules.filter((t,n)=>n!==e))}_moveSchedule(e,t){let n=e+t;if(n<0||n>=this.schedules.length)return;let r=[...this.schedules];[r[e],r[n]]=[r[n],r[e]],this._emitSchedules(r)}_updateMode(e,t){let n=this.schedules.map((n,r)=>r===e?{...n,mode:t}:n);this._emitSchedules(n)}_emitSchedules(e){this.dispatchEvent(new CustomEvent(`cover-schedules-changed`,{detail:{value:e},bubbles:!0,composed:!0}))}_emitSelectorChanged(e){this.dispatchEvent(new CustomEvent(`cover-schedule-selector-changed`,{detail:{value:e},bubbles:!0,composed:!0}))}};k([y({attribute:!1})],Xt.prototype,`schedules`,void 0),Xt=k([v(`rs-cover-schedule`)],Xt),_(),x(),A();var Zt,G=class extends g{static{Zt=this}constructor(...e){super(...e),this.selectedCovers=new Set,this.editing=!1,this.autoEnabled=!1,this.deployThreshold=1.5,this.minPosition=0,this.overrideMinutes=60,this.autoPaused=!1,this.coverSchedules=[],this.coverScheduleSelectorEntity=``,this.activeCoverScheduleIndex=-1,this.nightClose=!1,this.nightPosition=0,this.snapDeploy=!1,this.forcedReason=``,this.coverOrientations={},this.nightCloseElevation=0,this.nightCloseOffsetMinutes=0,this.outdoorMinTemp=10,this.coverMinPositions={},this._selectedForEdit=``,this._scheduleCollapsed=!0,this._solarCollapsed=!0,this._entityFilter=e=>{let t=e.entity_id;return t.startsWith(`cover.roommind_`)?!1:t.startsWith(`cover.`)&&!this.selectedCovers.has(t)}}willUpdate(e){e.has(`selectedCovers`)&&(this._selectedForEdit&&!this.selectedCovers.has(this._selectedForEdit)&&(this._selectedForEdit=``),!this._selectedForEdit&&this.selectedCovers.size>0&&(this._selectedForEdit=[...this.selectedCovers][0]))}static{this.styles=[Ut,I,l`
      :host {
        display: block;
      }

      /* Tile view rows (match rs-sensor-section visual rhythm) */
      .view-row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 6px 0;
        font-size: 14px;
        color: var(--primary-text-color);
      }

      .view-name {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .view-pill {
        font-size: 10px;
        font-weight: 500;
        padding: 1px 7px;
        border-radius: 8px;
        background: rgba(255, 255, 255, 0.05);
        color: var(--secondary-text-color);
        letter-spacing: 0.3px;
        text-transform: uppercase;
        flex-shrink: 0;
      }

      .view-value {
        font-weight: 500;
        flex-shrink: 0;
        color: var(--primary-text-color);
      }

      /* Device-row style (matches rs-device-section) */
      .device-list-scroll {
        max-height: 210px;
        overflow-y: auto;
      }
      .device-row {
        display: flex;
        align-items: center;
        padding: 4px 0;
        margin-bottom: 2px;
        border-radius: 8px;
        transition: background 0.15s;
      }
      .device-row:hover {
        background: rgba(0, 0, 0, 0.02);
      }
      .device-row.selected {
        background: rgba(3, 169, 244, 0.035);
      }
      .device-row ha-checkbox {
        flex-shrink: 0;
      }
      .device-info {
        flex: 1;
        min-width: 0;
      }
      .device-name-row {
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .device-name {
        font-size: 14px;
        font-weight: 450;
      }
      .device-value {
        margin-left: auto;
        font-size: 13px;
        font-weight: 500;
        padding-right: 4px;
        white-space: nowrap;
      }
      .device-entity {
        font-family: var(--code-font-family, monospace);
        font-size: 11px;
        color: var(--secondary-text-color);
        opacity: 0.7;
      }
      .external-badge {
        display: inline-flex;
        align-items: center;
        font-size: 10px;
        font-weight: 500;
        color: var(--secondary-text-color);
        background: var(--divider-color, rgba(0, 0, 0, 0.06));
        padding: 1px 6px;
        border-radius: 4px;
        white-space: nowrap;
      }
      .no-devices {
        color: var(--secondary-text-color);
        font-size: 13px;
        padding: 8px 0;
      }

      .entity-picker-wrap {
        margin-top: 8px;
      }
      ha-entity-picker {
        width: 100%;
      }
      .settings-group {
        margin-top: 16px;
        display: flex;
        flex-direction: column;
        gap: 12px;
      }
      .sub-section {
        margin-top: 20px;
        display: flex;
        flex-direction: column;
        gap: 12px;
      }
      .sub-section:first-child {
        margin-top: 8px;
      }
      .sub-section-header {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 13px;
        font-weight: 500;
        color: var(--secondary-text-color);
        text-transform: uppercase;
        letter-spacing: 0.3px;
        padding-bottom: 4px;
        border-bottom: 1px solid var(--divider-color, rgba(0, 0, 0, 0.12));
      }
      .sub-section-header ha-icon {
        --mdc-icon-size: 18px;
      }
      .field-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
      }
      @media (max-width: 450px) {
        .field-row {
          grid-template-columns: 1fr;
        }
      }
      .no-items {
        color: var(--secondary-text-color);
        font-size: 0.9em;
        margin: 0;
      }
      .status-hint {
        display: flex;
        align-items: center;
        gap: 6px;
        color: var(--secondary-text-color);
        font-size: 0.85em;
      }
      .status-hint.paused {
        color: var(--warning-color, #ff9800);
      }
      .pill {
        font-size: 10px;
        font-weight: 500;
        padding: 1px 6px;
        border-radius: 10px;
        background: var(--divider-color, rgba(0, 0, 0, 0.08));
        color: var(--secondary-text-color);
        white-space: nowrap;
      }

      /* Editing layout — feature card + grouped sections */
      .feature-card {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 14px 16px;
        border: 1px solid var(--divider-color);
        border-radius: 12px;
        background: var(--card-background-color);
        transition:
          border-color 0.2s ease,
          background 0.2s ease;
      }

      .feature-card.enabled {
        border-color: rgba(3, 169, 244, 0.4);
        background: rgba(3, 169, 244, 0.06);
      }

      .feature-text {
        flex: 1;
        min-width: 0;
      }

      .feature-title {
        font-size: 14px;
        font-weight: 500;
        margin: 0 0 4px;
      }

      .feature-description {
        font-size: 12px;
        color: var(--secondary-text-color);
        line-height: 1.5;
        margin: 0;
      }

      .feature-card ha-switch {
        flex-shrink: 0;
      }

      .group-card {
        margin-top: 16px;
        border: 1px solid var(--divider-color);
        border-radius: 12px;
        background: var(--card-background-color);
        padding: 14px 16px;
        display: flex;
        flex-direction: column;
        gap: 12px;
      }

      .group-header {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.4px;
        color: var(--secondary-text-color);
        cursor: pointer;
        user-select: none;
      }

      .group-header > span:first-of-type {
        flex: 1;
        min-width: 0;
      }

      .group-header ha-icon {
        --mdc-icon-size: 18px;
        color: var(--secondary-text-color);
      }

      .group-header .chevron {
        transition: transform 0.2s ease;
        margin-left: auto;
      }

      .group-header .chevron.collapsed {
        transform: rotate(-90deg);
      }

      .group-card.collapsed {
        gap: 0;
        padding-bottom: 14px;
      }

      .group-divider {
        height: 1px;
        background: var(--divider-color);
        margin: 4px -16px;
      }
    `]}render(){let e=this.hass.language;return this.editing?this._renderEdit(e):this._renderView(e)}_renderView(e){let t=[...this.selectedCovers];return t.length===0?m`<p class="no-items">${S(`covers.no_covers`,e)}</p>`:m`
      ${t.map(t=>{let n=this.hass.states[t],r=n?.attributes?.friendly_name??t,i=n?.attributes?.current_position,a=this.coverOrientations[t],o=a===void 0?void 0:Zt._DIRECTIONS.find(e=>e.deg===a),s=o?S(o.shortLabel,e):void 0,c=this.coverMinPositions[t];return m`
          <div class="view-row">
            <span class="view-name">${r}</span>
            ${s?m`<span class="view-pill">${s}</span>`:h}
            ${c!==void 0&&c>0?m`<span class="view-pill"
                  >${S(`covers.per_cover_min_short`,e)} ${c}%</span
                >`:h}
            ${i===void 0?h:m`<span class="view-value">${i}%</span>`}
          </div>
        `})}
      ${this.autoPaused?m`
            <div class="status-hint paused">
              <ha-icon icon="mdi:hand-back-right"></ha-icon>
              <span>${S(`covers.auto_paused`,e)}</span>
            </div>
          `:this.autoEnabled?m`
              <div class="status-hint">
                <ha-icon icon="mdi:sun-angle-outline"></ha-icon>
                <span>${S(`covers.shading_active`,e)}</span>
              </div>
            `:h}
      ${this.forcedReason===`schedule_active`?m`
            <div class="status-hint">
              <ha-icon icon="mdi:calendar-clock"></ha-icon>
              <span>${S(`covers.schedule_active`,e)}</span>
            </div>
          `:this.forcedReason===`night_close`?m`
              <div class="status-hint">
                <ha-icon icon="mdi:weather-night"></ha-icon>
                <span>${S(`covers.night_close_active`,e)}</span>
              </div>
            `:h}
    `}_renderMasterRow(e,t){let n=this.selectedCovers.has(e),r=this._selectedForEdit===e,i=this.hass.states[e],a=i?.attributes?.friendly_name||e,o=i?.attributes?.current_position,s=this.hass.language,c=this.coverOrientations[e],l=c===void 0?void 0:Zt._DIRECTIONS.find(e=>e.deg===c),u=l?S(l.shortLabel,s):``,d=this.coverMinPositions[e];return m`
      <div
        class="master-row ${r?`focused`:``}"
        @click=${()=>this._selectedForEdit=e}
      >
        <ha-checkbox
          .checked=${n}
          @click=${e=>e.stopPropagation()}
          @change=${t=>{let n=t.target;this._onToggle(e,n.checked),n.checked&&(this._selectedForEdit=e)}}
        ></ha-checkbox>
        <div class="master-info">
          <div class="master-name-row">
            <span class="master-name">${a}</span>
            ${t?m`<span class="external-badge">${S(`devices.other_area`,s)}</span>`:h}
          </div>
          <div class="master-meta">
            ${u?m`<span class="meta-pill">${u}</span>`:h}
            ${d!==void 0&&d>0?m`<span class="meta-pill">min ${d}%</span>`:h}
            ${o===void 0?h:m`<span class="meta-pill" style="color: var(--primary-color);">${o}%</span>`}
          </div>
        </div>
      </div>
    `}_renderCoverDetail(e){let t=this.hass.language,n=this.hass.states[e]?.attributes?.friendly_name||e,r=this.coverOrientations[e],i=this.coverMinPositions[e];return m`
      <div class="detail-head">
        <div class="detail-title">${n}</div>
        <div class="detail-entity-id">${e}</div>
      </div>
      <div class="detail-field">
        <ha-select
          .label=${S(`covers.orientation_group_title`,t)}
          .value=${r===void 0?``:String(r)}
          .options=${[{value:``,label:S(`covers.orientation_none`,t)},...Zt._DIRECTIONS.map(e=>({value:String(e.deg),label:S(e.longLabel,t)}))]}
          fixedMenuPosition
          @selected=${t=>{let n=P(t);this._setOrientation(e,n===``?void 0:Number(n))}}
          @closed=${e=>e.stopPropagation()}
        >
          <ha-list-item value="">${S(`covers.orientation_none`,t)}</ha-list-item>
          ${Zt._DIRECTIONS.map(e=>m`
              <ha-list-item value=${String(e.deg)}>${S(e.longLabel,t)}</ha-list-item>
            `)}
        </ha-select>
      </div>
      <div class="detail-field">
        <rs-threshold-field
          .label=${S(`covers.per_cover_min_position`,t)}
          .value=${i??0}
          .min=${0}
          .max=${99}
          .step=${1}
          suffix="%"
          @value-changed=${t=>this._setMinPosition(e,t.detail)}
        ></rs-threshold-field>
      </div>
    `}_renderEdit(e){let t=Ct(this.area.area_id,this.hass?.entities,this.hass?.devices).filter(e=>!e.entity_id.substring(e.entity_id.indexOf(`.`)+1).startsWith(`roommind_`)).filter(e=>e.entity_id.startsWith(`cover.`)),n=new Set(t.map(e=>e.entity_id)),r=[...this.selectedCovers].filter(e=>!n.has(e)),i=this.selectedCovers.size>0,a=this._selectedForEdit,o=a&&this.selectedCovers.has(a);return m`
      <rs-master-detail>
        <div slot="master" class="master">
          <div class="block-title">${S(`covers.add_cover`,e)}</div>
          <div class="master-list">
            ${t.length>0?t.map(e=>this._renderMasterRow(e.entity_id,!1)):m`<div class="empty-list">${S(`covers.no_covers_in_area`,e)}</div>`}
            ${r.map(e=>this._renderMasterRow(e,!0))}
          </div>
          <div class="picker-wrap">
            <ha-entity-picker
              .hass=${this.hass}
              .includeDomains=${[`cover`]}
              .entityFilter=${this._entityFilter}
              .value=${``}
              .label=${S(`covers.add_cover`,e)}
              @value-changed=${this._onEntityPicked}
            ></ha-entity-picker>
          </div>
        </div>
        <div slot="detail">
          ${o?m`<div class="detail-panel">${this._renderCoverDetail(a)}</div>`:m`<div class="detail-panel">
                <div class="empty-detail">
                  <ha-icon icon="mdi:gesture-tap"></ha-icon>
                  <span>${S(`devices.select_to_configure`,e)}</span>
                </div>
              </div>`}
        </div>
      </rs-master-detail>

      ${i?m`
            <div class="block-divider"></div>
            <div class="feature-card ${this.autoEnabled?`enabled`:``}">
              <div class="feature-text">
                <div class="feature-title">${S(`covers.auto_control`,e)}</div>
                <div class="feature-description">${S(`covers.auto_control_hint`,e)}</div>
              </div>
              <ha-switch
                .checked=${this.autoEnabled}
                @change=${e=>this._emit(`covers_auto_enabled`,e.target.checked)}
              ></ha-switch>
            </div>

            ${this.autoEnabled?m`
                  <div class="group-card ${this._scheduleCollapsed?`collapsed`:``}">
                    <div
                      class="group-header"
                      @click=${()=>this._scheduleCollapsed=!this._scheduleCollapsed}
                    >
                      <ha-icon icon="mdi:calendar-clock"></ha-icon>
                      <span>${S(`covers.schedule_group_title`,e)}</span>
                      <rs-info-icon
                        .text=${S(`covers.schedule_section_hint`,e)}
                      ></rs-info-icon>
                      <ha-icon
                        class="chevron ${this._scheduleCollapsed?`collapsed`:``}"
                        icon="mdi:chevron-down"
                      ></ha-icon>
                    </div>
                    ${this._scheduleCollapsed?h:m`<rs-cover-schedule
                            .hass=${this.hass}
                            .schedules=${this.coverSchedules}
                            .selectorEntity=${this.coverScheduleSelectorEntity}
                            .activeIndex=${this.activeCoverScheduleIndex}
                            .editing=${!0}
                            @cover-schedules-changed=${e=>this._emit(`cover_schedules`,e.detail.value)}
                            @cover-schedule-selector-changed=${e=>this._emit(`cover_schedule_selector_entity`,e.detail.value)}
                          ></rs-cover-schedule>
                          <div class="group-divider"></div>
                          <rs-toggle-row
                            .label=${S(`covers.night_close`,e)}
                            .hint=${S(`covers.night_close_hint`,e)}
                            .checked=${this.nightClose}
                            @toggle-changed=${e=>this._emit(`covers_night_close`,e.detail)}
                          ></rs-toggle-row>
                          ${this.nightClose?m`
                                <rs-threshold-field
                                  .label=${S(`covers.night_position`,e)}
                                  .hint=${S(`covers.night_position_hint`,e)}
                                  .value=${this.nightPosition}
                                  .min=${0}
                                  .max=${100}
                                  .step=${5}
                                  suffix="%"
                                  @value-changed=${e=>this._emit(`covers_night_position`,e.detail)}
                                ></rs-threshold-field>
                                <ha-expansion-panel
                                  .header=${S(`covers.night_close_advanced`,e)}
                                  outlined
                                >
                                  <div class="field-row" style="padding:8px 0;">
                                    <rs-threshold-field
                                      .label=${S(`covers.night_close_elevation`,e)}
                                      .hint=${S(`covers.night_close_elevation_hint`,e)}
                                      .value=${this.nightCloseElevation}
                                      .min=${-18}
                                      .max=${10}
                                      .step=${1}
                                      suffix="°"
                                      @value-changed=${e=>this._emit(`covers_night_close_elevation`,e.detail)}
                                    ></rs-threshold-field>
                                    <rs-threshold-field
                                      .label=${S(`covers.night_close_offset`,e)}
                                      .hint=${S(`covers.night_close_offset_hint`,e)}
                                      .value=${this.nightCloseOffsetMinutes}
                                      .min=${-120}
                                      .max=${120}
                                      .step=${5}
                                      suffix="min"
                                      @value-changed=${e=>this._emit(`covers_night_close_offset_minutes`,e.detail)}
                                    ></rs-threshold-field>
                                  </div>
                                </ha-expansion-panel>
                              `:h}`}
                  </div>

                  <div class="group-card ${this._solarCollapsed?`collapsed`:``}">
                    <div
                      class="group-header"
                      @click=${()=>this._solarCollapsed=!this._solarCollapsed}
                    >
                      <ha-icon icon="mdi:white-balance-sunny"></ha-icon>
                      <span>${S(`covers.solar_group_title`,e)}</span>
                      <ha-icon
                        class="chevron ${this._solarCollapsed?`collapsed`:``}"
                        icon="mdi:chevron-down"
                      ></ha-icon>
                    </div>
                    ${this._solarCollapsed?h:m`<div class="field-row">
                            <rs-threshold-field
                              .label=${S(`covers.deploy_threshold`,e)}
                              .hint=${S(`covers.deploy_threshold_hint`,e)}
                              .value=${this.deployThreshold}
                              .min=${.5}
                              .max=${5}
                              .step=${.5}
                              suffix="°C"
                              @value-changed=${e=>this._emit(`covers_deploy_threshold`,e.detail)}
                            ></rs-threshold-field>
                            <rs-threshold-field
                              .label=${S(`covers.min_position`,e)}
                              .hint=${S(`covers.min_position_hint`,e)}
                              .value=${this.minPosition}
                              .min=${0}
                              .max=${80}
                              .step=${5}
                              suffix="%"
                              @value-changed=${e=>this._emit(`covers_min_position`,e.detail)}
                            ></rs-threshold-field>
                          </div>
                          <div class="field-row">
                            <rs-threshold-field
                              .label=${S(`covers.override_minutes`,e)}
                              .hint=${S(`covers.override_minutes_hint`,e)}
                              .value=${this.overrideMinutes}
                              .min=${0}
                              .max=${480}
                              .step=${15}
                              suffix="min"
                              @value-changed=${e=>this._emit(`covers_override_minutes`,e.detail)}
                            ></rs-threshold-field>
                            <rs-threshold-field
                              .label=${S(`covers.outdoor_min_temp`,e)}
                              .hint=${S(`covers.outdoor_min_temp_hint`,e)}
                              .value=${this.outdoorMinTemp??10}
                              .min=${0}
                              .max=${35}
                              .step=${1}
                              suffix="°C"
                              @value-changed=${e=>this._emit(`covers_outdoor_min_temp`,e.detail)}
                            ></rs-threshold-field>
                          </div>
                          <div class="group-divider"></div>
                          <rs-toggle-row
                            .label=${S(`covers.snap_deploy`,e)}
                            .hint=${S(`covers.snap_deploy_hint`,e)}
                            .checked=${this.snapDeploy}
                            @toggle-changed=${e=>this._emit(`covers_snap_deploy`,e.detail)}
                          ></rs-toggle-row>`}
                  </div>
                `:h}
          `:h}
    `}static{this._DIRECTIONS=[{shortLabel:`covers.orientation_N`,longLabel:`covers.orientation_N_full`,deg:0},{shortLabel:`covers.orientation_NE`,longLabel:`covers.orientation_NE_full`,deg:45},{shortLabel:`covers.orientation_E`,longLabel:`covers.orientation_E_full`,deg:90},{shortLabel:`covers.orientation_SE`,longLabel:`covers.orientation_SE_full`,deg:135},{shortLabel:`covers.orientation_S`,longLabel:`covers.orientation_S_full`,deg:180},{shortLabel:`covers.orientation_SW`,longLabel:`covers.orientation_SW_full`,deg:225},{shortLabel:`covers.orientation_W`,longLabel:`covers.orientation_W_full`,deg:270},{shortLabel:`covers.orientation_NW`,longLabel:`covers.orientation_NW_full`,deg:315}]}_setMinPosition(e,t){let n={...this.coverMinPositions};n[e]=t,this._emit(`cover_min_positions`,n)}_setOrientation(e,t){let n={...this.coverOrientations};t===void 0?delete n[e]:n[e]=t,this._emit(`cover_orientations`,n)}_onEntityPicked(e){e.stopPropagation();let t=e.detail.value;if(!t)return;this._onToggle(t,!0);let n=e.target;n.value=``}_onToggle(e,t){this.dispatchEvent(new CustomEvent(`covers-toggle`,{detail:{entityId:e,checked:t},bubbles:!0,composed:!0}))}_emit(e,t){this.dispatchEvent(new CustomEvent(`setting-changed`,{detail:{key:e,value:t},bubbles:!0,composed:!0}))}};k([y({attribute:!1})],G.prototype,`hass`,void 0),k([y({attribute:!1})],G.prototype,`area`,void 0),k([y({attribute:!1})],G.prototype,`selectedCovers`,void 0),k([y({type:Boolean})],G.prototype,`editing`,void 0),k([y({type:Boolean})],G.prototype,`autoEnabled`,void 0),k([y({type:Number})],G.prototype,`deployThreshold`,void 0),k([y({type:Number})],G.prototype,`minPosition`,void 0),k([y({type:Number})],G.prototype,`overrideMinutes`,void 0),k([y({type:Boolean})],G.prototype,`autoPaused`,void 0),k([y({attribute:!1})],G.prototype,`coverSchedules`,void 0),k([y({type:String})],G.prototype,`coverScheduleSelectorEntity`,void 0),k([y({type:Number})],G.prototype,`activeCoverScheduleIndex`,void 0),k([y({type:Boolean})],G.prototype,`nightClose`,void 0),k([y({type:Number})],G.prototype,`nightPosition`,void 0),k([y({type:Boolean})],G.prototype,`snapDeploy`,void 0),k([y({type:String})],G.prototype,`forcedReason`,void 0),k([y({attribute:!1})],G.prototype,`coverOrientations`,void 0),k([y({type:Number})],G.prototype,`nightCloseElevation`,void 0),k([y({type:Number})],G.prototype,`nightCloseOffsetMinutes`,void 0),k([y({type:Number})],G.prototype,`outdoorMinTemp`,void 0),k([y({attribute:!1})],G.prototype,`coverMinPositions`,void 0),k([b()],G.prototype,`_selectedForEdit`,void 0),k([b()],G.prototype,`_scheduleCollapsed`,void 0),k([b()],G.prototype,`_solarCollapsed`,void 0),G=Zt=k([v(`rs-covers-section`)],G),_(),x(),A();var Qt=class extends g{constructor(...e){super(...e),this.enabled=!1,this.primaryDelta=1.5,this.outdoorThreshold=5,this.acMinOutdoor=-15,this.editing=!1}static{this.styles=[I,l`
      :host {
        display: block;
      }

      /* Read-only summary (tile) */
      .summary {
        padding: 0 16px 16px;
        font-size: 13px;
        color: var(--secondary-text-color);
        line-height: 1.6;
      }

      .summary.disabled {
        font-style: italic;
        opacity: 0.75;
      }

      /* Editing layout */
      .feature-card {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 14px 16px;
        border: 1px solid var(--divider-color);
        border-radius: 12px;
        background: var(--card-background-color);
        transition:
          border-color 0.2s ease,
          background 0.2s ease;
      }

      .feature-card.enabled {
        border-color: rgba(3, 169, 244, 0.4);
        background: rgba(3, 169, 244, 0.06);
      }

      .feature-text {
        flex: 1;
        min-width: 0;
      }

      .feature-title {
        font-size: 14px;
        font-weight: 500;
        margin: 0 0 4px;
      }

      .feature-description {
        font-size: 12px;
        color: var(--secondary-text-color);
        line-height: 1.5;
        margin: 0;
      }

      ha-switch {
        flex-shrink: 0;
      }

      .thresholds {
        margin-top: 16px;
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 12px;
      }

      @media (max-width: 600px) {
        .thresholds {
          grid-template-columns: 1fr;
        }
      }

      .threshold-cell {
        display: flex;
        flex-direction: column;
        gap: 8px;
        padding: 12px 14px;
        border: 1px solid var(--divider-color);
        border-radius: 10px;
        background: var(--card-background-color);
      }

      .threshold-label {
        font-size: 12px;
        font-weight: 500;
        color: var(--secondary-text-color);
        display: flex;
        align-items: center;
        gap: 4px;
        line-height: 1.3;
      }

      .threshold-label > span {
        flex: 1;
        min-width: 0;
      }

      .threshold-cell ha-textfield {
        width: 100%;
      }
    `]}render(){let e=this.hass.language;return this.editing?m`
      <div class="feature-card ${this.enabled?`enabled`:``}">
        <div class="feature-text">
          <div class="feature-title">${S(`heat_source.toggle`,e)}</div>
          <div class="feature-description">${S(`heat_source.toggle_hint`,e)}</div>
        </div>
        <ha-switch .checked=${this.enabled} @change=${this._onSwitchChange}></ha-switch>
      </div>

      ${this.enabled?m`
            <div class="thresholds">
              ${this._renderThresholdCell({label:S(`heat_source.primary_delta`,e),hint:S(`heat_source.primary_delta_hint`,e),suffix:S(`heat_source.primary_delta_suffix`,e),value:this.primaryDelta,min:.5,max:5,step:.1,key:`heat_source_primary_delta`})}
              ${this._renderThresholdCell({label:S(`heat_source.outdoor_threshold`,e),hint:S(`heat_source.outdoor_threshold_hint`,e),suffix:S(`heat_source.outdoor_threshold_suffix`,e),value:this.outdoorThreshold,min:-20,max:25,step:1,key:`heat_source_outdoor_threshold`})}
              ${this._renderThresholdCell({label:S(`heat_source.ac_min_outdoor`,e),hint:S(`heat_source.ac_min_outdoor_hint`,e),suffix:S(`heat_source.ac_min_outdoor_suffix`,e),value:this.acMinOutdoor,min:-30,max:5,step:1,key:`heat_source_ac_min_outdoor`})}
            </div>
          `:h}
    `:this.enabled?m`<div class="summary">
        ${S(`heat_source.primary_delta`,e)}:
        <strong>${this.primaryDelta}${S(`heat_source.primary_delta_suffix`,e)}</strong>
        · ${S(`heat_source.outdoor_threshold`,e)}:
        <strong
          >${this.outdoorThreshold}${S(`heat_source.outdoor_threshold_suffix`,e)}</strong
        >
        · ${S(`heat_source.ac_min_outdoor`,e)}:
        <strong>${this.acMinOutdoor}${S(`heat_source.ac_min_outdoor_suffix`,e)}</strong>
      </div>`:m`<div class="summary disabled">
          ${S(`heat_source.summary_disabled`,e)}
        </div>`}_renderThresholdCell(e){return m`
      <div class="threshold-cell">
        <div class="threshold-label">
          <span>${e.label}</span>
          <rs-info-icon .text=${e.hint}></rs-info-icon>
        </div>
        <ha-textfield
          .value=${String(e.value)}
          .min=${String(e.min)}
          .max=${String(e.max)}
          .step=${String(e.step)}
          .suffix=${e.suffix}
          type="number"
          @input=${t=>this._onNumberInput(e.key,t)}
        ></ha-textfield>
      </div>
    `}_onSwitchChange(e){this._emit(`heat_source_orchestration`,e.target.checked)}_onNumberInput(e,t){let n=parseFloat(t.target.value);isNaN(n)||this._emit(e,n)}_emit(e,t){this.dispatchEvent(new CustomEvent(`setting-changed`,{detail:{key:e,value:t},bubbles:!0,composed:!0}))}};k([y({attribute:!1})],Qt.prototype,`hass`,void 0),k([y({type:Boolean})],Qt.prototype,`enabled`,void 0),k([y({type:Number})],Qt.prototype,`primaryDelta`,void 0),k([y({type:Number})],Qt.prototype,`outdoorThreshold`,void 0),k([y({type:Number})],Qt.prototype,`acMinOutdoor`,void 0),k([y({type:Boolean})],Qt.prototype,`editing`,void 0),Qt=k([v(`rs-heat-source-section`)],Qt),_(),x(),A();var $t=class extends g{constructor(...e){super(...e),this.icon=``,this.label=``,this.hint=``,this.checked=!1,this.disabled=!1}static{this.styles=l`
    :host {
      display: block;
    }

    ha-card {
      padding: 16px 20px;
      min-width: 0;
    }

    .row {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .icon {
      --mdc-icon-size: 18px;
      color: var(--secondary-text-color);
      opacity: 0.7;
      flex-shrink: 0;
    }

    rs-toggle-row {
      flex: 1;
      min-width: 0;
    }
  `}render(){return m`
      <ha-card>
        <div class="row">
          ${this.icon?m`<ha-icon class="icon" icon=${this.icon}></ha-icon>`:h}
          <rs-toggle-row
            .label=${this.label}
            .hint=${this.hint}
            .checked=${this.checked}
            .disabled=${this.disabled}
            @toggle-changed=${this._onToggle}
          ></rs-toggle-row>
        </div>
      </ha-card>
    `}_onToggle(e){e.stopPropagation(),this.dispatchEvent(new CustomEvent(`toggle-changed`,{detail:e.detail,bubbles:!0,composed:!0}))}};k([y({type:String})],$t.prototype,`icon`,void 0),k([y({type:String})],$t.prototype,`label`,void 0),k([y({type:String})],$t.prototype,`hint`,void 0),k([y({type:Boolean})],$t.prototype,`checked`,void 0),k([y({type:Boolean})],$t.prototype,`disabled`,void 0),$t=k([v(`rs-toggle-card`)],$t),_(),x(),A();var en=`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`,tn=`M11,9H13V7H11M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M11,17H13V11H11V17Z`,nn=class extends g{constructor(...e){super(...e),this.open=!1,this.heading=``,this.icon=``,this.hasInfo=!1,this._infoExpanded=!1,this._onKeyDown=e=>{e.key===`Escape`&&this.open&&(e.stopPropagation(),this._close())}}connectedCallback(){super.connectedCallback(),window.addEventListener(`keydown`,this._onKeyDown)}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener(`keydown`,this._onKeyDown)}static{this.styles=l`
    :host {
      display: contents;
    }

    .backdrop {
      position: fixed;
      inset: 0;
      z-index: 1000;
      background: rgba(0, 0, 0, 0.55);
      backdrop-filter: blur(2px);
      display: flex;
      align-items: flex-start;
      justify-content: center;
      padding: 32px 16px;
      box-sizing: border-box;
      overflow-y: auto;
      animation: fade-in 0.18s ease-out;
    }

    @media (max-width: 600px) {
      .backdrop {
        padding: 0;
        align-items: stretch;
      }
    }

    .dialog {
      background: var(--card-background-color, #1c1c1c);
      color: var(--primary-text-color);
      border-radius: 14px;
      box-shadow: 0 24px 48px rgba(0, 0, 0, 0.5);
      width: 100%;
      max-width: 760px;
      display: flex;
      flex-direction: column;
      max-height: calc(100vh - 64px);
      animation: pop-in 0.18s ease-out;
    }

    @media (min-width: 1400px) {
      .dialog {
        max-width: 880px;
      }
    }

    @media (max-width: 600px) {
      .dialog {
        max-width: 100%;
        max-height: 100vh;
        border-radius: 0;
      }
    }

    .dialog-header {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 18px 24px;
      border-bottom: 1px solid var(--divider-color, rgba(255, 255, 255, 0.08));
    }

    .dialog-icon {
      --mdc-icon-size: 20px;
      opacity: 0.7;
      flex-shrink: 0;
      margin-right: 8px;
    }

    .dialog-title {
      flex: 1;
      font-size: 16px;
      font-weight: 500;
      margin: 0;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .info-btn {
      --mdc-icon-button-size: 36px;
      --mdc-icon-size: 20px;
      color: var(--secondary-text-color);
      transition:
        color 0.15s,
        background 0.15s;
      border-radius: 50%;
    }

    .info-btn.active {
      color: var(--primary-color);
      background: rgba(3, 169, 244, 0.12);
    }

    .close-btn {
      --mdc-icon-button-size: 36px;
      --mdc-icon-size: 20px;
      color: var(--secondary-text-color);
      margin: -6px -10px -6px 0;
    }

    .dialog-body {
      flex: 1;
      overflow-y: auto;
      padding: 20px 24px 24px;
    }

    .dialog-body ::slotted(*) {
      display: block;
    }

    .info-panel {
      margin-bottom: 16px;
      padding: 12px 14px;
      background: rgba(3, 169, 244, 0.06);
      border: 1px solid rgba(3, 169, 244, 0.18);
      border-radius: 10px;
      font-size: 13px;
      line-height: 1.6;
      color: var(--primary-text-color);
      animation: info-fade 0.18s ease-out;
    }

    .info-panel ::slotted(*) {
      display: block;
    }

    @keyframes fade-in {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }

    @keyframes pop-in {
      from {
        opacity: 0;
        transform: scale(0.97);
      }
      to {
        opacity: 1;
        transform: scale(1);
      }
    }

    @keyframes info-fade {
      from {
        opacity: 0;
        transform: translateY(-4px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
  `}render(){return this.open?m`
      <div class="backdrop" @click=${this._onBackdropClick} role="dialog" aria-modal="true">
        <div class="dialog" @click=${e=>e.stopPropagation()}>
          <div class="dialog-header">
            ${this.icon?m`<ha-icon class="dialog-icon" icon=${this.icon}></ha-icon>`:h}
            <h3 class="dialog-title">${this.heading}</h3>
            ${this.hasInfo?m`<ha-icon-button
                  class="info-btn ${this._infoExpanded?`active`:``}"
                  .path=${tn}
                  @click=${this._toggleInfo}
                ></ha-icon-button>`:h}
            <ha-icon-button
              class="close-btn"
              .path=${en}
              @click=${this._close}
            ></ha-icon-button>
          </div>
          <div class="dialog-body">
            ${this.hasInfo&&this._infoExpanded?m`<div class="info-panel"><slot name="info"></slot></div>`:h}
            <slot></slot>
          </div>
        </div>
      </div>
    `:h}_onBackdropClick(e){e.target===e.currentTarget&&this._close()}_toggleInfo(){this._infoExpanded=!this._infoExpanded}_close(){this._infoExpanded=!1,this.dispatchEvent(new CustomEvent(`rs-dialog-closed`,{bubbles:!0,composed:!0}))}};k([y({type:Boolean,reflect:!0})],nn.prototype,`open`,void 0),k([y({type:String})],nn.prototype,`heading`,void 0),k([y({type:String})],nn.prototype,`icon`,void 0),k([y({type:Boolean})],nn.prototype,`hasInfo`,void 0),k([b()],nn.prototype,`_infoExpanded`,void 0),nn=k([v(`rs-edit-dialog`)],nn),_(),x(),A();var rn=`https://github.com/snazzybean/roommind/blob/main/docs/control-and-devices.md`,K=class extends g{constructor(...e){super(...e),this.config=null,this.presenceEnabled=!1,this.presencePersons=[],this.climateControlActive=!0,this.valveProtectionEnabled=!1,this._devices=[],this._airflowDevices=[],this._roomVolumeM3=null,this._controlTarget=`air_temperature`,this._quietHours=null,this._nightModeEnabled=!0,this._nightControls=[],this._nightAllowRapidRecovery=!0,this._rapidRecoveryDeltaC=2,this._maxFanLevelNight=.5,this._sleepTempRampC=0,this._adjacentRooms=[],this._selectedTempSensor=``,this._selectedTempSensors=new Set,this._selectedHumiditySensor=``,this._selectedOccupancySensors=new Set,this._selectedWindowSensors=new Set,this._windowOpenDelay=0,this._windowCloseDelay=0,this._climateMode=`auto`,this._schedules=[],this._scheduleSelectorEntity=``,this._comfortHeat=21,this._comfortCool=24,this._ecoHeat=17,this._ecoCool=27,this._error=``,this._dirty=!1,this._editing=null,this._selectedPresencePersons=[],this._displayName=``,this._selectedCovers=new Set,this._coversAutoEnabled=!1,this._coversDeployThreshold=1.5,this._coversMinPosition=0,this._coversOverrideMinutes=60,this._coverSchedules=[],this._coverScheduleSelectorEntity=``,this._coversNightClose=!1,this._coversNightPosition=0,this._coversSnapDeploy=!1,this._coverOrientations={},this._coversNightCloseElevation=0,this._coversNightCloseOffsetMinutes=0,this._coversOutdoorMinTemp=10,this._coverMinPositions={},this._ignorePresence=!1,this._isOutdoor=!1,this._valveProtectionExclude=new Set,this._climateControlEnabled=!0,this._heatSourceOrchestration=!1,this._heatSourcePrimaryDelta=1.5,this._heatSourceOutdoorThreshold=5,this._heatSourceAcMinOutdoor=-15,this._prevAreaId=null,this._openEdit=e=>()=>{this._editing=e},this._closeEdit=()=>{this._editing=null}}static{this.styles=l`
    :host {
      display: block;
      max-width: 2400px;
      margin: 0 auto;
    }

    .detail-layout {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }

    .detail-grid {
      column-count: 3;
      column-width: 360px;
      column-gap: 16px;
      column-fill: balance;
    }

    .detail-grid > * {
      display: block;
      width: 100%;
      break-inside: avoid;
      page-break-inside: avoid;
      margin-bottom: 16px;
    }

    @media (min-width: 1900px) {
      .detail-grid {
        column-count: 4;
      }
    }

    /* Section cards handled by rs-section-card */

    /* YAML code block for info panels (slotted into edit dialogs) */
    .yaml-block {
      background: var(--code-editor-background-color, rgba(0, 0, 0, 0.35));
      border: 1px solid var(--divider-color, rgba(255, 255, 255, 0.12));
      border-radius: 6px;
      padding: 10px 14px;
      margin: 8px 0;
      font-family: var(--code-font-family, monospace);
      font-size: 12px;
      line-height: 1.6;
      white-space: pre;
      overflow-x: auto;
      color: var(--primary-text-color);
    }
    .yaml-key {
      color: #82aaff;
    }
    .yaml-value {
      color: #e2a76a;
    }

    /* Actions */
    .actions {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-top: 8px;
      margin-bottom: 24px;
    }

    .error {
      color: var(--error-color, #d32f2f);
      font-size: 13px;
      margin-top: 8px;
    }

    .field-hint {
      color: var(--secondary-text-color);
      font-size: 12px;
    }

    .exceptions-link {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      background: none;
      border: none;
      padding: 8px 0 0;
      margin: 0;
      cursor: pointer;
      font-size: 13px;
      color: var(--primary-color);
      font-family: inherit;
    }

    .exceptions-link:hover {
      text-decoration: underline;
    }

    .helper-link {
      display: inline-block;
      margin-top: 12px;
      color: var(--primary-color);
      font-size: 12px;
      text-decoration: none;
    }

    .helper-link:hover {
      text-decoration: underline;
    }
  `}connectedCallback(){super.connectedCallback(),this._initFromConfig()}disconnectedCallback(){super.disconnectedCallback(),this._saveDebounce&&clearTimeout(this._saveDebounce)}updated(e){let t=this.config?.area_id??this.area?.area_id??null;t===this._prevAreaId?e.has(`config`)&&!this._dirty&&(e.get(`config`)??this._initFromConfig()):(this._initFromConfig(),this._prevAreaId=t)}_initFromConfig(){this.config?(this.config.devices?.length?this._devices=[...this.config.devices]:this._devices=[...(this.config.thermostats??[]).map(e=>({entity_id:e,type:`trv`,role:`auto`,heating_system_type:this.config.heating_system_type??``})),...(this.config.acs??[]).map(e=>({entity_id:e,type:`ac`,role:`auto`}))],this._airflowDevices=[...this.config.airflow_devices??[]],this._roomVolumeM3=this.config.room_volume_m3??null,this._controlTarget=this.config.control_target??`air_temperature`,this._quietHours=this.config.quiet_hours??null,this._nightModeEnabled=this.config.night_mode_enabled??!0,this._nightControls=[...this.config.night_controls??[]],this._nightAllowRapidRecovery=this.config.night_allow_rapid_recovery??!0,this._rapidRecoveryDeltaC=this.config.rapid_recovery_delta_c??2,this._maxFanLevelNight=this.config.max_fan_level_night??.5,this._sleepTempRampC=this.config.sleep_temp_ramp_c??0,this._adjacentRooms=[...this.config.adjacent_rooms??[]],this._selectedTempSensor=this.config.temperature_sensor,this._selectedTempSensors=new Set(this.config.temperature_sensors?.length?this.config.temperature_sensors:this.config.temperature_sensor?[this.config.temperature_sensor]:[]),this._selectedTempSensor&&this._selectedTempSensors.add(this._selectedTempSensor),this._selectedHumiditySensor=this.config.humidity_sensor??``,this._selectedOccupancySensors=new Set(this.config.occupancy_sensors??[]),this._selectedWindowSensors=new Set(this.config.window_sensors??[]),this._windowOpenDelay=this.config.window_open_delay??0,this._windowCloseDelay=this.config.window_close_delay??0,this._climateMode=this.config.climate_mode,this._schedules=this.config.schedules??[],this._scheduleSelectorEntity=this.config.schedule_selector_entity??``,this._comfortHeat=this.config.comfort_heat??this.config.comfort_temp??21,this._comfortCool=this.config.comfort_cool??24,this._ecoHeat=this.config.eco_heat??this.config.eco_temp??17,this._ecoCool=this.config.eco_cool??27,this._selectedPresencePersons=this.config.presence_persons??[],this._displayName=this.config.display_name??``,this._selectedCovers=new Set(this.config.covers??[]),this._coversAutoEnabled=this.config.covers_auto_enabled??!1,this._coversDeployThreshold=this.config.covers_deploy_threshold??1.5,this._coversMinPosition=this.config.covers_min_position??0,this._coversOverrideMinutes=this.config.covers_override_minutes??60,this._coverSchedules=this.config.cover_schedules??[],this._coverScheduleSelectorEntity=this.config.cover_schedule_selector_entity??``,this._coversNightClose=this.config.covers_night_close??!1,this._coversNightPosition=this.config.covers_night_position??0,this._coversSnapDeploy=this.config.covers_snap_deploy??!1,this._coverOrientations=this.config.cover_orientations??{},this._coversNightCloseElevation=this.config.covers_night_close_elevation??0,this._coversNightCloseOffsetMinutes=this.config.covers_night_close_offset_minutes??0,this._coversOutdoorMinTemp=this.config.covers_outdoor_min_temp??10,this._coverMinPositions=this.config.cover_min_positions??{},this._ignorePresence=this.config.ignore_presence??!1,this._isOutdoor=this.config.is_outdoor??!1,this._valveProtectionExclude=new Set(this.config.valve_protection_exclude??[]),this._climateControlEnabled=this.config.climate_control_enabled??!0,this._heatSourceOrchestration=this.config.heat_source_orchestration??!1,this._heatSourcePrimaryDelta=this.config.heat_source_primary_delta??1.5,this._heatSourceOutdoorThreshold=this.config.heat_source_outdoor_threshold??5,this._heatSourceAcMinOutdoor=this.config.heat_source_ac_min_outdoor??-15):(this._devices=[],this._airflowDevices=[],this._roomVolumeM3=null,this._controlTarget=`air_temperature`,this._quietHours=null,this._nightModeEnabled=!0,this._nightControls=[],this._nightAllowRapidRecovery=!0,this._rapidRecoveryDeltaC=2,this._maxFanLevelNight=.5,this._sleepTempRampC=0,this._adjacentRooms=[],this._selectedTempSensor=``,this._selectedTempSensors=new Set,this._selectedHumiditySensor=``,this._selectedOccupancySensors=new Set,this._selectedWindowSensors=new Set,this._windowOpenDelay=0,this._windowCloseDelay=0,this._climateMode=`auto`,this._schedules=[],this._scheduleSelectorEntity=``,this._comfortHeat=21,this._comfortCool=24,this._ecoHeat=17,this._ecoCool=27,this._selectedPresencePersons=[],this._displayName=``,this._selectedCovers=new Set,this._coversAutoEnabled=!1,this._coversDeployThreshold=1.5,this._coversMinPosition=0,this._coversOverrideMinutes=60,this._coverSchedules=[],this._coverScheduleSelectorEntity=``,this._coversNightClose=!1,this._coversNightPosition=0,this._coversSnapDeploy=!1,this._coverOrientations={},this._coversNightCloseElevation=0,this._coversNightCloseOffsetMinutes=0,this._coversOutdoorMinTemp=10,this._coverMinPositions={},this._ignorePresence=!1,this._isOutdoor=!1,this._valveProtectionExclude=new Set,this._climateControlEnabled=!0,this._heatSourceOrchestration=!1,this._heatSourcePrimaryDelta=1.5,this._heatSourceOutdoorThreshold=5,this._heatSourceAcMinOutdoor=-15),this._dirty=!1,this._devices.length===0&&this._editing===null&&(this._editing=`devices`)}_getEffectiveOverride(){let e=this.shadowRoot?.querySelector(`rs-override-section`);if(e)return e.getEffectiveOverride();let t=this.config?.live;return t?.override_active&&t.override_type?{active:!0,type:t.override_type,temp:t.override_temp,until:t.override_until}:{active:!1,type:null,temp:null,until:null}}render(){return this.area?m`
      <div class="detail-layout">
        <rs-hero-status
          .hass=${this.hass}
          .area=${this.area}
          .config=${this.config}
          .isOutdoor=${this._isOutdoor}
          .overrideInfo=${this._getEffectiveOverride()}
          .climateControlActive=${this.climateControlActive&&this._climateControlEnabled}
          @display-name-changed=${this._onDisplayNameChanged}
        ></rs-hero-status>

        <div class="detail-grid">
          ${this._isOutdoor?h:m`
                <rs-toggle-card
                  icon="mdi:power"
                  .label=${S(`room.climate_control_toggle`,this.hass.language)}
                  .hint=${S(`room.climate_control_hint`,this.hass.language)}
                  .checked=${this._climateControlEnabled}
                  @toggle-changed=${this._onClimateControlToggle}
                ></rs-toggle-card>

                <rs-section-card
                  icon="mdi:cog"
                  .heading=${S(`room.section.climate_mode`,this.hass.language)}
                >
                  <rs-info-icon slot="header-extras">
                    <b>${S(`mode.auto`,this.hass.language)}</b> —
                    ${S(`mode.auto_desc`,this.hass.language)}<br />
                    <b>${S(`mode.heat_only`,this.hass.language)}</b> —
                    ${S(`mode.heat_only_desc`,this.hass.language)}<br />
                    <b>${S(`mode.cool_only`,this.hass.language)}</b> —
                    ${S(`mode.cool_only_desc`,this.hass.language)}
                  </rs-info-icon>
                  <rs-climate-mode-selector
                    .climateMode=${this._climateMode}
                    .language=${this.hass.language}
                    @mode-changed=${this._onModeChanged}
                  ></rs-climate-mode-selector>
                </rs-section-card>

                <rs-section-card
                  icon="mdi:calendar"
                  .heading=${S(`room.section.schedule`,this.hass.language)}
                  editable
                  @edit-click=${this._openEdit(`schedule`)}
                >
                  <rs-schedule-settings
                    .hass=${this.hass}
                    .schedules=${this._schedules}
                    .scheduleSelectorEntity=${this._scheduleSelectorEntity}
                    .activeScheduleIndex=${this.config?.live?.active_schedule_index??-1}
                    .comfortHeat=${this._comfortHeat}
                    .comfortCool=${this._comfortCool}
                    .ecoHeat=${this._ecoHeat}
                    .ecoCool=${this._ecoCool}
                    .climateMode=${this._climateMode}
                    .editing=${!1}
                    @schedules-changed=${this._onSchedulesChanged}
                    @schedule-selector-changed=${this._onScheduleSelectorChanged}
                    @comfort-heat-changed=${this._onComfortHeatChanged}
                    @comfort-cool-changed=${this._onComfortCoolChanged}
                    @eco-heat-changed=${this._onEcoHeatChanged}
                    @eco-cool-changed=${this._onEcoCoolChanged}
                  ></rs-schedule-settings>
                  ${this.config?m`
                        <rs-override-section
                          .hass=${this.hass}
                          .config=${this.config}
                          .climateMode=${this._climateMode}
                          .comfortHeat=${this._comfortHeat}
                          .comfortCool=${this._comfortCool}
                          .ecoHeat=${this._ecoHeat}
                          .ecoCool=${this._ecoCool}
                          .language=${this.hass.language}
                        ></rs-override-section>
                      `:h}
                </rs-section-card>
              `}
          ${this._isOutdoor?h:m`
                <rs-section-card
                  icon="mdi:power-plug"
                  .heading=${S(`room.section.devices`,this.hass.language)}
                  editable
                  @edit-click=${this._openEdit(`devices`)}
                >
                  <rs-device-section
                    .hass=${this.hass}
                    .area=${this.area}
                    .editing=${!1}
                    .devices=${this._devices}
                    .selectedTempSensor=${this._selectedTempSensor}
                    .valveProtectionExclude=${this._valveProtectionExclude}
                    .valveProtectionEnabled=${this.valveProtectionEnabled}
                    @device-changed=${this._onDeviceChanged}
                    @valve-protection-exclude-toggle=${this._onValveProtectionExcludeToggle}
                  ></rs-device-section>
                </rs-section-card>

                <rs-section-card
                  icon="mdi:thermometer"
                  .heading=${S(`room.section.sensors`,this.hass.language)}
                  editable
                  @edit-click=${this._openEdit(`sensors`)}
                >
                  <rs-sensor-section
                    .hass=${this.hass}
                    .area=${this.area}
                    .editing=${!1}
                    .temperatureSensor=${this._selectedTempSensor}
                    .temperatureSensors=${this._selectedTempSensors}
                    .humiditySensor=${this._selectedHumiditySensor}
                    .occupancySensors=${this._selectedOccupancySensors}
                    .windowSensors=${this._selectedWindowSensors}
                    .windowOpenDelay=${this._windowOpenDelay}
                    .windowCloseDelay=${this._windowCloseDelay}
                    .heatingSystemType=${Ht(this._devices)}
                    .language=${this.hass.language}
                    @sensor-changed=${this._onSensorChanged}
                  ></rs-sensor-section>
                </rs-section-card>

                <rs-section-card
                  icon="mdi:fan"
                  .heading=${S(`room.section.airflow`,this.hass.language)}
                  editable
                  @edit-click=${this._openEdit(`airflow`)}
                >
                  <rs-airflow-section
                    .hass=${this.hass}
                    .area=${this.area}
                    .editing=${!1}
                    .airflowDevices=${this._airflowDevices}
                    .statuses=${this.config?.live?.airflow_devices_status??[]}
                    .commandStatuses=${this.config?.live?.airflow_command_status??[]}
                    .hvacOutputStatus=${this.config?.live?.hvac_output_status??null}
                    .qFanMix=${this.config?.live?.q_fan_mix??0}
                    .qVent=${this.config?.live?.q_vent??0}
                    .airflowAch=${this.config?.live?.airflow_ach??0}
                    .planLevel=${this.config?.live?.airflow_plan_level??0}
                    .mixPlanLevel=${this.config?.live?.airflow_mix_plan_level??0}
                    .ventPlanLevel=${this.config?.live?.airflow_vent_plan_level??0}
                    .active=${this.config?.live?.airflow_active??!1}
                    .language=${this.hass.language}
                    @airflow-devices-changed=${this._onAirflowDevicesChanged}
                  ></rs-airflow-section>
                </rs-section-card>

                <rs-section-card
                  icon="mdi:weather-night"
                  .heading=${S(`room.section.comfort`,this.hass.language)}
                  editable
                  @edit-click=${this._openEdit(`comfort`)}
                >
                  <rs-comfort-section
                    .hass=${this.hass}
                    .area=${this.area}
                    .editing=${!1}
                    .currentTemp=${this.config?.live?.current_temp??null}
                    .perceivedTemp=${this.config?.live?.perceived_temp??null}
                    .currentHumidity=${this.config?.live?.current_humidity??null}
                    .controlTarget=${this._controlTarget}
                    .roomVolumeM3=${this._roomVolumeM3}
                    .quietHours=${this._quietHours}
                    .nightModeEnabled=${this._nightModeEnabled}
                    .maxFanLevelNight=${this._maxFanLevelNight}
                    .sleepTempRampC=${this._sleepTempRampC}
                    .nightAllowRapidRecovery=${this._nightAllowRapidRecovery}
                    .rapidRecoveryDeltaC=${this._rapidRecoveryDeltaC}
                    .nightMode=${this.config?.live?.night_mode??null}
                    .nightControls=${this._nightControls??[]}
                    .nightControlStatus=${this.config?.live?.night_control_status??[]}
                    .adjacentRooms=${this._adjacentRooms??[]}
                    .couplingStatus=${this.config?.live?.coupling_status??[]}
                    .rapidRecoveryActive=${this.config?.live?.rapid_recovery_active??!1}
                    .language=${this.hass.language}
                    @setting-changed=${this._onComfortSettingChanged}
                  ></rs-comfort-section>
                </rs-section-card>

                ${this.presenceEnabled&&this.presencePersons.length>0?m`<rs-section-card
                      icon="mdi:home-account"
                      .heading=${S(`room.section.presence`,this.hass.language)}
                      editable
                      @edit-click=${this._openEdit(`presence`)}
                    >
                      <rs-info-icon
                        slot="header-extras"
                        .text=${S(`presence.ignore_hint`,this.hass.language)}
                      ></rs-info-icon>
                      <rs-presence-section
                        .hass=${this.hass}
                        .presenceEnabled=${this.presenceEnabled}
                        .presencePersons=${this.presencePersons}
                        .selectedPresencePersons=${this._selectedPresencePersons}
                        .ignorePresence=${this._ignorePresence}
                        .editing=${!1}
                        .language=${this.hass.language}
                        @presence-persons-changed=${this._onPresencePersonsChanged}
                        @ignore-presence-changed=${this._onIgnorePresenceChanged}
                      ></rs-presence-section>
                    </rs-section-card>`:h}
              `}
          ${this._isOutdoor?h:m`<rs-section-card
                icon="mdi:blinds-horizontal"
                .heading=${S(`room.section.covers`,this.hass.language)}
                .badge=${S(`badge.beta`,this.hass.language)}
                .badgeHint=${S(`badge.beta_hint`,this.hass.language)}
                editable
                @edit-click=${this._openEdit(`covers`)}
              >
                <rs-covers-section
                  .hass=${this.hass}
                  .area=${this.area}
                  .editing=${!1}
                  .selectedCovers=${this._selectedCovers}
                  .autoEnabled=${this._coversAutoEnabled}
                  .deployThreshold=${this._coversDeployThreshold}
                  .minPosition=${this._coversMinPosition}
                  .overrideMinutes=${this._coversOverrideMinutes}
                  .coverSchedules=${this._coverSchedules}
                  .coverScheduleSelectorEntity=${this._coverScheduleSelectorEntity}
                  .activeCoverScheduleIndex=${this.config?.live?.active_cover_schedule_index??-1}
                  .nightClose=${this._coversNightClose}
                  .nightPosition=${this._coversNightPosition}
                  .snapDeploy=${this._coversSnapDeploy}
                  .forcedReason=${this.config?.live?.cover_forced_reason??``}
                  .autoPaused=${this.config?.live?.cover_auto_paused??!1}
                  .coverOrientations=${this._coverOrientations}
                  .nightCloseElevation=${this._coversNightCloseElevation}
                  .nightCloseOffsetMinutes=${this._coversNightCloseOffsetMinutes}
                  .outdoorMinTemp=${this._coversOutdoorMinTemp}
                  .coverMinPositions=${this._coverMinPositions}
                  @covers-toggle=${this._onCoversToggle}
                  @setting-changed=${this._onCoverSettingChanged}
                ></rs-covers-section>
              </rs-section-card>`}
          ${!this._isOutdoor&&this._selectedTempSensor&&this._devices.some(e=>e.type===`trv`)&&this._devices.some(e=>e.type===`ac`)?m`<rs-section-card
                icon="mdi:swap-horizontal"
                .heading=${S(`room.section.heat_source`,this.hass.language)}
                editable
                @edit-click=${this._openEdit(`heatSource`)}
              >
                <rs-heat-source-section
                  .hass=${this.hass}
                  .editing=${!1}
                  .enabled=${this._heatSourceOrchestration}
                  .primaryDelta=${this._heatSourcePrimaryDelta}
                  .outdoorThreshold=${this._heatSourceOutdoorThreshold}
                  .acMinOutdoor=${this._heatSourceAcMinOutdoor}
                  @setting-changed=${this._onHeatSourceSettingChanged}
                ></rs-heat-source-section>
              </rs-section-card>`:h}

          <rs-toggle-card
            icon="mdi:tree"
            .label=${S(`room.outdoor_toggle`,this.hass.language)}
            .hint=${S(`room.outdoor_hint`,this.hass.language)}
            .checked=${this._isOutdoor}
            @toggle-changed=${this._onOutdoorToggle}
          ></rs-toggle-card>
        </div>
        ${this._error?m`<div class="error">${this._error}</div>`:h}
        ${this._renderEditDialog()}
      </div>
    `:h}_renderEditDialog(){if(this._editing===null)return h;let e=this.hass.language;switch(this._editing){case`schedule`:return m`<rs-edit-dialog
          open
          icon="mdi:calendar"
          .heading=${S(`room.section.schedule`,e)}
          hasInfo
          @rs-dialog-closed=${this._closeEdit}
        >
          <div slot="info">
            <p><strong>${S(`schedule.help_temps_title`,e)}</strong></p>
            <p>${S(`schedule.help_temps`,e)}</p>
            <ol style="margin: 4px 0 0 0; padding-left: 20px; line-height: 1.8">
              <li>${M(S(`schedule.help_temps_1`,e))}</li>
              <li>${M(S(`schedule.help_temps_2`,e))}</li>
              <li>${M(S(`schedule.help_temps_3`,e))}</li>
              <li>${M(S(`schedule.help_temps_4`,e))}</li>
            </ol>
            <p style="margin-top: 12px">
              <strong>${S(`schedule.help_block_title`,e)}</strong>
            </p>
            <p>${M(S(`schedule.help_block`,e))}</p>
            <div class="yaml-block">
              ${M(`<span class="yaml-key">schedule</span>:
  <span class="yaml-key">living_room_heating</span>:
    <span class="yaml-key">name</span>: <span class="yaml-value">Living Room Heating</span>
    <span class="yaml-key">monday</span>:
      - <span class="yaml-key">from</span>: <span class="yaml-value">"06:00:00"</span>
        <span class="yaml-key">to</span>: <span class="yaml-value">"08:00:00"</span>
        <span class="yaml-key">data</span>:
          <span class="yaml-key">temperature</span>: <span class="yaml-value">23</span>
      - <span class="yaml-key">from</span>: <span class="yaml-value">"17:00:00"</span>
        <span class="yaml-key">to</span>: <span class="yaml-value">"22:00:00"</span>
        <span class="yaml-key">data</span>:
          <span class="yaml-key">temperature</span>: <span class="yaml-value">21.5</span>`)}
            </div>
            <p style="margin-top: 8px">${M(S(`schedule.help_block_note`,e))}</p>
            <p style="margin-top: 12px">
              <strong>${S(`schedule.help_split_title`,e)}</strong>
            </p>
            <p>${M(S(`schedule.help_split`,e))}</p>
            <div class="yaml-block">
              ${M(`- <span class="yaml-key">from</span>: <span class="yaml-value">"06:00:00"</span>
  <span class="yaml-key">to</span>: <span class="yaml-value">"08:00:00"</span>
  <span class="yaml-key">data</span>:
    <span class="yaml-key">heat_temperature</span>: <span class="yaml-value">21</span>
    <span class="yaml-key">cool_temperature</span>: <span class="yaml-value">24</span>`)}
            </div>
            <p style="margin-top: 8px">${M(S(`schedule.help_split_note`,e))}</p>
            <p style="margin-top: 12px">
              <strong>${S(`schedule.help_multi_title`,e)}</strong>
            </p>
            <p>${M(S(`schedule.help_multi`,e))}</p>
          </div>
          <rs-schedule-settings
            .hass=${this.hass}
            .schedules=${this._schedules}
            .scheduleSelectorEntity=${this._scheduleSelectorEntity}
            .activeScheduleIndex=${this.config?.live?.active_schedule_index??-1}
            .comfortHeat=${this._comfortHeat}
            .comfortCool=${this._comfortCool}
            .ecoHeat=${this._ecoHeat}
            .ecoCool=${this._ecoCool}
            .climateMode=${this._climateMode}
            .editing=${!0}
            @schedules-changed=${this._onSchedulesChanged}
            @schedule-selector-changed=${this._onScheduleSelectorChanged}
            @comfort-heat-changed=${this._onComfortHeatChanged}
            @comfort-cool-changed=${this._onComfortCoolChanged}
            @eco-heat-changed=${this._onEcoHeatChanged}
            @eco-cool-changed=${this._onEcoCoolChanged}
          ></rs-schedule-settings>
        </rs-edit-dialog>`;case`devices`:return m`<rs-edit-dialog
          open
          icon="mdi:power-plug"
          .heading=${S(`room.section.devices`,e)}
          hasInfo
          @rs-dialog-closed=${this._closeEdit}
        >
          <div slot="info">
            <b>${S(`devices.info.types_title`,e)}</b><br />
            ${S(`devices.info.types_body`,e)}
            <br /><br />
            <b>${S(`devices.info.control_title`,e)}</b><br />
            ${S(`devices.info.control_body`,e)}
            <br /><br />
            <b>${S(`devices.info.modes_title`,e)}</b><br />
            ${S(`devices.info.modes_body`,e)}
            <br /><br />
            <b>${S(`devices.info.heat_source_title`,e)}</b><br />
            ${S(`devices.info.heat_source_body`,e)}
            <br />
            <a class="helper-link" href=${rn} target="_blank" rel="noreferrer">
              ${S(`common.learn_more`,e)}
            </a>
          </div>
          <rs-device-section
            .hass=${this.hass}
            .area=${this.area}
            .editing=${!0}
            .devices=${this._devices}
            .selectedTempSensor=${this._selectedTempSensor}
            .valveProtectionExclude=${this._valveProtectionExclude}
            .valveProtectionEnabled=${this.valveProtectionEnabled}
            @device-changed=${this._onDeviceChanged}
            @valve-protection-exclude-toggle=${this._onValveProtectionExcludeToggle}
          ></rs-device-section>
        </rs-edit-dialog>`;case`sensors`:return m`<rs-edit-dialog
          open
          icon="mdi:thermometer"
          .heading=${S(`room.section.sensors`,e)}
          @rs-dialog-closed=${this._closeEdit}
        >
          <rs-sensor-section
            .hass=${this.hass}
            .area=${this.area}
            .editing=${!0}
            .temperatureSensor=${this._selectedTempSensor}
            .temperatureSensors=${this._selectedTempSensors}
            .humiditySensor=${this._selectedHumiditySensor}
            .occupancySensors=${this._selectedOccupancySensors}
            .windowSensors=${this._selectedWindowSensors}
            .windowOpenDelay=${this._windowOpenDelay}
            .windowCloseDelay=${this._windowCloseDelay}
            .heatingSystemType=${Ht(this._devices)}
            .language=${this.hass.language}
            @sensor-changed=${this._onSensorChanged}
          ></rs-sensor-section>
        </rs-edit-dialog>`;case`airflow`:return m`<rs-edit-dialog
          open
          icon="mdi:fan"
          .heading=${S(`room.section.airflow`,e)}
          hasInfo
          @rs-dialog-closed=${this._closeEdit}
        >
          <div slot="info">
            <b>${S(`airflow.info_title`,e)}</b><br />
            ${S(`airflow.info_body`,e)}
            <br /><br />
            <b>${S(`airflow.info_control_title`,e)}</b><br />
            ${S(`airflow.info_control_body`,e)}
          </div>
          <rs-airflow-section
            .hass=${this.hass}
            .area=${this.area}
            .editing=${!0}
            .airflowDevices=${this._airflowDevices}
            .statuses=${this.config?.live?.airflow_devices_status??[]}
            .commandStatuses=${this.config?.live?.airflow_command_status??[]}
            .hvacOutputStatus=${this.config?.live?.hvac_output_status??null}
            .qFanMix=${this.config?.live?.q_fan_mix??0}
            .qVent=${this.config?.live?.q_vent??0}
            .airflowAch=${this.config?.live?.airflow_ach??0}
            .planLevel=${this.config?.live?.airflow_plan_level??0}
            .mixPlanLevel=${this.config?.live?.airflow_mix_plan_level??0}
            .ventPlanLevel=${this.config?.live?.airflow_vent_plan_level??0}
            .active=${this.config?.live?.airflow_active??!1}
            .language=${this.hass.language}
            @airflow-devices-changed=${this._onAirflowDevicesChanged}
          ></rs-airflow-section>
        </rs-edit-dialog>`;case`comfort`:return m`<rs-edit-dialog
          open
          icon="mdi:weather-night"
          .heading=${S(`room.section.comfort`,e)}
          hasInfo
          @rs-dialog-closed=${this._closeEdit}
        >
          <div slot="info">
            <b>${S(`comfort.info_title`,e)}</b><br />
            ${S(`comfort.info_body`,e)}
            <br /><br />
            <b>${S(`comfort.info_night_title`,e)}</b><br />
            ${S(`comfort.info_night_body`,e)}
            <br /><br />
            <b>${S(`comfort.info_coupling_title`,e)}</b><br />
            ${S(`comfort.info_coupling_body`,e)}
          </div>
          <rs-comfort-section
            .hass=${this.hass}
            .area=${this.area}
            .editing=${!0}
            .currentTemp=${this.config?.live?.current_temp??null}
            .perceivedTemp=${this.config?.live?.perceived_temp??null}
            .currentHumidity=${this.config?.live?.current_humidity??null}
            .controlTarget=${this._controlTarget}
            .roomVolumeM3=${this._roomVolumeM3}
            .quietHours=${this._quietHours}
            .nightModeEnabled=${this._nightModeEnabled}
            .maxFanLevelNight=${this._maxFanLevelNight}
            .sleepTempRampC=${this._sleepTempRampC}
            .nightAllowRapidRecovery=${this._nightAllowRapidRecovery}
            .rapidRecoveryDeltaC=${this._rapidRecoveryDeltaC}
            .nightMode=${this.config?.live?.night_mode??null}
            .nightControls=${this._nightControls??[]}
            .nightControlStatus=${this.config?.live?.night_control_status??[]}
            .adjacentRooms=${this._adjacentRooms??[]}
            .couplingStatus=${this.config?.live?.coupling_status??[]}
            .rapidRecoveryActive=${this.config?.live?.rapid_recovery_active??!1}
            .language=${this.hass.language}
            @setting-changed=${this._onComfortSettingChanged}
          ></rs-comfort-section>
        </rs-edit-dialog>`;case`presence`:return m`<rs-edit-dialog
          open
          icon="mdi:home-account"
          .heading=${S(`room.section.presence`,e)}
          hasInfo
          @rs-dialog-closed=${this._closeEdit}
        >
          <div slot="info">
            <b>${S(`presence.room_help_header`,e)}</b><br />
            ${S(`presence.room_help_body`,e)}
            <br /><br />
            <b>${S(`presence.help_ignore_title`,e)}</b><br />
            ${S(`presence.help_ignore_body`,e)}
          </div>
          <rs-presence-section
            .hass=${this.hass}
            .presenceEnabled=${this.presenceEnabled}
            .presencePersons=${this.presencePersons}
            .selectedPresencePersons=${this._selectedPresencePersons}
            .ignorePresence=${this._ignorePresence}
            .editing=${!0}
            .language=${this.hass.language}
            @presence-persons-changed=${this._onPresencePersonsChanged}
            @ignore-presence-changed=${this._onIgnorePresenceChanged}
          ></rs-presence-section>
        </rs-edit-dialog>`;case`covers`:return m`<rs-edit-dialog
          open
          icon="mdi:blinds-horizontal"
          .heading=${S(`room.section.covers`,e)}
          hasInfo
          @rs-dialog-closed=${this._closeEdit}
        >
          <div slot="info">
            <b>${S(`covers.info.selection_title`,e)}</b><br />
            ${S(`covers.info.selection_body`,e)}
            <br /><br />
            <b>${S(`covers.info.schedule_title`,e)}</b><br />
            ${S(`covers.info.schedule_body`,e)}
            <div class="yaml-block">
              ${M(`<span class="yaml-key">schedule</span>:
  <span class="yaml-key">cover_evening</span>:
    <span class="yaml-key">name</span>: <span class="yaml-value">Cover Evening</span>
    <span class="yaml-key">monday</span>:
      - <span class="yaml-key">from</span>: <span class="yaml-value">"20:00:00"</span>
        <span class="yaml-key">to</span>: <span class="yaml-value">"06:00:00"</span>
        <span class="yaml-key">data</span>:
          <span class="yaml-key">position</span>: <span class="yaml-value">10</span>`)}
            </div>
            <b>${S(`covers.info.solar_title`,e)}</b><br />
            ${S(`covers.info.solar_body`,e)}
            <br /><br />
            <b>${S(`covers.info.night_title`,e)}</b><br />
            ${S(`covers.info.night_body`,e)}
            <br /><br />
            <b>${S(`covers.info.override_title`,e)}</b><br />
            ${S(`covers.info.override_body`,e)}
            <br /><br />
            <b>${S(`covers.info.priority_title`,e)}</b><br />
            ${S(`covers.info.priority_body`,e)}
            <br /><br />
            <b>${S(`covers.info.entities_title`,e)}</b><br />
            ${S(`covers.info.entities_body`,e)}
          </div>
          <rs-covers-section
            .hass=${this.hass}
            .area=${this.area}
            .editing=${!0}
            .selectedCovers=${this._selectedCovers}
            .autoEnabled=${this._coversAutoEnabled}
            .deployThreshold=${this._coversDeployThreshold}
            .minPosition=${this._coversMinPosition}
            .overrideMinutes=${this._coversOverrideMinutes}
            .coverSchedules=${this._coverSchedules}
            .coverScheduleSelectorEntity=${this._coverScheduleSelectorEntity}
            .activeCoverScheduleIndex=${this.config?.live?.active_cover_schedule_index??-1}
            .nightClose=${this._coversNightClose}
            .nightPosition=${this._coversNightPosition}
            .snapDeploy=${this._coversSnapDeploy}
            .forcedReason=${this.config?.live?.cover_forced_reason??``}
            .autoPaused=${this.config?.live?.cover_auto_paused??!1}
            .coverOrientations=${this._coverOrientations}
            .nightCloseElevation=${this._coversNightCloseElevation}
            .nightCloseOffsetMinutes=${this._coversNightCloseOffsetMinutes}
            .outdoorMinTemp=${this._coversOutdoorMinTemp}
            .coverMinPositions=${this._coverMinPositions}
            @covers-toggle=${this._onCoversToggle}
            @setting-changed=${this._onCoverSettingChanged}
          ></rs-covers-section>
        </rs-edit-dialog>`;case`heatSource`:return m`<rs-edit-dialog
          open
          icon="mdi:swap-horizontal"
          .heading=${S(`room.section.heat_source`,e)}
          @rs-dialog-closed=${this._closeEdit}
        >
          <rs-heat-source-section
            .hass=${this.hass}
            .editing=${!0}
            .enabled=${this._heatSourceOrchestration}
            .primaryDelta=${this._heatSourcePrimaryDelta}
            .outdoorThreshold=${this._heatSourceOutdoorThreshold}
            .acMinOutdoor=${this._heatSourceAcMinOutdoor}
            @setting-changed=${this._onHeatSourceSettingChanged}
          ></rs-heat-source-section>
        </rs-edit-dialog>`}}_onModeChanged(e){this._climateMode=e.detail.mode,this._autoSave()}_onSchedulesChanged(e){this._schedules=e.detail.value,this._autoSave()}_onScheduleSelectorChanged(e){this._scheduleSelectorEntity=e.detail.value,this._autoSave()}_onComfortHeatChanged(e){this._comfortHeat=e.detail.value,this._comfortCool<this._comfortHeat&&(this._comfortCool=this._comfortHeat),this._autoSave()}_onComfortCoolChanged(e){this._comfortCool=e.detail.value,this._comfortHeat>this._comfortCool&&(this._comfortHeat=this._comfortCool),this._autoSave()}_onEcoHeatChanged(e){this._ecoHeat=e.detail.value,this._ecoCool<this._ecoHeat&&(this._ecoCool=this._ecoHeat),this._autoSave()}_onEcoCoolChanged(e){this._ecoCool=e.detail.value,this._ecoHeat>this._ecoCool&&(this._ecoHeat=this._ecoCool),this._autoSave()}_onDeviceChanged(e){let t=new Set(this._devices.map(e=>e.entity_id));this._devices=e.detail.devices;let n=new Set(this._devices.map(e=>e.entity_id));for(let e of t)if(!n.has(e)&&this._valveProtectionExclude.has(e)){let t=new Set(this._valveProtectionExclude);t.delete(e),this._valveProtectionExclude=t}for(let e of this._devices)if(e.type!==`trv`&&this._valveProtectionExclude.has(e.entity_id)){let t=new Set(this._valveProtectionExclude);t.delete(e.entity_id),this._valveProtectionExclude=t}this._autoSave()}_onAirflowDevicesChanged(e){this._airflowDevices=e.detail.devices,this._autoSave()}_onComfortSettingChanged(e){let{key:t,value:n}=e.detail;e.stopPropagation(),t===`room_volume_m3`?this._roomVolumeM3=n:t===`control_target`?this._controlTarget=n:t===`quiet_hours`?this._quietHours=n:t===`night_mode_enabled`?this._nightModeEnabled=n:t===`night_controls`?this._nightControls=n:t===`night_allow_rapid_recovery`?this._nightAllowRapidRecovery=n:t===`rapid_recovery_delta_c`?this._rapidRecoveryDeltaC=n:t===`max_fan_level_night`?this._maxFanLevelNight=n:t===`sleep_temp_ramp_c`?this._sleepTempRampC=n:t===`adjacent_rooms`&&(this._adjacentRooms=n),this._autoSave()}_onSensorChanged(e){let{key:t,value:n}=e.detail;if(t===`temperature_sensor`)this._selectedTempSensor=n,this._selectedTempSensor?this._selectedTempSensors=new Set([this._selectedTempSensor,...this._selectedTempSensors]):this._selectedTempSensors=new Set;else if(t===`temperature_sensors`){let e=new Set(n);this._selectedTempSensor&&!e.has(this._selectedTempSensor)&&(this._selectedTempSensor=[...e][0]??``),this._selectedTempSensor&&e.add(this._selectedTempSensor),this._selectedTempSensors=e}else t===`humidity_sensor`?this._selectedHumiditySensor=n:t===`occupancy_sensors`?this._selectedOccupancySensors=new Set(n):t===`window_sensors`?this._selectedWindowSensors=new Set(n):t===`window_open_delay`?this._windowOpenDelay=n:t===`window_close_delay`&&(this._windowCloseDelay=n);this._autoSave()}_onValveProtectionExcludeToggle(e){let{entityId:t,excluded:n}=e.detail,r=new Set(this._valveProtectionExclude);n?r.add(t):r.delete(t),this._valveProtectionExclude=r,this._autoSave()}_onPresencePersonsChanged(e){this._selectedPresencePersons=e.detail,this._autoSave()}_onIgnorePresenceChanged(e){this._ignorePresence=e.detail,this._autoSave()}_onCoversToggle(e){let{entityId:t,checked:n}=e.detail,r=new Set(this._selectedCovers);if(n)r.add(t);else{if(r.delete(t),t in this._coverOrientations){let e={...this._coverOrientations};delete e[t],this._coverOrientations=e}if(t in this._coverMinPositions){let e={...this._coverMinPositions};delete e[t],this._coverMinPositions=e}}this._selectedCovers=r,this._autoSave()}_onCoverSettingChanged(e){let{key:t,value:n}=e.detail;e.stopPropagation(),t===`covers_auto_enabled`?this._coversAutoEnabled=n:t===`covers_deploy_threshold`?this._coversDeployThreshold=n:t===`covers_min_position`?this._coversMinPosition=n:t===`covers_override_minutes`?this._coversOverrideMinutes=n:t===`cover_schedules`?this._coverSchedules=n:t===`cover_schedule_selector_entity`?this._coverScheduleSelectorEntity=n:t===`covers_night_close`?this._coversNightClose=n:t===`covers_night_position`?this._coversNightPosition=n:t===`covers_snap_deploy`?this._coversSnapDeploy=n:t===`cover_orientations`?this._coverOrientations=n:t===`covers_night_close_elevation`?this._coversNightCloseElevation=n:t===`covers_night_close_offset_minutes`?this._coversNightCloseOffsetMinutes=n:t===`covers_outdoor_min_temp`?this._coversOutdoorMinTemp=n:t===`cover_min_positions`&&(this._coverMinPositions=n),this._autoSave()}_onHeatSourceSettingChanged(e){let{key:t,value:n}=e.detail;e.stopPropagation(),t===`heat_source_orchestration`?this._heatSourceOrchestration=n:t===`heat_source_primary_delta`?this._heatSourcePrimaryDelta=n:t===`heat_source_outdoor_threshold`?this._heatSourceOutdoorThreshold=n:t===`heat_source_ac_min_outdoor`&&(this._heatSourceAcMinOutdoor=n),this._autoSave()}_onClimateControlToggle(e){this._climateControlEnabled=e.detail,this._autoSave()}_onOutdoorToggle(e){this._isOutdoor=e.detail,this._autoSave()}_onDisplayNameChanged(e){this._displayName=e.detail.value,this._autoSave()}_autoSave(){this._dirty=!0,this._saveDebounce&&clearTimeout(this._saveDebounce),this._saveDebounce=setTimeout(()=>this._doSave(),500)}async _doSave(){F(this,`saving`),this._error=``;try{await this.hass.callWS({type:`roommind/rooms/save`,area_id:this.area.area_id,devices:this._devices,airflow_devices:this._airflowDevices,room_volume_m3:this._roomVolumeM3,control_target:this._controlTarget,quiet_hours:this._quietHours,night_mode_enabled:this._nightModeEnabled,night_controls:this._nightControls??[],night_allow_rapid_recovery:this._nightAllowRapidRecovery,rapid_recovery_delta_c:this._rapidRecoveryDeltaC,max_fan_level_night:this._maxFanLevelNight,sleep_temp_ramp_c:this._sleepTempRampC,adjacent_rooms:this._adjacentRooms??[],temperature_sensor:this._selectedTempSensor,temperature_sensors:this._temperatureSensorIdsForSave(),humidity_sensor:this._selectedHumiditySensor,occupancy_sensors:[...this._selectedOccupancySensors],window_sensors:[...this._selectedWindowSensors],window_open_delay:this._windowOpenDelay,window_close_delay:this._windowCloseDelay,climate_mode:this._climateMode,schedules:this._schedules,schedule_selector_entity:this._scheduleSelectorEntity,comfort_heat:this._comfortHeat,comfort_cool:this._comfortCool,eco_heat:this._ecoHeat,eco_cool:this._ecoCool,presence_persons:this._selectedPresencePersons.filter(e=>e),display_name:this._displayName,covers:[...this._selectedCovers],climate_control_enabled:this._climateControlEnabled,covers_auto_enabled:this._coversAutoEnabled,covers_deploy_threshold:this._coversDeployThreshold,covers_min_position:this._coversMinPosition,covers_override_minutes:this._coversOverrideMinutes,cover_schedules:this._coverSchedules,cover_schedule_selector_entity:this._coverScheduleSelectorEntity,covers_night_close:this._coversNightClose,covers_night_position:this._coversNightPosition,covers_snap_deploy:this._coversSnapDeploy,cover_orientations:this._coverOrientations,covers_night_close_elevation:this._coversNightCloseElevation,covers_night_close_offset_minutes:this._coversNightCloseOffsetMinutes,covers_outdoor_min_temp:this._coversOutdoorMinTemp,cover_min_positions:this._coverMinPositions,ignore_presence:this._ignorePresence,is_outdoor:this._isOutdoor,valve_protection_exclude:[...this._valveProtectionExclude],heat_source_orchestration:this._heatSourceOrchestration,heat_source_primary_delta:this._heatSourcePrimaryDelta,heat_source_outdoor_threshold:this._heatSourceOutdoorThreshold,heat_source_ac_min_outdoor:this._heatSourceAcMinOutdoor}),this._dirty=!1,F(this,`saved`),this.dispatchEvent(new CustomEvent(`room-updated`,{bubbles:!0,composed:!0}))}catch(e){let t=e instanceof Error?e.message:S(`room.error_save_fallback`,this.hass.language);this._error=t,F(this,`error`)}}_temperatureSensorIdsForSave(){let e=[];this._selectedTempSensor&&e.push(this._selectedTempSensor);for(let t of this._selectedTempSensors)t&&!e.includes(t)&&e.push(t);return e}};k([y({attribute:!1})],K.prototype,`area`,void 0),k([y({attribute:!1})],K.prototype,`config`,void 0),k([y({attribute:!1})],K.prototype,`hass`,void 0),k([y({type:Boolean})],K.prototype,`presenceEnabled`,void 0),k([y({attribute:!1})],K.prototype,`presencePersons`,void 0),k([y({type:Boolean})],K.prototype,`climateControlActive`,void 0),k([y({type:Boolean})],K.prototype,`valveProtectionEnabled`,void 0),k([b()],K.prototype,`_devices`,void 0),k([b()],K.prototype,`_airflowDevices`,void 0),k([b()],K.prototype,`_roomVolumeM3`,void 0),k([b()],K.prototype,`_controlTarget`,void 0),k([b()],K.prototype,`_quietHours`,void 0),k([b()],K.prototype,`_nightModeEnabled`,void 0),k([b()],K.prototype,`_nightControls`,void 0),k([b()],K.prototype,`_nightAllowRapidRecovery`,void 0),k([b()],K.prototype,`_rapidRecoveryDeltaC`,void 0),k([b()],K.prototype,`_maxFanLevelNight`,void 0),k([b()],K.prototype,`_sleepTempRampC`,void 0),k([b()],K.prototype,`_adjacentRooms`,void 0),k([b()],K.prototype,`_selectedTempSensor`,void 0),k([b()],K.prototype,`_selectedTempSensors`,void 0),k([b()],K.prototype,`_selectedHumiditySensor`,void 0),k([b()],K.prototype,`_selectedOccupancySensors`,void 0),k([b()],K.prototype,`_selectedWindowSensors`,void 0),k([b()],K.prototype,`_windowOpenDelay`,void 0),k([b()],K.prototype,`_windowCloseDelay`,void 0),k([b()],K.prototype,`_climateMode`,void 0),k([b()],K.prototype,`_schedules`,void 0),k([b()],K.prototype,`_scheduleSelectorEntity`,void 0),k([b()],K.prototype,`_comfortHeat`,void 0),k([b()],K.prototype,`_comfortCool`,void 0),k([b()],K.prototype,`_ecoHeat`,void 0),k([b()],K.prototype,`_ecoCool`,void 0),k([b()],K.prototype,`_error`,void 0),k([b()],K.prototype,`_dirty`,void 0),k([b()],K.prototype,`_editing`,void 0),k([b()],K.prototype,`_selectedPresencePersons`,void 0),k([b()],K.prototype,`_displayName`,void 0),k([b()],K.prototype,`_selectedCovers`,void 0),k([b()],K.prototype,`_coversAutoEnabled`,void 0),k([b()],K.prototype,`_coversDeployThreshold`,void 0),k([b()],K.prototype,`_coversMinPosition`,void 0),k([b()],K.prototype,`_coversOverrideMinutes`,void 0),k([b()],K.prototype,`_coverSchedules`,void 0),k([b()],K.prototype,`_coverScheduleSelectorEntity`,void 0),k([b()],K.prototype,`_coversNightClose`,void 0),k([b()],K.prototype,`_coversNightPosition`,void 0),k([b()],K.prototype,`_coversSnapDeploy`,void 0),k([b()],K.prototype,`_coverOrientations`,void 0),k([b()],K.prototype,`_coversNightCloseElevation`,void 0),k([b()],K.prototype,`_coversNightCloseOffsetMinutes`,void 0),k([b()],K.prototype,`_coversOutdoorMinTemp`,void 0),k([b()],K.prototype,`_coverMinPositions`,void 0),k([b()],K.prototype,`_ignorePresence`,void 0),k([b()],K.prototype,`_isOutdoor`,void 0),k([b()],K.prototype,`_valveProtectionExclude`,void 0),k([b()],K.prototype,`_climateControlEnabled`,void 0),k([b()],K.prototype,`_heatSourceOrchestration`,void 0),k([b()],K.prototype,`_heatSourcePrimaryDelta`,void 0),k([b()],K.prototype,`_heatSourceOutdoorThreshold`,void 0),k([b()],K.prototype,`_heatSourceAcMinOutdoor`,void 0),K=k([v(`rs-room-detail`)],K);var an=n({HaTextfieldPolyfill:()=>q}),q,on=t((()=>{_(),x(),A(),q=class extends g{constructor(...e){super(...e),this.value=``,this.type=`text`,this.label=``,this.placeholder=``,this.suffix=``,this.prefix=``,this.helper=``,this.disabled=!1,this.required=!1,this.readOnly=!1,this.min=``,this.max=``,this.step=null,this.name=``}static{this.shadowRootOptions={mode:`open`,delegatesFocus:!0}}static{this.styles=l`
    :host {
      display: inline-flex;
      flex-direction: column;
      outline: none;
      width: 100%;
    }
    ha-input {
      --ha-input-padding-bottom: 0;
      width: 100%;
    }
    .prefix,
    .suffix {
      color: var(--secondary-text-color);
    }
  `}render(){return m`
      <ha-input
        .type=${this.type}
        .value=${this.value||``}
        .label=${this.label}
        .placeholder=${this.placeholder}
        .disabled=${this.disabled}
        .required=${this.required}
        .readonly=${this.readOnly}
        .min=${this.min===``?void 0:this.min}
        .max=${this.max===``?void 0:this.max}
        .step=${this.step??void 0}
        .name=${this.name||void 0}
        .hint=${this.helper}
        .withoutSpinButtons=${this.type===`number`}
        @input=${this._sync}
        @change=${this._sync}
      >
        ${this.prefix?m`<span class="prefix" slot="start">${this.prefix}</span>`:h}
        ${this.suffix?m`<span class="suffix" slot="end">${this.suffix}</span>`:h}
      </ha-input>
    `}_sync(){this.value=this._haInput?.value??``}},k([y({type:String})],q.prototype,`value`,void 0),k([y({type:String})],q.prototype,`type`,void 0),k([y({type:String})],q.prototype,`label`,void 0),k([y({type:String})],q.prototype,`placeholder`,void 0),k([y({type:String})],q.prototype,`suffix`,void 0),k([y({type:String})],q.prototype,`prefix`,void 0),k([y({type:String})],q.prototype,`helper`,void 0),k([y({type:Boolean})],q.prototype,`disabled`,void 0),k([y({type:Boolean})],q.prototype,`required`,void 0),k([y({type:Boolean,reflect:!0,attribute:`readonly`})],q.prototype,`readOnly`,void 0),k([y()],q.prototype,`min`,void 0),k([y()],q.prototype,`max`,void 0),k([y()],q.prototype,`step`,void 0),k([y({type:String})],q.prototype,`name`,void 0),k([ft(`ha-input`)],q.prototype,`_haInput`,void 0)})),sn=async()=>{if(!customElements.get(`ha-entity-picker`)){if(!customElements.get(`ha-selector`)){await customElements.whenDefined(`partial-panel-resolver`);let e=document.createElement(`partial-panel-resolver`);e.hass={panels:[{url_path:`tmp`,component_name:`config`}]},e._updateRoutes(),await e.routerOptions.routes.tmp.load(),await customElements.whenDefined(`ha-panel-config`),await document.createElement(`ha-panel-config`).routerOptions.routes.automation.load()}if(!customElements.get(`ha-entity-picker`))try{await(await(await window.loadCardHelpers()).createCardElement({type:`entities`,entities:[]})).constructor.getConfigElement()}catch{}if(!customElements.get(`ha-entity-picker`))try{await Promise.race([customElements.whenDefined(`ha-selector`),new Promise((e,t)=>setTimeout(()=>t(Error(`timeout`)),1e4))]);let e=document.querySelector(`home-assistant`)?.hass,t=document.createElement(`div`);t.style.cssText=`position:fixed;left:-9999px;opacity:0;pointer-events:none`,document.body.appendChild(t);try{let n=document.createElement(`ha-selector`);n.hass=e,n.selector={entity:{}},t.appendChild(n),await Promise.race([customElements.whenDefined(`ha-entity-picker`),new Promise(e=>setTimeout(e,5e3))])}finally{t.remove()}}catch{}if(await customElements.whenDefined(`ha-card`),!customElements.get(`ha-textfield`))try{await Promise.race([customElements.whenDefined(`ha-input`),new Promise((e,t)=>setTimeout(()=>t(Error(`timeout`)),5e3))]);let{HaTextfieldPolyfill:e}=await Promise.resolve().then(()=>(on(),an));customElements.get(`ha-textfield`)||customElements.define(`ha-textfield`,e)}catch{}if(!customElements.get(`ha-date-range-picker`))try{await(await window.loadCardHelpers()).createCardElement({type:`energy-date-selection`,entities:[]}),await Promise.race([customElements.whenDefined(`ha-date-range-picker`),new Promise((e,t)=>setTimeout(t,5e3))])}catch{}if(!customElements.get(`ha-chart-base`))try{await(await window.loadCardHelpers()).createCardElement({type:`statistics-graph`,entities:[]}),await Promise.race([customElements.whenDefined(`ha-chart-base`),new Promise((e,t)=>setTimeout(t,5e3))])}catch{}}},cn=3250368e4;_(),x(),A();var ln=class extends g{constructor(...e){super(...e),this.icon=``,this.heading=``,this.intro=``,this.badge=``,this.badgeHint=``}render(){return m`
      <ha-expansion-panel outlined>
        <div slot="header" class="panel-header">
          <ha-icon .icon=${this.icon}></ha-icon>
          <span>${this.heading}</span>
          ${this.badge?m`<rs-badge .label=${this.badge} .hint=${this.badgeHint}></rs-badge>`:h}
        </div>
        <div class="panel-content">
          ${this.intro?m`<p class="section-intro">${this.intro}</p>`:h}
          <slot></slot>
        </div>
      </ha-expansion-panel>
    `}static{this.styles=l`
    :host {
      display: block;
    }

    .panel-header {
      display: flex;
      align-items: center;
      gap: 10px;
      --mdc-icon-size: 20px;
      color: var(--secondary-text-color);
    }

    .panel-header span {
      color: var(--primary-text-color);
      font-weight: 500;
    }

    .panel-content {
      padding: 16px 16px 16px;
    }

    .section-intro {
      color: var(--secondary-text-color);
      font-size: 13px;
      line-height: 1.5;
      margin: 0 0 16px;
      padding: 2px 0 2px 12px;
      border-left: 3px solid var(--divider-color);
    }
  `}};k([y({type:String})],ln.prototype,`icon`,void 0),k([y({type:String})],ln.prototype,`heading`,void 0),k([y({type:String})],ln.prototype,`intro`,void 0),k([y({type:String})],ln.prototype,`badge`,void 0),k([y({type:String})],ln.prototype,`badgeHint`,void 0),ln=k([v(`rs-settings-panel`)],ln),_();var J=class extends g{_fire(e,t){this.dispatchEvent(new CustomEvent(`setting-changed`,{detail:{key:e,value:t},bubbles:!0,composed:!0}))}static{this.settingsBaseStyles=l`
    :host {
      display: block;
    }

    /* Round HA's MDC-based inputs to match the rest of the design */
    ha-textfield,
    ha-select,
    ha-entity-picker,
    ha-combo-box {
      --mdc-shape-small: 8px;
      --mdc-shape-medium: 8px;
      --md-filled-text-field-container-shape: 8px;
      --md-outlined-text-field-container-shape: 8px;
      display: block;
      border-radius: 8px;
      overflow: hidden;
      isolation: isolate;
      clip-path: inset(0 round 8px);
    }

    ha-entity-picker {
      clip-path: inset(0 round 8px 8px 4px 4px);
    }

    .settings-section {
      padding: 16px 0;
      border-top: 1px solid var(--divider-color);
    }
    .settings-section:first-child,
    .settings-section.first {
      border-top: none;
      padding-top: 0;
    }

    .toggle-row {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 16px;
    }
    .toggle-text {
      display: flex;
      flex-direction: column;
      gap: 4px;
      flex: 1;
    }
    .toggle-label {
      font-size: 14px;
      font-weight: 500;
      color: var(--primary-text-color);
    }
    .toggle-hint {
      font-size: 13px;
      color: var(--secondary-text-color);
      line-height: 1.4;
    }

    .threshold-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }
    .threshold-field {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    .threshold-field ha-textfield {
      width: 100%;
    }
    .field-hint {
      color: var(--secondary-text-color);
      font-size: 12px;
    }

    @media (max-width: 600px) {
      .threshold-grid {
        grid-template-columns: 1fr;
      }
    }
  `}};_(),x(),A();var un=class extends J{constructor(...e){super(...e),this.groupByFloor=!1,this.climateControlActive=!0}render(){let e=this.hass.language;return m`
      ${this.hass.floors&&Object.keys(this.hass.floors).length>0?m`<div class="settings-section first">
            <div class="toggle-row">
              <div class="toggle-text">
                <span class="toggle-label">${S(`settings.group_by_floor`,e)}</span>
              </div>
              <ha-switch
                .checked=${this.groupByFloor}
                @change=${e=>this._fire(`groupByFloor`,e.target.checked)}
              ></ha-switch>
            </div>
          </div>`:h}

      <div
        class="settings-section ${this.hass.floors&&Object.keys(this.hass.floors).length>0?``:`first`}"
      >
        <div class="toggle-row">
          <div class="toggle-text">
            <span class="toggle-label">${S(`settings.climate_control_active`,e)}</span>
            <span class="toggle-hint">${S(`settings.climate_control_hint`,e)}</span>
          </div>
          <ha-switch
            .checked=${this.climateControlActive}
            @change=${e=>this._fire(`climateControlActive`,e.target.checked)}
          ></ha-switch>
        </div>
      </div>
    `}static{this.styles=[J.settingsBaseStyles]}};k([y({attribute:!1})],un.prototype,`hass`,void 0),k([y({type:Boolean})],un.prototype,`groupByFloor`,void 0),k([y({type:Boolean})],un.prototype,`climateControlActive`,void 0),un=k([v(`rs-settings-general`)],un),_(),x(),A();var dn=class extends J{constructor(...e){super(...e),this.outdoorTempSensor=``,this.outdoorHumiditySensor=``,this.weatherEntity=``,this.outdoorUnavailableNotify=!0,this._filterTemperature=e=>e.attributes?.device_class===`temperature`,this._filterHumidity=e=>e.attributes?.device_class===`humidity`}_getSensorValue(e){let t=this.hass.states[e];if(!t||t.state===`unavailable`||t.state===`unknown`)return null;let n=parseFloat(t.state);return isNaN(n)?null:Math.round(n*10)/10}render(){let e=this.hass.language,t=this.outdoorTempSensor?this._getSensorValue(this.outdoorTempSensor):null,n=this.outdoorHumiditySensor?this._getSensorValue(this.outdoorHumiditySensor):null;return m`
      <div class="settings-section first">
        <div class="sensor-grid">
          <div class="sensor-field">
            <ha-entity-picker
              .hass=${this.hass}
              .value=${this.outdoorTempSensor}
              .includeDomains=${[`sensor`]}
              .entityFilter=${this._filterTemperature}
              .label=${S(`settings.outdoor_sensor_label`,e)}
              allow-custom-entity
              @value-changed=${e=>{let t=e.detail?.value??``;t!==this.outdoorTempSensor&&this._fire(`outdoorTempSensor`,t)}}
            ></ha-entity-picker>
            ${t===null?this.outdoorTempSensor?m`<div class="current-value muted">
                    ${S(`settings.outdoor_waiting`,e)}
                  </div>`:h:m`<div class="current-value">
                  ${S(`settings.outdoor_current`,e,{temp:t.toFixed(1),unit:C(this.hass)})}
                </div>`}
          </div>
          <div class="sensor-field">
            <ha-entity-picker
              .hass=${this.hass}
              .value=${this.outdoorHumiditySensor}
              .includeDomains=${[`sensor`]}
              .entityFilter=${this._filterHumidity}
              .label=${S(`settings.outdoor_humidity_label`,e)}
              allow-custom-entity
              @value-changed=${e=>{let t=e.detail?.value??``;t!==this.outdoorHumiditySensor&&this._fire(`outdoorHumiditySensor`,t)}}
            ></ha-entity-picker>
            ${n===null?this.outdoorHumiditySensor?m`<div class="current-value muted">
                    ${S(`settings.outdoor_waiting`,e)}
                  </div>`:h:m`<div class="current-value">
                  ${S(`settings.outdoor_humidity_current`,e,{value:String(n)})}
                </div>`}
          </div>
        </div>
      </div>

      <div class="settings-section">
        <ha-entity-picker
          .hass=${this.hass}
          .value=${this.weatherEntity}
          .includeDomains=${[`weather`]}
          .label=${S(`settings.weather_entity`,e)}
          allow-custom-entity
          @value-changed=${e=>{let t=e.detail?.value??``;t!==this.weatherEntity&&this._fire(`weatherEntity`,t)}}
        ></ha-entity-picker>
        <span class="field-hint">${S(`settings.weather_entity_hint`,e)}</span>
      </div>

      <div class="settings-section">
        <rs-toggle-row
          .label=${S(`settings.outdoor_unavailable_notify`,e)}
          .hint=${S(`settings.outdoor_unavailable_notify_hint`,e)}
          .checked=${this.outdoorUnavailableNotify}
          @toggle-changed=${e=>this._fire(`outdoorUnavailableNotify`,e.detail)}
        ></rs-toggle-row>
      </div>
    `}static{this.styles=[J.settingsBaseStyles,l`
      .sensor-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
      }
      .current-value {
        margin-top: 8px;
        font-size: 14px;
        color: var(--primary-text-color);
      }
      .current-value.muted {
        color: var(--secondary-text-color);
      }

      @media (max-width: 600px) {
        .sensor-grid {
          grid-template-columns: 1fr;
        }
      }
    `]}};k([y({attribute:!1})],dn.prototype,`hass`,void 0),k([y({type:String})],dn.prototype,`outdoorTempSensor`,void 0),k([y({type:String})],dn.prototype,`outdoorHumiditySensor`,void 0),k([y({type:String})],dn.prototype,`weatherEntity`,void 0),k([y({type:Boolean})],dn.prototype,`outdoorUnavailableNotify`,void 0),dn=k([v(`rs-settings-sensors`)],dn),_(),x(),A();var fn=`https://github.com/snazzybean/roommind/blob/main/docs/control-and-devices.md`,pn=class extends J{constructor(...e){super(...e),this.controlMode=`mpc`,this.comfortWeight=70,this.outdoorCoolingMin=16,this.outdoorHeatingMax=22,this.predictionEnabled=!0,this.scheduleOffAction=`eco`}render(){let e=this.hass.language;return m`
      <div class="settings-section first">
        <p class="hint">${S(`settings.control_mode_hint`,e)}</p>
        <div class="radio-group">
          <label class="radio-option" @click=${()=>this._setControlMode(`mpc`)}>
            <ha-radio name="control_mode" .checked=${this.controlMode===`mpc`}></ha-radio>
            <span>${S(`settings.control_mode_mpc`,e)}</span>
          </label>
          <label class="radio-option" @click=${()=>this._setControlMode(`bangbang`)}>
            <ha-radio name="control_mode" .checked=${this.controlMode===`bangbang`}></ha-radio>
            <span>${S(`settings.control_mode_simple`,e)}</span>
          </label>
        </div>
      </div>

      <div class="settings-section">
        <label class="section-label">${S(`settings.comfort_weight`,e)}</label>
        <div class="slider-row">
          <span class="slider-label">${S(`settings.comfort_weight_efficiency`,e)}</span>
          <input
            type="range"
            min="0"
            max="100"
            step="5"
            .value=${String(this.comfortWeight)}
            @change=${e=>{let t=parseInt(e.target.value,10);!isNaN(t)&&t!==this.comfortWeight&&this._fire(`comfortWeight`,t)}}
          />
          <span class="slider-label">${S(`settings.comfort_weight_comfort`,e)}</span>
        </div>
        <p class="hint helper-text">${S(`settings.comfort_weight_hint`,e)}</p>
        <a class="helper-link" href=${fn} target="_blank" rel="noreferrer">
          ${S(`common.learn_more`,e)}
        </a>
      </div>

      <div class="settings-section">
        <p class="hint">${S(`settings.smart_control_hint`,e)}</p>
        <div class="threshold-grid">
          <div class="threshold-field">
            <ha-textfield
              .value=${String(w(this.outdoorCoolingMin,this.hass))}
              .label=${S(`settings.outdoor_cooling_min`,e)}
              .suffix=${C(this.hass)}
              type="number"
              step=${D(this.hass)}
              min=${O(-10,40,this.hass).min}
              max=${O(-10,40,this.hass).max}
              @change=${e=>{let t=parseFloat(e.target.value);isNaN(t)||this._fire(`outdoorCoolingMin`,At(t,this.hass))}}
            ></ha-textfield>
            <span class="field-hint">${S(`settings.outdoor_cooling_min_hint`,e)}</span>
          </div>
          <div class="threshold-field">
            <ha-textfield
              .value=${String(w(this.outdoorHeatingMax,this.hass))}
              .label=${S(`settings.outdoor_heating_max`,e)}
              .suffix=${C(this.hass)}
              type="number"
              step=${D(this.hass)}
              min=${O(0,40,this.hass).min}
              max=${O(0,40,this.hass).max}
              @change=${e=>{let t=parseFloat(e.target.value);isNaN(t)||this._fire(`outdoorHeatingMax`,At(t,this.hass))}}
            ></ha-textfield>
            <span class="field-hint">${S(`settings.outdoor_heating_max_hint`,e)}</span>
          </div>
        </div>
      </div>

      <div class="settings-section">
        <div class="toggle-row">
          <div class="toggle-text">
            <span class="toggle-label">${S(`settings.prediction_enabled`,e)}</span>
            <span class="toggle-hint">${S(`settings.prediction_enabled_hint`,e)}</span>
          </div>
          <ha-switch
            .checked=${this.predictionEnabled}
            @change=${e=>this._fire(`predictionEnabled`,e.target.checked)}
          ></ha-switch>
        </div>
      </div>

      <div class="settings-section">
        <ha-select
          .label=${S(`schedule.off_action_label`,e)}
          .value=${this.scheduleOffAction}
          .options=${[{value:`eco`,label:S(`schedule.off_action_eco`,e)},{value:`off`,label:S(`schedule.off_action_off`,e)}]}
          fixedMenuPosition
          @selected=${e=>{let t=P(e);t&&t!==this.scheduleOffAction&&this._fire(`scheduleOffAction`,t)}}
          @closed=${e=>e.stopPropagation()}
        >
          <ha-list-item value="eco">${S(`schedule.off_action_eco`,e)}</ha-list-item>
          <ha-list-item value="off">${S(`schedule.off_action_off`,e)}</ha-list-item>
        </ha-select>
      </div>
    `}_setControlMode(e){this.controlMode!==e&&this._fire(`controlMode`,e)}static{this.styles=[J.settingsBaseStyles,l`
      .hint {
        color: var(--secondary-text-color);
        font-size: 13px;
        margin: 0 0 12px;
      }
      .helper-text {
        margin: 10px 0 0;
      }
      .section-label {
        display: block;
        margin-bottom: 8px;
        font-size: 14px;
        color: var(--primary-text-color);
      }

      .radio-group {
        display: flex;
        flex-direction: column;
        gap: 8px;
      }
      .radio-option {
        display: flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
      }

      .slider-row {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .slider-row input[type="range"] {
        flex: 1;
        accent-color: var(--primary-color);
      }
      .slider-label {
        font-size: 12px;
        color: var(--secondary-text-color);
        white-space: nowrap;
      }
      .helper-link {
        display: inline-block;
        margin-top: 6px;
        font-size: 12px;
        color: var(--primary-color);
        text-decoration: none;
      }
      .helper-link:hover {
        text-decoration: underline;
      }
    `]}};k([y({attribute:!1})],pn.prototype,`hass`,void 0),k([y({type:String})],pn.prototype,`controlMode`,void 0),k([y({type:Number})],pn.prototype,`comfortWeight`,void 0),k([y({type:Number})],pn.prototype,`outdoorCoolingMin`,void 0),k([y({type:Number})],pn.prototype,`outdoorHeatingMax`,void 0),k([y({type:Boolean})],pn.prototype,`predictionEnabled`,void 0),k([y({type:String})],pn.prototype,`scheduleOffAction`,void 0),pn=k([v(`rs-settings-control`)],pn),_(),x(),A();var mn=class extends J{constructor(...e){super(...e),this.presenceEnabled=!1,this.presencePersons=[],this.presenceAwayAction=`eco`,this.presenceClearsOverride=!1}render(){let e=this.hass.language;return m`
      <div class="toggle-row">
        <div class="toggle-text">
          <span class="toggle-label">${S(`presence.title`,e)}</span>
          <span class="toggle-hint">${S(`presence.hint`,e)}</span>
        </div>
        <ha-switch
          .checked=${this.presenceEnabled}
          @change=${e=>this._fire(`presenceEnabled`,e.target.checked)}
        ></ha-switch>
      </div>

      ${this.presenceEnabled?m`
            <div class="detail-section">
              <span class="field-hint">${S(`presence.hint_detail`,e)}</span>
              ${this.presencePersons.length>0?m`
                    <div class="person-list">
                      ${this.presencePersons.map(e=>m`
                          <div class="person-row">
                            <ha-icon
                              icon="mdi:account"
                              style="--mdc-icon-size: 18px; color: var(--secondary-text-color)"
                            ></ha-icon>
                            <span class="person-name">${this.hass.states[e]?.attributes?.friendly_name??e.split(`.`).slice(1).join(`.`)}</span>
                            <ha-icon-button
                              .path=${`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}
                              @click=${()=>this._fire(`presencePersons`,this.presencePersons.filter(t=>t!==e))}
                            ></ha-icon-button>
                          </div>
                        `)}
                    </div>
                  `:h}
              <ha-entity-picker
                .hass=${this.hass}
                .includeDomains=${[`person`,`device_tracker`,`binary_sensor`,`input_boolean`]}
                .entityFilter=${e=>!this.presencePersons.includes(e.entity_id)}
                .label=${S(`presence.add_entity`,e)}
                @value-changed=${e=>{let t=e.detail?.value;t&&!this.presencePersons.includes(t)&&this._fire(`presencePersons`,[...this.presencePersons,t]);let n=e.target;n.value=``}}
              ></ha-entity-picker>
              <ha-select
                .label=${S(`presence.away_action_label`,e)}
                .value=${this.presenceAwayAction}
                .options=${[{value:`eco`,label:S(`presence.away_action_eco`,e)},{value:`off`,label:S(`presence.away_action_off`,e)}]}
                fixedMenuPosition
                @selected=${e=>{let t=P(e);t&&t!==this.presenceAwayAction&&this._fire(`presenceAwayAction`,t)}}
                @closed=${e=>e.stopPropagation()}
                style="margin-top: 8px"
              >
                <ha-list-item value="eco">${S(`presence.away_action_eco`,e)}</ha-list-item>
                <ha-list-item value="off">${S(`presence.away_action_off`,e)}</ha-list-item>
              </ha-select>
              <div class="toggle-row">
                <div class="toggle-text">
                  <span class="toggle-label">${S(`presence.clears_override_label`,e)}</span>
                  <span class="toggle-hint">${S(`presence.clears_override_hint`,e)}</span>
                </div>
                <ha-switch
                  .checked=${this.presenceClearsOverride}
                  @change=${e=>this._fire(`presenceClearsOverride`,e.target.checked)}
                ></ha-switch>
              </div>
            </div>
          `:h}
    `}static{this.styles=[J.settingsBaseStyles,l`
      .detail-section {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin-top: 12px;
      }

      .person-list {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }
      .person-row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 4px 8px 4px 12px;
        border-radius: 8px;
        background: rgba(0, 0, 0, 0.04);
      }
      .person-name {
        flex: 1;
        font-size: 14px;
        font-weight: 500;
      }
    `]}};k([y({attribute:!1})],mn.prototype,`hass`,void 0),k([y({type:Boolean})],mn.prototype,`presenceEnabled`,void 0),k([y({type:Array})],mn.prototype,`presencePersons`,void 0),k([y({type:String})],mn.prototype,`presenceAwayAction`,void 0),k([y({type:Boolean})],mn.prototype,`presenceClearsOverride`,void 0),mn=k([v(`rs-settings-presence`)],mn),_(),x(),A();var hn=class extends J{constructor(...e){super(...e),this.vacationActive=!1,this.vacationTemp=15,this.vacationUntil=``}render(){let e=this.hass.language;return m`
      <div class="toggle-row">
        <div class="toggle-text">
          <span class="toggle-label">${S(`vacation.title`,e)}</span>
          <span class="toggle-hint">${S(`vacation.hint`,e)}</span>
        </div>
        <ha-switch
          .checked=${this.vacationActive}
          @change=${e=>{let t=e.target.checked;this._fire(`vacationActive`,t),t||this._fire(`vacationUntil`,``)}}
        ></ha-switch>
      </div>

      ${this.vacationActive?m`
            <div class="threshold-grid" style="margin-top: 12px">
              <div class="threshold-field">
                <ha-textfield
                  .value=${this.vacationUntil}
                  .label=${S(`vacation.end_date`,e)}
                  type="datetime-local"
                  @change=${e=>this._fire(`vacationUntil`,e.target.value)}
                ></ha-textfield>
              </div>
              <div class="threshold-field">
                <ha-textfield
                  .value=${String(w(this.vacationTemp,this.hass))}
                  .label=${S(`vacation.setback_temp`,e)}
                  .suffix=${C(this.hass)}
                  type="number"
                  step=${D(this.hass)}
                  min=${O(5,25,this.hass).min}
                  max=${O(5,25,this.hass).max}
                  @change=${e=>{let t=parseFloat(e.target.value);isNaN(t)||this._fire(`vacationTemp`,At(t,this.hass))}}
                ></ha-textfield>
              </div>
            </div>
          `:h}
    `}static{this.styles=[J.settingsBaseStyles]}};k([y({attribute:!1})],hn.prototype,`hass`,void 0),k([y({type:Boolean})],hn.prototype,`vacationActive`,void 0),k([y({type:Number})],hn.prototype,`vacationTemp`,void 0),k([y({type:String})],hn.prototype,`vacationUntil`,void 0),hn=k([v(`rs-settings-vacation`)],hn),_(),x(),A();var gn=class extends J{constructor(...e){super(...e),this.valveProtectionEnabled=!1,this.valveProtectionInterval=7}render(){let e=this.hass.language;return m`
      <div class="toggle-row">
        <div class="toggle-text">
          <span class="toggle-label">${S(`valve_protection.title`,e)}</span>
          <span class="toggle-hint">${S(`valve_protection.hint`,e)}</span>
        </div>
        <ha-switch
          .checked=${this.valveProtectionEnabled}
          @change=${e=>this._fire(`valveProtectionEnabled`,e.target.checked)}
        ></ha-switch>
      </div>

      ${this.valveProtectionEnabled?m`
            <div class="threshold-grid" style="margin-top: 12px">
              <div class="threshold-field">
                <ha-textfield
                  .value=${String(this.valveProtectionInterval)}
                  .label=${S(`valve_protection.interval_label`,e)}
                  .suffix=${S(`valve_protection.interval_suffix`,e)}
                  type="number"
                  step="1"
                  min="1"
                  max="90"
                  @change=${e=>{let t=parseInt(e.target.value,10);!isNaN(t)&&t>=1&&t<=90&&this._fire(`valveProtectionInterval`,t)}}
                ></ha-textfield>
                <span class="field-hint">${S(`valve_protection.interval_hint`,e)}</span>
              </div>
            </div>
          `:h}
    `}static{this.styles=[J.settingsBaseStyles]}};k([y({attribute:!1})],gn.prototype,`hass`,void 0),k([y({type:Boolean})],gn.prototype,`valveProtectionEnabled`,void 0),k([y({type:Number})],gn.prototype,`valveProtectionInterval`,void 0),gn=k([v(`rs-settings-valve`)],gn),_(),x(),A();var _n=class extends g{constructor(...e){super(...e),this.label=``,this.confirmMessage=``,this.disabled=!1,this.destructive=!1}static{this.styles=l`
    :host {
      display: block;
    }

    .confirm-btn {
      background: transparent;
      border: 1px solid var(--divider-color);
      border-radius: 8px;
      padding: 8px 16px;
      font-size: 14px;
      font-family: inherit;
      cursor: pointer;
      color: var(--primary-text-color);
      transition: all 0.2s;
    }

    .confirm-btn.destructive {
      border-color: var(--error-color);
      color: var(--error-color);
    }

    .confirm-btn.destructive:hover:not([disabled]) {
      background: var(--error-color);
      color: #fff;
    }

    .confirm-btn[disabled] {
      opacity: 0.5;
      cursor: not-allowed;
    }
  `}render(){return m`
      <button
        class="confirm-btn ${this.destructive?`destructive`:``}"
        ?disabled=${this.disabled}
        @click=${this._onClick}
      >
        ${this.label}
      </button>
    `}_onClick(){this.disabled||this.confirmMessage&&!confirm(this.confirmMessage)||this.dispatchEvent(new CustomEvent(`confirmed`,{bubbles:!0,composed:!0}))}};k([y({type:String})],_n.prototype,`label`,void 0),k([y({type:String})],_n.prototype,`confirmMessage`,void 0),k([y({type:Boolean})],_n.prototype,`disabled`,void 0),k([y({type:Boolean})],_n.prototype,`destructive`,void 0),_n=k([v(`rs-confirm-button`)],_n),_(),x(),A();var vn=class extends g{constructor(...e){super(...e),this.compressorGroups=[],this._memberFilter=e=>{let t=e.entity_id;if(t.substring(t.indexOf(`.`)+1).startsWith(`roommind_`))return!1;for(let e of this.compressorGroups)if(e.members.includes(t)||e.master_entity===t)return!1;return!0},this._masterFilter=e=>{let t=e.entity_id;if(t.substring(t.indexOf(`.`)+1).startsWith(`roommind_`))return!1;for(let e of this.compressorGroups)if(e.members.includes(t)||e.master_entity===t)return!1;return!0}}static{this.styles=[I,l`
      :host {
        display: block;
      }
      .group-card {
        border: 1px solid var(--divider-color);
        border-radius: 8px;
        padding: 16px;
        margin-bottom: 16px;
      }
      .member-list {
        display: flex;
        flex-direction: column;
        gap: 4px;
        margin: 8px 0;
      }
      .member-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 4px 8px;
        background: var(--card-background-color);
        border-radius: 4px;
      }
      .member-name {
        font-size: 14px;
        flex: 1;
      }
      .member-area {
        font-size: 12px;
        color: var(--secondary-text-color);
        margin-left: 4px;
      }
      .member-missing {
        color: var(--error-color);
      }
      .field-row {
        margin-top: 12px;
      }
      .field-hint {
        font-size: 12px;
        color: var(--secondary-text-color);
        margin-top: 4px;
      }
      .section-label {
        font-size: 14px;
        font-weight: 500;
        margin-top: 12px;
        margin-bottom: 4px;
      }
      .add-button {
        margin-top: 12px;
      }
      .delete-row {
        margin-top: 16px;
        display: flex;
        justify-content: flex-end;
      }
      .no-groups {
        color: var(--secondary-text-color);
        font-size: 14px;
        padding: 8px 0;
      }
      ha-textfield {
        width: 100%;
      }
      ha-entity-picker {
        width: 100%;
      }
      .number-fields {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
        margin-top: 12px;
      }
      @media (max-width: 500px) {
        .number-fields {
          grid-template-columns: 1fr;
        }
      }
    `]}render(){let e=this.hass.language;return m`
      ${this.compressorGroups.length===0?m`<div class="no-groups">${S(`compressor.no_groups`,e)}</div>`:this.compressorGroups.map((e,t)=>this._renderGroup(e,t))}
      <ha-button class="add-button" @click=${this._addGroup}>
        <ha-icon icon="mdi:plus" slot="icon"></ha-icon>
        ${S(`compressor.add_group`,e)}
      </ha-button>
    `}_renderGroup(e,t){let n=this.hass.language;return m`
      <div class="group-card">
        <ha-textfield
          .value=${e.name}
          .label=${S(`compressor.group_name`,n)}
          @change=${e=>{let n=e.target.value;this._updateGroup(t,`name`,n)}}
        ></ha-textfield>

        <div class="section-label">${S(`compressor.members`,n)}</div>
        ${e.members.length>0?m`
              <div class="member-list">
                ${e.members.map(e=>this._renderMember(e,t))}
              </div>
            `:h}
        <ha-entity-picker
          .hass=${this.hass}
          .value=${``}
          .includeDomains=${[`climate`]}
          .entityFilter=${this._memberFilter}
          @value-changed=${e=>{let n=e.detail?.value??``;if(!n)return;let r=[...this.compressorGroups];r[t]={...r[t],members:[...r[t].members,n]},this._fire(r);let i=e.target;i&&(i.value=``)}}
        ></ha-entity-picker>
        <div class="field-hint">${S(`compressor.members_hint`,n)}</div>

        <div class="number-fields">
          <div>
            <ha-textfield
              type="number"
              .value=${String(e.min_run_minutes)}
              .label=${S(`compressor.min_run`,n)}
              .suffix=${S(`compressor.min_run_suffix`,n)}
              min="1"
              max="60"
              step="1"
              @change=${e=>{let n=parseInt(e.target.value,10);!isNaN(n)&&n>=1&&n<=60&&this._updateGroup(t,`min_run_minutes`,n)}}
            ></ha-textfield>
            <div class="field-hint">${S(`compressor.min_run_hint`,n)}</div>
          </div>
          <div>
            <ha-textfield
              type="number"
              .value=${String(e.min_off_minutes)}
              .label=${S(`compressor.min_off`,n)}
              .suffix=${S(`compressor.min_off_suffix`,n)}
              min="1"
              max="30"
              step="1"
              @change=${e=>{let n=parseInt(e.target.value,10);!isNaN(n)&&n>=1&&n<=30&&this._updateGroup(t,`min_off_minutes`,n)}}
            ></ha-textfield>
            <div class="field-hint">${S(`compressor.min_off_hint`,n)}</div>
          </div>
        </div>

        <div class="section-label">${S(`compressor.master_entity`,n)}</div>
        <ha-entity-picker
          .hass=${this.hass}
          .value=${e.master_entity||``}
          .includeDomains=${[`climate`]}
          .entityFilter=${this._masterFilter}
          @value-changed=${e=>{this._updateGroup(t,`master_entity`,e.detail?.value??``)}}
        ></ha-entity-picker>
        <div class="field-hint">${S(`compressor.master_entity_hint`,n)}</div>

        <div class="field-row">
          <ha-formfield .label=${S(`compressor.enforce_uniform_mode`,n)}>
            <ha-switch
              .checked=${e.enforce_uniform_mode||!1}
              @change=${e=>{this._updateGroup(t,`enforce_uniform_mode`,e.target.checked)}}
            ></ha-switch>
          </ha-formfield>
          <div class="field-hint">${S(`compressor.enforce_uniform_mode_hint`,n)}</div>
        </div>

        ${e.master_entity||e.enforce_uniform_mode?m`
              <div class="field-row">
                <ha-select
                  .label=${S(`compressor.conflict_resolution`,n)}
                  .value=${e.conflict_resolution||`heating_priority`}
                  .options=${[{value:`heating_priority`,label:S(`compressor.conflict_heating_priority`,n)},{value:`cooling_priority`,label:S(`compressor.conflict_cooling_priority`,n)},{value:`majority`,label:S(`compressor.conflict_majority`,n)},{value:`outdoor_temp`,label:S(`compressor.conflict_outdoor_temp`,n)}]}
                  @selected=${e=>{let n=P(e);n&&this._updateGroup(t,`conflict_resolution`,n)}}
                  @closed=${e=>e.stopPropagation()}
                  fixedMenuPosition
                  style="width: 100%;"
                >
                </ha-select>
                <div class="field-hint">${S(`compressor.conflict_resolution_hint`,n)}</div>
              </div>
            `:h}

        <div class="field-row">
          <ha-entity-picker
            .hass=${this.hass}
            .value=${e.action_script||``}
            .includeDomains=${[`script`]}
            .label=${S(`compressor.action_script`,n)}
            @value-changed=${e=>{this._updateGroup(t,`action_script`,e.detail?.value??``)}}
          ></ha-entity-picker>
          <div class="field-hint">${S(`compressor.action_script_hint`,n)}</div>
        </div>

        <div class="delete-row">
          <rs-confirm-button
            .label=${S(`compressor.delete`,n)}
            .confirmMessage=${S(`compressor.delete_confirm`,n).replace(`{name}`,e.name||`#${t+1}`)}
            destructive
            @confirmed=${()=>{this._fire(this.compressorGroups.filter((e,n)=>n!==t))}}
          ></rs-confirm-button>
        </div>
      </div>
    `}_renderMember(e,t){let n=this.hass.states[e],r=!n,i=n?.attributes?.friendly_name||e,a=this.hass.entities[e]?.area_id,o=a?this.hass.areas[a]?.name:void 0;return m`
      <div class="member-row">
        <span class="member-name ${r?`member-missing`:``}"
          >${i}${o?m`<span class="member-area">(${o})</span>`:h}</span
        >
        <ha-icon-button
          .path=${`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}
          @click=${()=>{let n=[...this.compressorGroups];n[t]={...n[t],members:n[t].members.filter(t=>t!==e)},this._fire(n)}}
        ></ha-icon-button>
      </div>
    `}_updateGroup(e,t,n){let r=[...this.compressorGroups];r[e]={...r[e],[t]:n},this._fire(r)}_addGroup(){this._fire([...this.compressorGroups,{id:self.crypto?.randomUUID?.()??`${Date.now()}-${Math.random().toString(36).slice(2)}`,name:``,members:[],min_run_minutes:15,min_off_minutes:5,master_entity:``,conflict_resolution:`heating_priority`,action_script:``,enforce_uniform_mode:!1}])}_fire(e){this.dispatchEvent(new CustomEvent(`setting-changed`,{detail:{key:`compressorGroups`,value:e},bubbles:!0,composed:!0}))}};k([y({attribute:!1})],vn.prototype,`hass`,void 0),k([y({type:Array})],vn.prototype,`compressorGroups`,void 0),vn=k([v(`rs-settings-compressor`)],vn),_(),x(),A();var yn=class extends J{constructor(...e){super(...e),this.moldDetectionEnabled=!1,this.moldHumidityThreshold=70,this.moldSustainedMinutes=30,this.moldPreventionEnabled=!1,this.moldPreventionIntensity=`medium`}render(){let e=this.hass.language;return m`
      <!-- Detection section -->
      <div class="settings-section first">
        <div class="toggle-row">
          <div class="toggle-text">
            <span class="toggle-label">
              <ha-icon
                icon="mdi:bell-alert"
                style="--mdc-icon-size: 18px; vertical-align: middle; margin-right: 4px"
              ></ha-icon>
              ${S(`mold.detection`,e)}
            </span>
            <span class="toggle-hint">${S(`mold.detection_desc`,e)}</span>
          </div>
          <ha-switch
            .checked=${this.moldDetectionEnabled}
            @change=${e=>this._fire(`moldDetectionEnabled`,e.target.checked)}
          ></ha-switch>
        </div>
        ${this.moldDetectionEnabled?m`
              <div class="threshold-grid" style="margin-top: 12px">
                <div class="threshold-field">
                  <ha-textfield
                    .value=${String(this.moldHumidityThreshold)}
                    .label=${S(`mold.threshold`,e)}
                    .suffix=${`%`}
                    type="number"
                    step="1"
                    min="50"
                    max="90"
                    @change=${e=>{let t=parseFloat(e.target.value);!isNaN(t)&&t>=50&&t<=90&&this._fire(`moldHumidityThreshold`,t)}}
                  ></ha-textfield>
                  <span class="field-hint">${S(`mold.threshold_hint`,e)}</span>
                </div>
                <div class="threshold-field">
                  <ha-textfield
                    .value=${String(this.moldSustainedMinutes)}
                    .label=${S(`mold.sustained`,e)}
                    .suffix=${`min`}
                    type="number"
                    step="5"
                    min="5"
                    max="120"
                    @change=${e=>{let t=parseInt(e.target.value,10);!isNaN(t)&&t>=5&&t<=120&&this._fire(`moldSustainedMinutes`,t)}}
                  ></ha-textfield>
                  <span class="field-hint">${S(`mold.sustained_hint`,e)}</span>
                </div>
              </div>
            `:h}
      </div>

      <!-- Prevention section -->
      <div class="settings-section">
        <div class="toggle-row">
          <div class="toggle-text">
            <span class="toggle-label">
              <ha-icon
                icon="mdi:shield-check"
                style="--mdc-icon-size: 18px; vertical-align: middle; margin-right: 4px"
              ></ha-icon>
              ${S(`mold.prevention`,e)}
            </span>
            <span class="toggle-hint">${S(`mold.prevention_desc`,e)}</span>
          </div>
          <ha-switch
            .checked=${this.moldPreventionEnabled}
            @change=${e=>this._fire(`moldPreventionEnabled`,e.target.checked)}
          ></ha-switch>
        </div>
        ${this.moldPreventionEnabled?m`
              <div style="margin-top: 12px; display: flex; flex-direction: column; gap: 4px;">
                <ha-select
                  style="width: 100%;"
                  .value=${this.moldPreventionIntensity}
                  .label=${S(`mold.intensity`,e)}
                  .options=${[{value:`light`,label:S(`mold.intensity_light`,e,{delta:String(T(1,this.hass)),unit:C(this.hass)})},{value:`medium`,label:S(`mold.intensity_medium`,e,{delta:String(T(2,this.hass)),unit:C(this.hass)})},{value:`strong`,label:S(`mold.intensity_strong`,e,{delta:String(T(3,this.hass)),unit:C(this.hass)})}]}
                  fixedMenuPosition
                  @selected=${e=>{let t=P(e);t&&t!==this.moldPreventionIntensity&&this._fire(`moldPreventionIntensity`,t)}}
                  @closed=${e=>e.stopPropagation()}
                >
                  <ha-list-item value="light"
                    >${S(`mold.intensity_light`,e,{delta:String(T(1,this.hass)),unit:C(this.hass)})}</ha-list-item
                  >
                  <ha-list-item value="medium"
                    >${S(`mold.intensity_medium`,e,{delta:String(T(2,this.hass)),unit:C(this.hass)})}</ha-list-item
                  >
                  <ha-list-item value="strong"
                    >${S(`mold.intensity_strong`,e,{delta:String(T(3,this.hass)),unit:C(this.hass)})}</ha-list-item
                  >
                </ha-select>
                <span class="field-hint">${S(`mold.intensity_hint`,e)}</span>
              </div>
            `:h}
      </div>
    `}static{this.styles=[J.settingsBaseStyles]}};k([y({attribute:!1})],yn.prototype,`hass`,void 0),k([y({type:Boolean})],yn.prototype,`moldDetectionEnabled`,void 0),k([y({type:Number})],yn.prototype,`moldHumidityThreshold`,void 0),k([y({type:Number})],yn.prototype,`moldSustainedMinutes`,void 0),k([y({type:Boolean})],yn.prototype,`moldPreventionEnabled`,void 0),k([y({type:String})],yn.prototype,`moldPreventionIntensity`,void 0),yn=k([v(`rs-settings-mold`)],yn),_(),x(),A();var bn=class extends J{constructor(...e){super(...e),this.notificationsEnabled=!0,this.notificationTargets=[],this.notificationCooldown=60,this.moldPreventionEnabled=!1,this.moldPreventionNotify=!1}render(){let e=this.hass.language;return m`
      <div class="toggle-row">
        <div class="toggle-text">
          <span class="toggle-label">${S(`notifications.enabled`,e)}</span>
          <span class="toggle-hint">${S(`notifications.enabled_hint`,e)}</span>
        </div>
        <ha-switch
          .checked=${this.notificationsEnabled}
          @change=${e=>this._fire(`moldNotificationsEnabled`,e.target.checked)}
        ></ha-switch>
      </div>

      ${this.notificationsEnabled?m`
            <div class="detail-section">
              <p class="hint">${S(`notifications.desc`,e)}</p>

              <div class="target-list">
                ${this.notificationTargets.map((t,n)=>m`
                    <div class="target-card">
                      <div class="target-header">
                        <ha-icon
                          icon="mdi:bell"
                          style="--mdc-icon-size: 18px; color: var(--secondary-text-color)"
                        ></ha-icon>
                        <span>${t.entity_id?this.hass.states[t.entity_id]?.attributes?.friendly_name??t.entity_id.replace(`notify.`,``):S(`notifications.target_unnamed`,e)}</span>
                        <ha-icon-button
                          .path=${`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}
                          @click=${()=>{this._fire(`moldNotificationTargets`,this.notificationTargets.filter((e,t)=>t!==n))}}
                        ></ha-icon-button>
                      </div>
                      <div class="target-detail">
                        <ha-entity-picker
                          .hass=${this.hass}
                          .value=${t.person_entity}
                          .includeDomains=${[`person`]}
                          .label=${S(`notifications.target_person`,e)}
                          allow-custom-entity
                          @value-changed=${e=>{let t=[...this.notificationTargets];t[n]={...t[n],person_entity:e.detail?.value??``},this._fire(`moldNotificationTargets`,t)}}
                        ></ha-entity-picker>
                        <ha-select
                          .value=${t.notify_when}
                          .options=${[{value:`always`,label:S(`notifications.target_when_always`,e)},{value:`home_only`,label:S(`notifications.target_when_home`,e)}]}
                          fixedMenuPosition
                          @selected=${e=>{let t=P(e);if(!t)return;let r=[...this.notificationTargets];r[n]={...r[n],notify_when:t},this._fire(`moldNotificationTargets`,r)}}
                          @closed=${e=>e.stopPropagation()}
                        >
                          <ha-list-item value="always"
                            >${S(`notifications.target_when_always`,e)}</ha-list-item
                          >
                          <ha-list-item value="home_only"
                            >${S(`notifications.target_when_home`,e)}</ha-list-item
                          >
                        </ha-select>
                      </div>
                    </div>
                  `)}
              </div>

              <div style="margin-top: 8px">
                <ha-entity-picker
                  .hass=${this.hass}
                  .value=${``}
                  .includeDomains=${[`notify`]}
                  .label=${S(`notifications.add_target_label`,e)}
                  allow-custom-entity
                  @value-changed=${e=>{let t=e.detail?.value??``;if(!t)return;this._fire(`moldNotificationTargets`,[...this.notificationTargets,{entity_id:t,person_entity:``,notify_when:`always`}]);let n=e.target;n&&(n.value=``)}}
                ></ha-entity-picker>
                <span class="field-hint">${S(`notifications.add_target_hint`,e)}</span>
              </div>

              <div class="threshold-grid" style="margin-top: 12px">
                <div class="threshold-field">
                  <ha-textfield
                    .value=${String(this.notificationCooldown)}
                    .label=${S(`notifications.cooldown`,e)}
                    .suffix=${`min`}
                    type="number"
                    step="5"
                    min="10"
                    max="1440"
                    @change=${e=>{let t=parseInt(e.target.value,10);!isNaN(t)&&t>=10&&t<=1440&&this._fire(`moldNotificationCooldown`,t)}}
                  ></ha-textfield>
                  <span class="field-hint">${S(`notifications.cooldown_hint`,e)}</span>
                </div>
              </div>

              ${this.moldPreventionEnabled?m`
                    <div class="toggle-row" style="margin-top: 12px">
                      <div class="toggle-text">
                        <span class="toggle-label"
                          >${S(`notifications.mold_prevention_notify`,e)}</span
                        >
                        <span class="toggle-hint"
                          >${S(`notifications.mold_prevention_notify_hint`,e)}</span
                        >
                      </div>
                      <ha-switch
                        .checked=${this.moldPreventionNotify}
                        @change=${e=>this._fire(`moldPreventionNotify`,e.target.checked)}
                      ></ha-switch>
                    </div>
                  `:h}
            </div>
          `:h}
    `}static{this.styles=[J.settingsBaseStyles,l`
      .hint {
        color: var(--secondary-text-color);
        font-size: 13px;
        margin: 12px 0;
        line-height: 1.4;
      }
      .detail-section {
        margin-top: 4px;
      }
      .field-hint {
        color: var(--secondary-text-color);
        font-size: 12px;
      }

      .target-list {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }
      .target-card {
        display: flex;
        flex-direction: column;
        gap: 4px;
        padding: 8px 8px 8px 12px;
        border-radius: 8px;
        background: rgba(0, 0, 0, 0.04);
      }
      .target-header {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .target-header span {
        flex: 1;
        font-size: 14px;
        font-weight: 500;
      }
      .target-detail {
        display: flex;
        gap: 8px;
        align-items: center;
        padding-left: 26px;
      }
      .target-detail ha-entity-picker {
        flex: 1;
      }
      .target-detail ha-select {
        min-width: 120px;
      }

      @media (max-width: 600px) {
        .target-detail {
          flex-direction: column;
          padding-left: 0;
        }
      }
    `]}};k([y({attribute:!1})],bn.prototype,`hass`,void 0),k([y({type:Boolean})],bn.prototype,`notificationsEnabled`,void 0),k([y({type:Array})],bn.prototype,`notificationTargets`,void 0),k([y({type:Number})],bn.prototype,`notificationCooldown`,void 0),k([y({type:Boolean})],bn.prototype,`moldPreventionEnabled`,void 0),k([y({type:Boolean})],bn.prototype,`moldPreventionNotify`,void 0),bn=k([v(`rs-settings-notifications`)],bn),_(),x(),A();var xn=250,Sn=class extends J{constructor(...e){super(...e),this.rooms={},this.learningDisabledRooms=[],this.boostAppliedAt={},this.roomsLive={},this._showLearningExceptions=!1,this._boostSelectedRoom=``}render(){let e=this.hass.language,t=Object.entries(this.rooms).map(([e])=>({areaId:e,name:this.hass.areas?.[e]?.name??e})).sort((e,t)=>e.name.localeCompare(t.name)),n=Object.keys(this.rooms),r=n.length===0||this.learningDisabledRooms.length<n.length,i=this.learningDisabledRooms.filter(e=>n.includes(e)).length;return m`
      <!-- Learning toggle -->
      <div class="settings-section first">
        <div class="toggle-row">
          <div class="toggle-text">
            <span class="toggle-label">${S(`settings.learning_title`,e)}</span>
            <span class="toggle-hint">${S(`settings.learning_hint`,e)}</span>
          </div>
          <ha-switch
            .checked=${r}
            @change=${e=>{let t=e.target.checked;this._fire(`learningDisabledRooms`,t?[]:Object.keys(this.rooms)),t||(this._showLearningExceptions=!1)}}
          ></ha-switch>
        </div>
        ${r&&t.length>0?m`
              <button
                class="exceptions-link"
                @click=${()=>{this._showLearningExceptions=!this._showLearningExceptions}}
              >
                <span
                  >${i>0?`${i} ${S(i===1?`settings.learning_room_paused`:`settings.learning_rooms_paused`,e)}`:S(`settings.learning_exceptions`,e)}</span
                >
                <ha-icon
                  icon=${this._showLearningExceptions?`mdi:chevron-up`:`mdi:chevron-down`}
                  style="--mdc-icon-size: 16px"
                ></ha-icon>
              </button>
              ${this._showLearningExceptions?m`
                    <div class="room-toggles">
                      ${t.map(e=>m`
                          <div class="room-toggle-row">
                            <span class="room-toggle-name">${e.name}</span>
                            <ha-switch
                              .checked=${!this.learningDisabledRooms.includes(e.areaId)}
                              @change=${t=>{let n=!t.target.checked,r=new Set(this.learningDisabledRooms);n?r.add(e.areaId):r.delete(e.areaId),this._fire(`learningDisabledRooms`,[...r])}}
                            ></ha-switch>
                          </div>
                        `)}
                    </div>
                  `:h}
            `:h}
      </div>

      <!-- Boost learning -->
      <div class="settings-section">
        <span class="toggle-label">${S(`settings.boost_title`,e)}</span>
        <p class="hint">${S(`settings.boost_hint`,e)}</p>

        ${t.length>0?m`
              <div class="room-select-row">
                <ha-select
                  .value=${this._boostSelectedRoom}
                  .label=${S(`settings.boost_room_select`,e)}
                  .options=${t.map(e=>({value:e.areaId,label:e.name}))}
                  fixedMenuPosition
                  @selected=${e=>{this._boostSelectedRoom=P(e)}}
                  @closed=${e=>e.stopPropagation()}
                >
                  ${t.map(e=>m`<ha-list-item value=${e.areaId}>${e.name}</ha-list-item>`)}
                </ha-select>
                ${this._boostSelectedRoom?m`<ha-icon-button
                      .path=${`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}
                      @click=${()=>{this._boostSelectedRoom=``}}
                    ></ha-icon-button>`:h}
                ${this._boostSelectedRoom&&this._isCooldown(this._boostSelectedRoom)?m`<span class="boost-status">
                      <ha-icon icon="mdi:check-circle-outline"></ha-icon>
                      ${S(`settings.boost_cooldown`,e)}
                    </span>`:m`<button
                      class="boost-btn"
                      ?disabled=${!this._boostSelectedRoom||this._isCooldown(this._boostSelectedRoom)}
                      @click=${()=>this._boostSelectedRoom&&this._boostLearning(this._boostSelectedRoom)}
                    >
                      <ha-icon icon="mdi:lightning-bolt"></ha-icon>
                      ${S(`settings.boost_btn`,e)}
                    </button>`}
              </div>
            `:m`<p class="hint">${S(`settings.boost_no_rooms`,e)}</p>`}
      </div>
    `}_isCooldown(e){let t=this.roomsLive?.[e]?.n_observations??0,n=this.boostAppliedAt[e];return n!==void 0&&t-n<xn}async _boostLearning(e){try{F(this,`saving`);let t=await this.hass.callWS({type:`roommind/model/boost_learning`,area_id:e});F(this,`saved`),this.dispatchEvent(new CustomEvent(`boost-applied`,{detail:{area_id:e,n_observations:t.n_observations},bubbles:!0,composed:!0}))}catch{F(this,`error`)}}static{this.styles=[J.settingsBaseStyles,l`
      .hint {
        color: var(--secondary-text-color);
        font-size: 13px;
        margin: 4px 0 12px;
        line-height: 1.4;
      }

      .exceptions-link {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        background: none;
        border: none;
        padding: 8px 0 0;
        margin: 0;
        cursor: pointer;
        font-size: 13px;
        color: var(--primary-color);
        font-family: inherit;
      }
      .exceptions-link:hover {
        text-decoration: underline;
      }

      .room-toggles {
        display: flex;
        flex-direction: column;
        gap: 4px;
        margin-top: 12px;
      }
      .room-toggle-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 4px 0;
      }
      .room-toggle-name {
        font-size: 14px;
        color: var(--primary-text-color);
      }

      .room-select-row {
        display: flex;
        align-items: center;
        gap: 12px;
      }
      .room-select-row ha-select {
        flex: 1;
      }

      .boost-btn {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 8px 14px;
        border: 1px solid var(--primary-color);
        border-radius: 8px;
        background: transparent;
        color: var(--primary-color);
        font-size: 13px;
        font-family: inherit;
        cursor: pointer;
        transition: background 0.15s;
        --mdc-icon-size: 16px;
        white-space: nowrap;
      }
      .boost-btn:hover {
        background: rgba(var(--rgb-primary-color), 0.08);
      }
      .boost-btn:disabled {
        opacity: 0.4;
        cursor: not-allowed;
      }
      .boost-btn:disabled:hover {
        background: transparent;
      }

      .boost-status {
        display: flex;
        align-items: center;
        gap: 6px;
        color: var(--success-color, #4caf50);
        font-size: 13px;
        --mdc-icon-size: 16px;
        white-space: nowrap;
      }
    `]}};k([y({attribute:!1})],Sn.prototype,`hass`,void 0),k([y({attribute:!1})],Sn.prototype,`rooms`,void 0),k([y({type:Array})],Sn.prototype,`learningDisabledRooms`,void 0),k([y({attribute:!1})],Sn.prototype,`boostAppliedAt`,void 0),k([y({attribute:!1})],Sn.prototype,`roomsLive`,void 0),k([b()],Sn.prototype,`_showLearningExceptions`,void 0),k([b()],Sn.prototype,`_boostSelectedRoom`,void 0),Sn=k([v(`rs-settings-learning`)],Sn),_(),x(),A();var Cn=class extends J{constructor(...e){super(...e),this.rooms={},this._resetSelectedRoom=``}render(){let e=this.hass.language,t=Object.entries(this.rooms).map(([e])=>({areaId:e,name:this.hass.areas?.[e]?.name??e})).sort((e,t)=>e.name.localeCompare(t.name));return m`
      <div class="settings-section first">
        <div class="reset-row">
          <div class="reset-text">
            <span class="toggle-label">${S(`settings.reset_all_label`,e)}</span>
            <span class="toggle-hint">${S(`settings.reset_all_hint`,e)}</span>
          </div>
          <button class="reset-btn" @click=${this._resetAllModels}>
            <ha-icon icon="mdi:restart-alert"></ha-icon>
            ${S(`settings.reset_all_btn`,e)}
          </button>
        </div>
      </div>

      <div class="settings-section">
        <div class="reset-text" style="margin-bottom: 12px">
          <span class="toggle-label">${S(`settings.reset_room_label`,e)}</span>
          <span class="toggle-hint">${S(`settings.reset_room_hint`,e)}</span>
        </div>
        ${t.length>0?m`
              <div class="reset-room-row">
                <ha-select
                  .value=${this._resetSelectedRoom}
                  .label=${S(`settings.reset_room_select`,e)}
                  .options=${t.map(e=>({value:e.areaId,label:e.name}))}
                  fixedMenuPosition
                  @selected=${e=>{this._resetSelectedRoom=P(e)}}
                  @closed=${e=>e.stopPropagation()}
                >
                  ${t.map(e=>m`<ha-list-item value=${e.areaId}>${e.name}</ha-list-item>`)}
                </ha-select>
                ${this._resetSelectedRoom?m`<ha-icon-button
                      .path=${`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}
                      @click=${()=>{this._resetSelectedRoom=``}}
                    ></ha-icon-button>`:h}
                <button
                  class="reset-btn"
                  ?disabled=${!this._resetSelectedRoom}
                  @click=${()=>this._resetSelectedRoom&&this._resetRoomModel(this._resetSelectedRoom)}
                >
                  <ha-icon icon="mdi:restart"></ha-icon>
                  ${S(`settings.reset_btn`,e)}
                </button>
              </div>
            `:m`<p class="hint">${S(`settings.reset_no_rooms`,e)}</p>`}
      </div>
    `}async _resetRoomModel(e){let t=this.hass.language;if(confirm(S(`settings.reset_room_confirm`,t)))try{F(this,`saving`),await this.hass.callWS({type:`roommind/thermal/reset`,area_id:e}),F(this,`saved`)}catch{F(this,`error`)}}async _resetAllModels(){let e=this.hass.language;if(confirm(S(`settings.reset_all_confirm`,e)))try{F(this,`saving`),await this.hass.callWS({type:`roommind/thermal/reset_all`}),F(this,`saved`)}catch{F(this,`error`)}}static{this.styles=[J.settingsBaseStyles,l`
      .hint {
        color: var(--secondary-text-color);
        font-size: 13px;
        margin: 0;
      }

      .reset-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 16px;
      }
      .reset-text {
        display: flex;
        flex-direction: column;
        gap: 4px;
        flex: 1;
      }

      .reset-btn {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 8px 14px;
        border: 1px solid var(--error-color, #d32f2f);
        border-radius: 8px;
        background: transparent;
        color: var(--error-color, #d32f2f);
        font-size: 13px;
        font-family: inherit;
        cursor: pointer;
        transition: background 0.15s;
        --mdc-icon-size: 16px;
        white-space: nowrap;
      }
      .reset-btn:hover {
        background: rgba(211, 47, 47, 0.08);
      }
      .reset-btn:disabled {
        opacity: 0.4;
        cursor: not-allowed;
      }
      .reset-btn:disabled:hover {
        background: transparent;
      }

      .reset-room-row {
        display: flex;
        align-items: center;
        gap: 12px;
      }
      .reset-room-row ha-select {
        flex: 1;
      }

      @media (max-width: 600px) {
        .reset-row {
          flex-direction: column;
          align-items: flex-start;
          gap: 12px;
        }
      }
    `]}};k([y({attribute:!1})],Cn.prototype,`hass`,void 0),k([y({attribute:!1})],Cn.prototype,`rooms`,void 0),k([b()],Cn.prototype,`_resetSelectedRoom`,void 0),Cn=k([v(`rs-settings-reset`)],Cn),_(),x(),A();var Y=class extends g{constructor(...e){super(...e),this.rooms={},this._groupByFloor=!1,this._climateControlActive=!0,this._learningDisabledRooms=[],this._outdoorTempSensor=``,this._outdoorHumiditySensor=``,this._outdoorCoolingMin=16,this._outdoorHeatingMax=22,this._controlMode=`mpc`,this._comfortWeight=70,this._weatherEntity=``,this._outdoorUnavailableNotify=!0,this._predictionEnabled=!0,this._vacationActive=!1,this._vacationTemp=15,this._vacationUntil=``,this._presenceEnabled=!1,this._presencePersons=[],this._presenceAwayAction=`eco`,this._presenceClearsOverride=!1,this._scheduleOffAction=`eco`,this._valveProtectionEnabled=!1,this._valveProtectionInterval=7,this._moldDetectionEnabled=!1,this._moldHumidityThreshold=70,this._moldSustainedMinutes=30,this._moldNotificationCooldown=60,this._moldNotificationsEnabled=!0,this._moldNotificationTargets=[],this._moldPreventionEnabled=!1,this._moldPreventionIntensity=`medium`,this._moldPreventionNotify=!1,this._compressorGroups=[],this._boostAppliedAt={},this._loaded=!1}connectedCallback(){super.connectedCallback(),this._loadSettings()}disconnectedCallback(){super.disconnectedCallback(),this._saveDebounce&&clearTimeout(this._saveDebounce)}async _loadSettings(){try{let e=(await this.hass.callWS({type:`roommind/settings/get`})).settings;this._groupByFloor=e.group_by_floor??!1,this._climateControlActive=e.climate_control_active??!0,this._learningDisabledRooms=e.learning_disabled_rooms??[],this._outdoorTempSensor=e.outdoor_temp_sensor??``,this._outdoorHumiditySensor=e.outdoor_humidity_sensor??``,this._outdoorCoolingMin=e.outdoor_cooling_min??16,this._outdoorHeatingMax=e.outdoor_heating_max??22,this._controlMode=e.control_mode??`mpc`,this._comfortWeight=e.comfort_weight??70,this._weatherEntity=e.weather_entity??``,this._outdoorUnavailableNotify=e.outdoor_unavailable_notify??!0,this._predictionEnabled=e.prediction_enabled??!0;let t=e.vacation_until;this._vacationActive=!!(t&&t>Date.now()/1e3),this._vacationTemp=e.vacation_temp??15,t&&t>Date.now()/1e3&&t<3250368e4?this._vacationUntil=this._tsToDatetimeLocal(t):this._vacationUntil=``,this._presenceEnabled=e.presence_enabled??!1,this._presencePersons=e.presence_persons??[],this._presenceAwayAction=e.presence_away_action??`eco`,this._presenceClearsOverride=e.presence_clears_override??!1,this._scheduleOffAction=e.schedule_off_action??`eco`,this._valveProtectionEnabled=e.valve_protection_enabled??!1,this._valveProtectionInterval=e.valve_protection_interval_days??7,this._moldDetectionEnabled=e.mold_detection_enabled??!1,this._moldHumidityThreshold=e.mold_humidity_threshold??70,this._moldSustainedMinutes=e.mold_sustained_minutes??30,this._moldNotificationCooldown=e.mold_notification_cooldown??60,this._moldNotificationsEnabled=e.mold_notifications_enabled??!0,this._moldNotificationTargets=e.mold_notification_targets??[],this._moldPreventionEnabled=e.mold_prevention_enabled??!1,this._moldPreventionIntensity=e.mold_prevention_intensity??`medium`,this._moldPreventionNotify=e.mold_prevention_notify_enabled??!1,this._compressorGroups=e.compressor_groups??[],this._boostAppliedAt=e.boost_applied_at??{}}catch(e){console.debug(`[RoomMind] loadSettings:`,e)}finally{this._loaded=!0}}render(){if(!this._loaded)return m`<div class="loading">${S(`panel.loading`,this.hass.language)}</div>`;let e=this.hass.language;return m`
      <rs-settings-panel
        icon="mdi:power"
        .heading=${S(`settings.general_title`,e)}
        .intro=${S(`settings.intro.general`,e)}
      >
        <rs-settings-general
          .hass=${this.hass}
          .groupByFloor=${this._groupByFloor}
          .climateControlActive=${this._climateControlActive}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-general>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:thermometer"
        .heading=${S(`settings.sensors_title`,e)}
        .intro=${S(`settings.intro.sensors`,e)}
      >
        <rs-settings-sensors
          .hass=${this.hass}
          .outdoorTempSensor=${this._outdoorTempSensor}
          .outdoorHumiditySensor=${this._outdoorHumiditySensor}
          .weatherEntity=${this._weatherEntity}
          .outdoorUnavailableNotify=${this._outdoorUnavailableNotify}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-sensors>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:tune-variant"
        .heading=${S(`settings.control_title`,e)}
        .intro=${S(`settings.intro.control`,e)}
      >
        <rs-settings-control
          .hass=${this.hass}
          .controlMode=${this._controlMode}
          .comfortWeight=${this._comfortWeight}
          .outdoorCoolingMin=${this._outdoorCoolingMin}
          .outdoorHeatingMax=${this._outdoorHeatingMax}
          .predictionEnabled=${this._predictionEnabled}
          .scheduleOffAction=${this._scheduleOffAction}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-control>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:home-account"
        .heading=${S(`presence.title`,e)}
        .intro=${S(`settings.intro.presence`,e)}
      >
        <rs-settings-presence
          .hass=${this.hass}
          .presenceEnabled=${this._presenceEnabled}
          .presencePersons=${this._presencePersons}
          .presenceAwayAction=${this._presenceAwayAction}
          .presenceClearsOverride=${this._presenceClearsOverride}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-presence>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:airplane"
        .heading=${S(`vacation.title`,e)}
        .intro=${S(`settings.intro.vacation`,e)}
      >
        <rs-settings-vacation
          .hass=${this.hass}
          .vacationActive=${this._vacationActive}
          .vacationTemp=${this._vacationTemp}
          .vacationUntil=${this._vacationUntil}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-vacation>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:shield-refresh"
        .heading=${S(`valve_protection.title`,e)}
        .intro=${S(`settings.intro.valve`,e)}
      >
        <rs-settings-valve
          .hass=${this.hass}
          .valveProtectionEnabled=${this._valveProtectionEnabled}
          .valveProtectionInterval=${this._valveProtectionInterval}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-valve>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:heat-pump-outline"
        .heading=${S(`compressor.title`,e)}
        .intro=${S(`settings.intro.compressor`,e)}
      >
        <rs-settings-compressor
          .hass=${this.hass}
          .compressorGroups=${this._compressorGroups}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-compressor>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:water-alert"
        .heading=${S(`mold.title`,e)}
        .intro=${S(`settings.intro.mold`,e)}
      >
        <rs-settings-mold
          .hass=${this.hass}
          .moldDetectionEnabled=${this._moldDetectionEnabled}
          .moldHumidityThreshold=${this._moldHumidityThreshold}
          .moldSustainedMinutes=${this._moldSustainedMinutes}
          .moldPreventionEnabled=${this._moldPreventionEnabled}
          .moldPreventionIntensity=${this._moldPreventionIntensity}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-mold>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:bell-outline"
        .heading=${S(`notifications.title`,e)}
        .intro=${S(`settings.intro.notifications`,e)}
        .badge=${S(`badge.beta`,e)}
        .badgeHint=${S(`badge.beta_hint`,e)}
      >
        <rs-settings-notifications
          .hass=${this.hass}
          .notificationsEnabled=${this._moldNotificationsEnabled}
          .notificationTargets=${this._moldNotificationTargets}
          .notificationCooldown=${this._moldNotificationCooldown}
          .moldPreventionEnabled=${this._moldPreventionEnabled}
          .moldPreventionNotify=${this._moldPreventionNotify}
          @setting-changed=${this._onSettingChanged}
        ></rs-settings-notifications>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:brain"
        .heading=${S(`settings.learning_title`,e)}
        .intro=${S(`settings.intro.learning`,e)}
      >
        <rs-settings-learning
          .hass=${this.hass}
          .rooms=${this.rooms}
          .learningDisabledRooms=${this._learningDisabledRooms}
          .boostAppliedAt=${this._boostAppliedAt}
          .roomsLive=${Object.fromEntries(Object.entries(this.rooms).map(([e,t])=>[e,t.live??{}]))}
          @setting-changed=${this._onSettingChanged}
          @boost-applied=${this._onBoostApplied}
        ></rs-settings-learning>
      </rs-settings-panel>

      <rs-settings-panel
        icon="mdi:restart"
        .heading=${S(`settings.reset_title`,e)}
        .intro=${S(`settings.intro.reset`,e)}
      >
        <rs-settings-reset .hass=${this.hass} .rooms=${this.rooms}></rs-settings-reset>
      </rs-settings-panel>
    `}_onBoostApplied(e){let{area_id:t,n_observations:n}=e.detail;this._boostAppliedAt={...this._boostAppliedAt,[t]:n}}_onSettingChanged(e){let{key:t,value:n}=e.detail;this[`_${t}`]=n,this._autoSave()}_tsToDatetimeLocal(e){let t=new Date(e*1e3),n=e=>String(e).padStart(2,`0`);return`${t.getFullYear()}-${n(t.getMonth()+1)}-${n(t.getDate())}T${n(t.getHours())}:${n(t.getMinutes())}`}_autoSave(){this._saveDebounce&&clearTimeout(this._saveDebounce),this._saveDebounce=setTimeout(()=>this._doSave(),500)}async _doSave(){F(this,`saving`);try{await this.hass.callWS({type:`roommind/settings/save`,group_by_floor:this._groupByFloor,climate_control_active:this._climateControlActive,learning_disabled_rooms:this._learningDisabledRooms,outdoor_temp_sensor:this._outdoorTempSensor,outdoor_humidity_sensor:this._outdoorHumiditySensor,outdoor_cooling_min:this._outdoorCoolingMin,outdoor_heating_max:this._outdoorHeatingMax,control_mode:this._controlMode,comfort_weight:this._comfortWeight,weather_entity:this._weatherEntity,outdoor_unavailable_notify:this._outdoorUnavailableNotify,prediction_enabled:this._predictionEnabled,vacation_temp:this._vacationTemp,vacation_until:this._vacationActive?this._vacationUntil?new Date(this._vacationUntil).getTime()/1e3:cn:null,presence_enabled:this._presenceEnabled,presence_persons:this._presencePersons.filter(e=>e),presence_away_action:this._presenceAwayAction,presence_clears_override:this._presenceClearsOverride,schedule_off_action:this._scheduleOffAction,valve_protection_enabled:this._valveProtectionEnabled,valve_protection_interval_days:this._valveProtectionInterval,compressor_groups:this._compressorGroups.filter(e=>e.members.length>0),mold_detection_enabled:this._moldDetectionEnabled,mold_humidity_threshold:this._moldHumidityThreshold,mold_sustained_minutes:this._moldSustainedMinutes,mold_notification_cooldown:this._moldNotificationCooldown,mold_notifications_enabled:this._moldNotificationsEnabled,mold_notification_targets:this._moldNotificationTargets.filter(e=>e.entity_id),mold_prevention_enabled:this._moldPreventionEnabled,mold_prevention_intensity:this._moldPreventionIntensity,mold_prevention_notify_enabled:this._moldPreventionNotify,mold_prevention_notify_targets:this._moldPreventionNotify?this._moldNotificationTargets.filter(e=>e.entity_id):[]}),F(this,`saved`)}catch{F(this,`error`)}}static{this.styles=l`
    :host {
      display: flex;
      flex-direction: column;
      gap: 12px;
      padding: 0 16px;
    }

    .loading {
      padding: 80px 16px;
      text-align: center;
      color: var(--secondary-text-color);
    }
  `}};k([y({attribute:!1})],Y.prototype,`hass`,void 0),k([y({attribute:!1})],Y.prototype,`rooms`,void 0),k([b()],Y.prototype,`_groupByFloor`,void 0),k([b()],Y.prototype,`_climateControlActive`,void 0),k([b()],Y.prototype,`_learningDisabledRooms`,void 0),k([b()],Y.prototype,`_outdoorTempSensor`,void 0),k([b()],Y.prototype,`_outdoorHumiditySensor`,void 0),k([b()],Y.prototype,`_outdoorCoolingMin`,void 0),k([b()],Y.prototype,`_outdoorHeatingMax`,void 0),k([b()],Y.prototype,`_controlMode`,void 0),k([b()],Y.prototype,`_comfortWeight`,void 0),k([b()],Y.prototype,`_weatherEntity`,void 0),k([b()],Y.prototype,`_outdoorUnavailableNotify`,void 0),k([b()],Y.prototype,`_predictionEnabled`,void 0),k([b()],Y.prototype,`_vacationActive`,void 0),k([b()],Y.prototype,`_vacationTemp`,void 0),k([b()],Y.prototype,`_vacationUntil`,void 0),k([b()],Y.prototype,`_presenceEnabled`,void 0),k([b()],Y.prototype,`_presencePersons`,void 0),k([b()],Y.prototype,`_presenceAwayAction`,void 0),k([b()],Y.prototype,`_presenceClearsOverride`,void 0),k([b()],Y.prototype,`_scheduleOffAction`,void 0),k([b()],Y.prototype,`_valveProtectionEnabled`,void 0),k([b()],Y.prototype,`_valveProtectionInterval`,void 0),k([b()],Y.prototype,`_moldDetectionEnabled`,void 0),k([b()],Y.prototype,`_moldHumidityThreshold`,void 0),k([b()],Y.prototype,`_moldSustainedMinutes`,void 0),k([b()],Y.prototype,`_moldNotificationCooldown`,void 0),k([b()],Y.prototype,`_moldNotificationsEnabled`,void 0),k([b()],Y.prototype,`_moldNotificationTargets`,void 0),k([b()],Y.prototype,`_moldPreventionEnabled`,void 0),k([b()],Y.prototype,`_moldPreventionIntensity`,void 0),k([b()],Y.prototype,`_moldPreventionNotify`,void 0),k([b()],Y.prototype,`_compressorGroups`,void 0),k([b()],Y.prototype,`_boostAppliedAt`,void 0),k([b()],Y.prototype,`_loaded`,void 0),Y=k([v(`rs-settings`)],Y);function wn(e){let t=[...e.history,...e.detail];return t.length===0?null:[`timestamp,datetime,room_temp,outdoor_temp,target_temp,mode,predicted_temp,window_open,heating_power,solar_irradiance,blind_position,cover_reason,device_setpoint`,...t.map(e=>{let t=new Date(e.ts*1e3).toISOString(),n=e.room_temp??``,r=e.outdoor_temp??``,i=e.target_temp??``,a=e.predicted_temp??``,o=e.heating_power??``,s=e.solar_irradiance??``,c=e.blind_position??``,l=e.cover_reason??``,u=e.device_setpoint??``;return`${e.ts},${t},${n},${r},${i},${e.mode},${a},${e.window_open},${o},${s},${c},${l},${u}`})].join(`
`)}function Tn(e,t,n){let r=new Blob([e],{type:`${n};charset=utf-8`}),i=URL.createObjectURL(r),a=document.createElement(`a`);a.href=i,a.download=t,a.click(),URL.revokeObjectURL(i)}function En(e,t,n,r,i,a,o){let s=e?.areas?.[n],c=(t[n]?.display_name||s?.name||n).replace(/\s+/g,`_`).toLowerCase();return a?`roommind_${a}_${c}.${o}`:`roommind_${c}_${new Date(r).toISOString().slice(0,10)}_${new Date(i).toISOString().slice(0,10)}.${o}`}function Dn(e){return navigator.clipboard?.writeText?(navigator.clipboard.writeText(e).catch(()=>{On(e)}),!0):On(e)}function On(e){let t=document.createElement(`textarea`);t.value=e,t.style.position=`fixed`,t.style.opacity=`0`,document.body.appendChild(t),t.select();let n=!1;try{n=document.execCommand(`copy`)}catch(e){console.debug(`[RoomMind] clipboard fallback:`,e)}return document.body.removeChild(t),n}_(),x(),A();var X=class extends g{constructor(...e){super(...e),this.rooms={},this.selectedRoom=``,this.rangeStart=0,this.rangeEnd=0,this.activeQuick=`24h`,this.data=null,this.language=`en`,this._openDropdown=null,this._diagLoading=!1,this._boundCloseDropdowns=this._closeDropdowns.bind(this)}connectedCallback(){super.connectedCallback(),document.addEventListener(`click`,this._boundCloseDropdowns)}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener(`click`,this._boundCloseDropdowns)}updated(e){(e.has(`rooms`)||e.has(`selectedRoom`))&&this.selectedRoom&&this.updateComplete.then(()=>{let e=this.renderRoot?.querySelector(`ha-select`);e&&e.value!==this.selectedRoom&&(e.value=this.selectedRoom)})}render(){let e=this.language,t=this._getConfiguredRooms();return m`
      ${this._renderRoomSelector(t,e)}
      ${this.selectedRoom?this._renderRangeButtons(e):h}
    `}_getConfiguredRooms(){return Object.entries(this.rooms).map(([e,t])=>{let n=this.hass?.areas?.[e];return{area_id:e,name:t.display_name||n?.name||e}})}_renderRoomSelector(e,t){return m`
      <div class="selector-row">
        <ha-select
          .value=${this.selectedRoom}
          .label=${S(`analytics.select_room`,t)}
          .options=${e.map(e=>({value:e.area_id,label:e.name}))}
          naturalMenuWidth
          fixedMenuPosition
          @selected=${this._onRoomSelected}
          @closed=${e=>e.stopPropagation()}
        >
          ${e.map(e=>m` <ha-list-item value=${e.area_id}>${e.name}</ha-list-item> `)}
        </ha-select>
      </div>
    `}_renderRangeButtons(e){let t=[{key:`24h`,label:S(`analytics.range_1d`,e),days:1},{key:`2d`,label:S(`analytics.range_2d`,e),days:2},{key:`7d`,label:S(`analytics.range_7d`,e),days:7},{key:`30d`,label:S(`analytics.range_30d`,e),days:30}],n=this.data&&(this.data.history.length>0||this.data.detail.length>0),r=e=>new Date(e).toLocaleString(this.hass.language,{month:`2-digit`,day:`2-digit`,hour:`2-digit`,minute:`2-digit`});return m`
      <div class="range-row">
        <div class="range-controls">
          <div class="range-bar">
            ${t.map(e=>m`
                <button
                  class="range-chip"
                  ?active=${this.activeQuick===e.key}
                  @click=${()=>this._onQuickRange(e.key,e.days)}
                >
                  ${e.label}
                </button>
              `)}
            <div class="range-chip picker-chip ${this.activeQuick===null?`picker-active`:``}">
              <ha-date-range-picker
                .hass=${this.hass}
                .startDate=${new Date(this.rangeStart)}
                .endDate=${new Date(this.rangeEnd)}
                .ranges=${!1}
                time-picker
                auto-apply
                minimal
                @value-changed=${this._onDateRangeChanged}
              ></ha-date-range-picker>
            </div>
          </div>
          <span class="date-label ${this.activeQuick===null?`custom-active`:``}"
            >${r(this.rangeStart)} – ${r(this.rangeEnd)}</span
          >
        </div>
        <div class="action-buttons">
          <div class="export-split">
            <button
              class="export-btn"
              ?disabled=${!n}
              @click=${e=>{e.stopPropagation(),this._toggleDropdown(`csv`)}}
            >
              <ha-icon icon="mdi:download"></ha-icon>
              ${S(`analytics.export`,e)}
              <ha-icon class="arrow-icon" icon="mdi:chevron-down"></ha-icon>
            </button>
            ${this._openDropdown===`csv`?m`<div class="export-dropdown" @click=${e=>e.stopPropagation()}>
                  <button @click=${this._exportCsv}>
                    <ha-icon icon="mdi:download"></ha-icon>
                    ${S(`analytics.export_download`,e)}
                  </button>
                  <button @click=${this._copyCsvToClipboard}>
                    <ha-icon icon="mdi:content-copy"></ha-icon>
                    ${S(`analytics.export_clipboard`,e)}
                  </button>
                </div>`:h}
          </div>
          <div class="export-split">
            <button
              class="export-btn"
              ?disabled=${this._diagLoading}
              @click=${e=>{e.stopPropagation(),this._toggleDropdown(`diag`)}}
            >
              <ha-icon icon=${this._diagLoading?`mdi:loading`:`mdi:bug-outline`}></ha-icon>
              ${S(`analytics.copy_diagnostics`,e)}
              <ha-icon class="arrow-icon" icon="mdi:chevron-down"></ha-icon>
            </button>
            ${this._openDropdown===`diag`?m`<div class="export-dropdown" @click=${e=>e.stopPropagation()}>
                  <button @click=${this._exportDiagnostics}>
                    <ha-icon icon="mdi:download"></ha-icon>
                    ${S(`analytics.export_download`,e)}
                  </button>
                  <button @click=${this._copyDiagnosticsToClipboard}>
                    <ha-icon icon="mdi:content-copy"></ha-icon>
                    ${S(`analytics.export_clipboard`,e)}
                  </button>
                </div>`:h}
          </div>
        </div>
      </div>
    `}_onRoomSelected(e){let t=P(e);t&&t!==this.selectedRoom&&this.dispatchEvent(new CustomEvent(`room-selected`,{detail:{areaId:t},bubbles:!0,composed:!0}))}_onQuickRange(e,t){let n=new Date,r=new Date(n);r.setDate(r.getDate()-(t-1)),r.setHours(0,0,0,0),this.dispatchEvent(new CustomEvent(`range-changed`,{detail:{activeQuick:e,rangeStart:r.getTime(),rangeEnd:n.getTime(),chartAnchor:n.getTime()},bubbles:!0,composed:!0}))}_onDateRangeChanged(e){let{startDate:t,endDate:n}=e.detail.value;!t||!n||this.dispatchEvent(new CustomEvent(`range-changed`,{detail:{activeQuick:null,rangeStart:t.getTime(),rangeEnd:n.getTime(),chartAnchor:n.getTime()},bubbles:!0,composed:!0}))}_exportCsv(){if(!this.data)return;let e=wn(this.data);e&&(Tn(e,En(this.hass,this.rooms,this.selectedRoom,this.rangeStart,this.rangeEnd,``,`csv`),`text/csv`),this._openDropdown=null)}async _exportDiagnostics(){if(!this._diagLoading){this._diagLoading=!0,this._openDropdown=null;try{let e=await this.hass.callWS({type:`roommind/diagnostics/get`});Tn(JSON.stringify(e,null,2),`roommind_diagnostics.json`,`application/json`)}catch(e){console.warn(`[RoomMind] diagnostics export failed:`,e)}finally{this._diagLoading=!1}}}_copyCsvToClipboard(){if(!this.data)return;let e=wn(this.data);e&&(Dn(e),this._openDropdown=null)}async _copyDiagnosticsToClipboard(){if(!this._diagLoading){this._diagLoading=!0,this._openDropdown=null;try{let e=await this.hass.callWS({type:`roommind/diagnostics/get`});Dn(JSON.stringify(e,null,2))}catch(e){console.warn(`[RoomMind] diagnostics clipboard failed:`,e)}finally{this._diagLoading=!1}}}_toggleDropdown(e){this._openDropdown=this._openDropdown===e?null:e}_closeDropdowns(){this._openDropdown&&=null}static{this.styles=[I,l`
      :host {
        display: block;
      }

      .selector-row {
        margin-bottom: 16px;
      }

      .selector-row ha-select {
        width: 100%;
      }

      .range-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 16px;
        gap: 12px;
      }

      .range-controls {
        display: flex;
        align-items: center;
        gap: 8px;
        position: relative;
      }

      .range-bar {
        display: inline-flex;
        border-radius: 12px;
        border: 1px solid var(--divider-color);
        background: var(--card-background-color);
      }

      .range-bar > :first-child {
        border-radius: 12px 0 0 12px;
      }

      .range-bar > :last-child {
        border-radius: 0 12px 12px 0;
      }

      .range-chip {
        padding: 7px 14px;
        border: none;
        border-right: 1px solid var(--divider-color);
        background: transparent;
        color: var(--secondary-text-color);
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        transition:
          background 0.15s ease,
          color 0.15s ease;
        font-family: inherit;
        white-space: nowrap;
      }

      .range-chip:last-child {
        border-right: none;
      }

      .range-chip:hover:not([active]) {
        background: rgba(var(--rgb-primary-color, 3, 169, 244), 0.08);
        color: var(--primary-text-color);
      }

      .range-chip[active] {
        background: var(--primary-color);
        color: var(--text-primary-color, #fff);
      }

      .picker-chip {
        display: flex;
        align-items: center;
        padding: 0;
        cursor: pointer;
      }

      .picker-chip ha-date-range-picker {
        --mdc-icon-size: 18px;
        --mdc-icon-button-size: 32px;
      }

      .picker-chip.picker-active {
        background: var(--primary-color);
        color: var(--text-primary-color, #fff);
      }

      .date-label {
        font-size: 12px;
        color: var(--secondary-text-color);
        white-space: nowrap;
      }

      .date-label.custom-active {
        color: var(--primary-color);
      }

      .action-buttons {
        display: flex;
        gap: 8px;
      }

      .export-split {
        position: relative;
        display: inline-flex;
      }

      .export-btn {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 7px 14px;
        border: 1px solid var(--divider-color);
        border-radius: 12px;
        background: var(--card-background-color);
        color: var(--secondary-text-color);
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.15s ease;
        font-family: inherit;
        white-space: nowrap;
        --mdc-icon-size: 14px;
      }

      .export-btn:hover {
        color: var(--primary-text-color);
        border-color: var(--primary-color);
      }

      .export-btn[disabled] {
        opacity: 0.4;
        cursor: default;
      }

      .arrow-icon {
        --mdc-icon-size: 14px;
        margin-left: 2px;
        margin-right: -4px;
      }

      .export-dropdown {
        position: absolute;
        top: 100%;
        right: 0;
        margin-top: 4px;
        min-width: 100%;
        background: var(--card-background-color);
        border: 1px solid var(--divider-color);
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        z-index: 10;
        overflow: hidden;
      }

      .export-dropdown button {
        display: flex;
        align-items: center;
        gap: 8px;
        width: 100%;
        padding: 10px 14px;
        border: none;
        background: transparent;
        color: var(--primary-text-color);
        font-size: 12px;
        font-family: inherit;
        cursor: pointer;
        white-space: nowrap;
        --mdc-icon-size: 14px;
      }

      .export-dropdown button:hover {
        background: rgba(var(--rgb-primary-color, 3, 169, 244), 0.08);
      }

      .export-dropdown button + button {
        border-top: 1px solid var(--divider-color);
      }

      @media (max-width: 600px) {
        .range-row {
          flex-wrap: wrap;
        }
        .range-controls {
          flex-wrap: wrap;
        }
        .range-chip {
          padding: 6px 10px;
          font-size: 11px;
        }
      }
    `]}};k([y({attribute:!1})],X.prototype,`hass`,void 0),k([y({attribute:!1})],X.prototype,`rooms`,void 0),k([y({type:String})],X.prototype,`selectedRoom`,void 0),k([y({type:Number})],X.prototype,`rangeStart`,void 0),k([y({type:Number})],X.prototype,`rangeEnd`,void 0),k([y({type:String})],X.prototype,`activeQuick`,void 0),k([y({attribute:!1})],X.prototype,`data`,void 0),k([y({type:String})],X.prototype,`language`,void 0),k([b()],X.prototype,`_openDropdown`,void 0),k([b()],X.prototype,`_diagLoading`,void 0),X=k([v(`rs-analytics-toolbar`)],X),_();var kn=l`
  .info-icon {
    --mdc-icon-size: 16px;
    color: var(--secondary-text-color);
    opacity: 0.3;
    cursor: pointer;
    flex-shrink: 0;
    transition:
      opacity 0.15s,
      color 0.15s;
  }

  .info-icon:hover {
    opacity: 0.7;
  }

  .info-icon.info-active {
    opacity: 1;
    color: var(--primary-color);
  }

  .info-panel {
    padding: 12px;
    border-radius: 8px;
    background: var(--secondary-background-color, rgba(128, 128, 128, 0.06));
    font-size: 13px;
    line-height: 1.6;
    color: var(--secondary-text-color);
  }

  .info-panel strong {
    display: block;
    margin-bottom: 4px;
    color: var(--primary-text-color);
    font-size: 13px;
  }

  .info-panel .yaml-block {
    background: var(--primary-background-color, #f5f5f5);
    border: 1px solid var(--divider-color, #e0e0e0);
    border-radius: 6px;
    padding: 10px 14px;
    margin: 8px 0;
    font-family: var(--code-font-family, monospace);
    font-size: 12px;
    line-height: 1.6;
    white-space: pre;
    overflow-x: auto;
    color: var(--primary-text-color);
  }
  .info-panel .yaml-key {
    color: #0550ae;
  }
  .info-panel .yaml-value {
    color: #0a3069;
  }
`,An=3*36e5;function jn(e,t){let{hass:n,language:r,chartAnchor:i,forecast:a,isOutdoor:o}=t,s=e=>w(e,n),c=[],l=[],u=[],d=[];for(let t of e){let e=t.ts*1e3;t.room_temp!==null&&c.push([e,s(t.room_temp)]),!o&&t.target_temp!==null&&l.push([e,s(t.target_temp)]),!o&&t.predicted_temp!==null&&u.push([e,s(t.predicted_temp)]),t.outdoor_temp!==null&&d.push([e,s(t.outdoor_temp)])}for(let e of a??[]){let t=e.ts*1e3;!o&&e.target_temp!==null&&l.push([t,s(e.target_temp)]),!o&&e.predicted_temp!==null&&u.push([t,s(e.predicted_temp)])}let f=[{id:`room_temp`,type:`line`,name:S(`analytics.temperature`,r),color:`rgb(255, 152, 0)`,data:c,showSymbol:!1,smooth:!0,lineStyle:{width:2},yAxisIndex:0}];o||f.push({id:`target_temp`,type:`line`,name:S(`analytics.target`,r),color:`rgb(76, 175, 80)`,data:l,showSymbol:!1,smooth:!1,lineStyle:{width:2,type:`dashed`},yAxisIndex:0}),u.length>0&&f.push({id:`predicted_temp`,type:`line`,name:S(`analytics.prediction`,r),color:`rgb(33, 150, 243)`,data:u,showSymbol:!1,smooth:!0,lineStyle:{width:2,type:`dotted`},yAxisIndex:0}),d.length>0&&f.push({id:`outdoor_temp`,type:`line`,name:S(`analytics.outdoor`,r),color:`rgb(158, 158, 158)`,data:d,showSymbol:!1,smooth:!0,lineStyle:{width:1},yAxisIndex:0});let p=[],ee=[],te=[],ne=!1,re=!1,ie=!1;for(let t of e){let e=t.ts*1e3;t.mode===`heating`?(p.push([e,999]),ne=!0):p.push([e,null]),t.mode===`cooling`?(ee.push([e,999]),re=!0):ee.push([e,null]),t.window_open?(te.push([e,999]),ie=!0):te.push([e,null])}return ne&&f.push({id:`heating_events`,type:`line`,name:S(`analytics.heating_period`,r),color:`rgb(244, 67, 54)`,data:p,showSymbol:!1,lineStyle:{width:0},areaStyle:{color:`rgba(244, 67, 54, 0.08)`,origin:`start`},tooltip:{show:!1},yAxisIndex:0,z:-1,connectNulls:!1}),re&&f.push({id:`cooling_events`,type:`line`,name:S(`analytics.cooling_period`,r),color:`rgb(63, 81, 181)`,data:ee,showSymbol:!1,lineStyle:{width:0},areaStyle:{color:`rgba(63, 81, 181, 0.08)`,origin:`start`},tooltip:{show:!1},yAxisIndex:0,z:-1,connectNulls:!1}),ie&&f.push({id:`window_events`,type:`line`,name:S(`analytics.window_open_period`,r),color:`rgb(0, 150, 136)`,data:te,showSymbol:!1,lineStyle:{width:0},areaStyle:{color:`rgba(0, 150, 136, 0.1)`,origin:`start`},tooltip:{show:!1},yAxisIndex:0,z:-1,connectNulls:!1}),f.push({id:`now_marker`,type:`line`,name:``,color:`rgba(255,255,255,0.3)`,data:[[i,-999],[i,999]],showSymbol:!1,lineStyle:{width:1,type:`dashed`},yAxisIndex:0,tooltip:{show:!1},z:-2}),f}function Mn(e,t,n){let{hass:r,language:i,chartAnchor:a,rangeStart:o,rangeEnd:s}=n,c=C(r),l={type:`value`,name:c};if(e.length>0){let t=1/0,n=-1/0;for(let r of e)r<t&&(t=r),r>n&&(n=r);let r=n-t,i=Math.max(r*.1,.5);l.min=Math.floor((t-i)*2)/2,l.max=Math.ceil((n+i)*2)/2}return{xAxis:{type:`time`,min:o,max:Math.abs(s-Date.now())<36e5?a+An:s},yAxis:l,dataZoom:[{type:`inside`,xAxisIndex:0,filterMode:`none`}],tooltip:{trigger:`axis`,axisPointer:{snap:!1},valueFormatter:e=>e.toFixed(1)+`\xA0`+c,formatter:e=>{if(!Array.isArray(e)||e.length===0)return``;let n=`<div style="font-weight:500;margin-bottom:4px">${new Date(e[0].value[0]).toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`})}</div>`,a=null,o=null;for(let t of e){if(t.seriesId?.endsWith(`_events`))continue;let e=t.value?.[1];e!=null&&(n+=`<div>${t.color?`<span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${t.color};margin-right:6px"></span>`:``}${t.seriesName}: ${e.toFixed(1)}\u00A0${c}</div>`,t.seriesId===`room_temp`&&(a=e),t.seriesId===`predicted_temp`&&(o=e))}if(a!==null&&o!==null){let e=a-o;n+=`<div style="border-top:1px solid rgba(128,128,128,0.3);margin-top:4px;padding-top:4px">Delta: ${e>=0?`+`:``}${e.toFixed(2)}\u00A0${c}</div>`}if(t.length>0){let a=e[0].value[0]/1e3,o=null,s=1/0;for(let e of t){let t=Math.abs(e.ts-a);t<s&&(s=t,o=e)}if(o){let e=[];if(o.mode===`heating`){let t=o.heating_power;t!=null&&t>0&&t<100?e.push(`${S(`analytics.heating_period`,i)} ${t}%`):e.push(S(`analytics.heating_period`,i)),o.device_setpoint!=null&&e.push(`TRV ${E(o.device_setpoint,r)}\u00A0${c}`)}else o.mode===`cooling`&&(e.push(S(`analytics.cooling_period`,i)),o.device_setpoint!=null&&e.push(`AC ${E(o.device_setpoint,r)}\u00A0${c}`));o.window_open&&e.push(S(`analytics.window_open_period`,i)),e.length>0&&(n+=`<div style="border-top:1px solid rgba(128,128,128,0.3);margin-top:4px;padding-top:4px;color:rgba(255,255,255,0.7)">${e.join(` · `)}</div>`),o.blind_position!=null&&(n+=`<div style="color:rgba(255,255,255,0.7)">${S(`analytics.blind_position`,i)} ${100-o.blind_position}%</div>`)}}return n}},grid:{top:15,left:10,right:10,bottom:5,containLabel:!0}}}_(),x(),A();var Z=class extends g{constructor(...e){super(...e),this.data=null,this.rangeStart=0,this.rangeEnd=0,this.chartAnchor=0,this.language=`en`,this.isOutdoor=!1,this._hiddenSeries=new Set([`outdoor_temp`]),this._chartInfoExpanded=!1}render(){let e=this.language,t=this.data?[...this.data.history,...this.data.detail]:[],n=[...t,...this.data?.forecast??[]],r={hass:this.hass,language:e,chartAnchor:this.chartAnchor,rangeStart:this.rangeStart,rangeEnd:this.rangeEnd,forecast:this.data?.forecast,isOutdoor:this.isOutdoor},i=t.length>0?jn(t,r):[],a=[],o=i.map(e=>{let t=e.id,n=e.lineStyle||{},r=t.endsWith(`_events`);if(this._hiddenSeries.has(t)){let t={...e,lineStyle:{...n,width:0,opacity:0}};return e.areaStyle&&(t.areaStyle={...e.areaStyle,opacity:0}),t}if(!r&&t!==`now_marker`)for(let t of e.data)t&&t[1]!=null&&a.push(t[1]);let i={...e,lineStyle:{...n,opacity:1}};return e.areaStyle&&(i.areaStyle={...e.areaStyle,opacity:1}),i}),s=Mn(a,n,r);return m`
      <ha-card>
        <div class="card-header">
          <span>${S(`analytics.temperature`,e)}</span>
          <ha-icon
            class="info-icon chart-info-toggle ${this._chartInfoExpanded?`info-active`:``}"
            icon="mdi:information-outline"
            @click=${()=>{this._chartInfoExpanded=!this._chartInfoExpanded}}
          ></ha-icon>
        </div>
        ${this._chartInfoExpanded?m`<div class="chart-info-panel">
              ${this._renderMarkdown(S(`analytics.chart_info_body`,e))}
            </div>`:h}
        ${t.length>0?m`
              <ha-chart-base
                .hass=${this.hass}
                .data=${o}
                .options=${s}
                .height=${`300px`}
                style="height: 300px"
              ></ha-chart-base>
              ${this._renderSeriesLegend(i)}
            `:m`<div class="chart-empty">
              <ha-icon icon="mdi:chart-line"></ha-icon>
              <span>${S(`analytics.no_data`,e)}</span>
            </div>`}
      </ha-card>
    `}_renderSeriesLegend(e){return m`
      <div class="series-legend">
        ${e.filter(e=>e.id!==`now_marker`).map(e=>{let t=e.id;return m`
            <button
              class="legend-item ${this._hiddenSeries.has(t)?`legend-hidden`:``}"
              @click=${()=>this._toggleSeries(t)}
            >
              <span class="legend-dot" style="background: ${e.color}"></span>
              ${e.name}
            </button>
          `})}
      </div>
    `}_renderMarkdown(e){return e.split(`

`).map(e=>m`<p>
          ${e.split(/(\*\*.*?\*\*)/).map(e=>e.startsWith(`**`)&&e.endsWith(`**`)?m`<strong>${e.slice(2,-2)}</strong>`:e)}
        </p>`)}_toggleSeries(e){let t=new Set(this._hiddenSeries);t.has(e)?t.delete(e):t.add(e),this._hiddenSeries=t}static{this.styles=[kn,l`
      :host {
        display: block;
      }

      ha-card {
        margin-bottom: 16px;
      }

      .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 16px 0;
        font-size: 16px;
        font-weight: 500;
      }

      .chart-info-toggle {
        --mdc-icon-size: 20px;
      }

      .chart-info-panel {
        margin: 8px 16px 4px;
        padding: 12px 14px;
        border-radius: 8px;
        background: var(--secondary-background-color, rgba(128, 128, 128, 0.06));
        font-size: 13px;
        line-height: 1.6;
        color: var(--secondary-text-color);
      }

      .chart-info-panel p {
        margin: 0 0 8px;
      }

      .chart-info-panel p:last-child {
        margin-bottom: 0;
      }

      .chart-info-panel strong {
        color: var(--primary-text-color);
      }

      .series-legend {
        display: flex;
        justify-content: center;
        gap: 6px;
        padding: 8px 16px 12px;
        flex-wrap: wrap;
      }

      .legend-item {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 4px 10px;
        border: none;
        border-radius: 12px;
        background: transparent;
        color: var(--primary-text-color);
        font-size: 12px;
        font-family: inherit;
        cursor: pointer;
        transition: opacity 0.2s;
      }

      .legend-item:hover {
        background: var(--secondary-background-color, rgba(128, 128, 128, 0.1));
      }

      .legend-item.legend-hidden {
        opacity: 0.35;
      }

      .legend-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        flex-shrink: 0;
      }

      .chart-empty {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 200px;
        gap: 8px;
        color: var(--secondary-text-color);
        opacity: 0.5;
        --mdc-icon-size: 40px;
        font-size: 13px;
      }
    `]}};k([y({attribute:!1})],Z.prototype,`hass`,void 0),k([y({attribute:!1})],Z.prototype,`data`,void 0),k([y({type:Number})],Z.prototype,`rangeStart`,void 0),k([y({type:Number})],Z.prototype,`rangeEnd`,void 0),k([y({type:Number})],Z.prototype,`chartAnchor`,void 0),k([y({type:String})],Z.prototype,`language`,void 0),k([y({type:Boolean})],Z.prototype,`isOutdoor`,void 0),k([b()],Z.prototype,`_hiddenSeries`,void 0),k([b()],Z.prototype,`_chartInfoExpanded`,void 0),Z=k([v(`rs-analytics-chart`)],Z),_(),x(),A();var Nn=class extends g{constructor(...e){super(...e),this.data=null,this.language=`en`,this._expandedStat=null}render(){let e=this.language,t=!!this.data?.model?.model,n=this.data?.model,r=n?.model,i=n?.confidence??0,a=n?.n_samples??0,o=n?.n_heating??0,s=n?.n_cooling??0,c=n?.applicable_modes??[],l=n?.prediction_std_idle,u=n?.prediction_std_heating,d=n?.mpc_active??!1,f=Math.round(i*100),p=new Set(c),ee=p.has(`heating`),te=p.has(`cooling`),ne=o>=10,re=s>=10,ie=a-o-s>=10,ae=n?.n_observations??a,oe=[],se=(t,n,r,i,a)=>{oe.push({id:t,labelKey:r,infoKey:a});let o=this._expandedStat===t;return m`
        <div class="model-stat ${o?`active`:``}" @click=${()=>this._toggleStat(t)}>
          <div class="stat-content">
            <span class="model-value ${n===`—`?`pending`:``}">${n}</span>
            <span class="model-label">${S(r,e)}${i?` (${i})`:``}</span>
          </div>
          <ha-icon
            class="info-icon ${o?`info-active`:``}"
            icon="mdi:information-outline"
          ></ha-icon>
        </div>
      `};return m`
      <ha-card>
        <div class="card-header">
          <span>${S(`analytics.model_status`,e)}</span>
        </div>
        <div class="card-content">
          <div class="confidence-hero">
            <div class="confidence-top">
              <div class="confidence-main">
                <span class="confidence-value">${t?f+`%`:`0%`}</span>
                <span class="confidence-label">
                  ${S(`analytics.confidence`,e)}
                  <ha-icon
                    class="info-icon ${this._expandedStat===`confidence`?`info-active`:``}"
                    icon="mdi:information-outline"
                    @click=${()=>this._toggleStat(`confidence`)}
                  ></ha-icon>
                </span>
              </div>
              <div class="confidence-meta">
                <span class="meta-value">${t?ae:0}</span>
                <span class="meta-label">
                  ${S(`analytics.data_points`,e)}
                  <ha-icon
                    class="info-icon ${this._expandedStat===`data_points`?`info-active`:``}"
                    icon="mdi:information-outline"
                    @click=${()=>this._toggleStat(`data_points`)}
                  ></ha-icon>
                </span>
              </div>
            </div>
            <div class="confidence-bar">
              <div class="confidence-fill" style="width: ${t?f:0}%"></div>
            </div>
            <div class="control-mode-badge ${d?`mpc`:`bangbang`}">
              <ha-icon icon=${d?`mdi:brain`:`mdi:school-outline`}></ha-icon>
              ${S(d?`analytics.control_mode_mpc`:`analytics.control_mode_bangbang`,e)}
            </div>
            ${this._expandedStat===`confidence`?m`<div class="info-panel stat-info-panel">
                  <strong>${S(`analytics.confidence`,e)}</strong>
                  ${S(`analytics.info.confidence`,e)}
                </div>`:h}
            ${this._expandedStat===`data_points`?m`<div class="info-panel stat-info-panel">
                  <strong>${S(`analytics.data_points`,e)}</strong>
                  ${S(`analytics.info.data_points`,e)}
                </div>`:h}
          </div>

          <div class="model-grid">
            ${se(`time_constant`,ie&&r&&r.U>0?(1/r.U).toFixed(1)+`h`:`—`,`analytics.time_constant`,``,`analytics.info.time_constant`)}
            ${ee?se(`heating_rate`,ne&&r?T(r.Q_heat,this.hass).toFixed(1)+C(this.hass)+`/h`:`—`,`analytics.heating_rate`,``,`analytics.info.heating_rate`):h}
            ${te?se(`cooling_rate`,re&&r?T(r.Q_cool,this.hass).toFixed(1)+C(this.hass)+`/h`:`—`,`analytics.cooling_rate`,``,`analytics.info.cooling_rate`):h}
            ${r&&r.Q_solar>.1?se(`solar_gain`,T(r.Q_solar,this.hass).toFixed(1)+C(this.hass)+`/h`,`analytics.solar_gain`,``,`analytics.info.solar_gain`):h}
            ${r&&n?.has_occupancy_sensors?se(`occupancy_gain`,T(r.Q_occupancy,this.hass).toFixed(1)+C(this.hass)+`/h`,`analytics.occupancy_gain`,``,`analytics.info.occupancy_gain`):h}
            ${se(`accuracy_idle`,ie&&l!=null?`±`+T(l,this.hass).toFixed(2)+C(this.hass):`—`,`analytics.accuracy_idle`,``,`analytics.info.accuracy_idle`)}
            ${ee?se(`accuracy_heating`,ne&&u!=null?`±`+T(u,this.hass).toFixed(2)+C(this.hass):`—`,`analytics.accuracy_heating`,``,`analytics.info.accuracy_heating`):h}
          </div>
          ${this._expandedStat&&oe.find(e=>e.id===this._expandedStat)?m`<div class="info-panel stat-info-panel">
                <strong
                  >${S(oe.find(e=>e.id===this._expandedStat).labelKey,e)}</strong
                >
                ${S(oe.find(e=>e.id===this._expandedStat).infoKey,e)}
              </div>`:h}
        </div>
      </ha-card>
    `}_toggleStat(e){this._expandedStat=this._expandedStat===e?null:e}static{this.styles=[kn,l`
      :host {
        display: block;
      }

      ha-card {
        margin-bottom: 16px;
      }

      .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 16px 0;
        font-size: 16px;
        font-weight: 500;
      }

      .card-content {
        padding: 16px;
      }

      .confidence-hero {
        margin-bottom: 16px;
      }

      .confidence-top {
        display: flex;
        justify-content: space-between;
        align-items: flex-end;
        margin-bottom: 8px;
      }

      .confidence-main {
        display: flex;
        align-items: baseline;
        gap: 8px;
      }

      .confidence-value {
        font-size: 28px;
        font-weight: 600;
        color: var(--primary-text-color);
      }

      .confidence-label {
        font-size: 13px;
        color: var(--secondary-text-color);
      }

      .confidence-meta {
        display: flex;
        align-items: baseline;
        gap: 6px;
      }

      .meta-value {
        font-size: 16px;
        font-weight: 500;
        color: var(--primary-text-color);
      }

      .meta-label {
        font-size: 12px;
        color: var(--secondary-text-color);
      }

      .control-mode-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        margin-top: 8px;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 500;
        --mdc-icon-size: 14px;
      }

      .control-mode-badge.mpc {
        background: rgba(76, 175, 80, 0.12);
        color: var(--success-color, #4caf50);
      }

      .control-mode-badge.bangbang {
        background: rgba(158, 158, 158, 0.12);
        color: var(--secondary-text-color);
      }

      .confidence-bar {
        height: 4px;
        border-radius: 2px;
        background: var(--divider-color);
        overflow: hidden;
      }

      .confidence-fill {
        height: 100%;
        border-radius: 2px;
        background: var(--primary-color);
        transition: width 0.6s ease;
      }

      .model-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
        gap: 12px;
      }

      .model-stat {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 12px;
        border-radius: 8px;
        border: 1px solid var(--divider-color);
        cursor: pointer;
        transition: border-color 0.2s;
      }

      .model-stat.active {
        border-color: var(--primary-color);
      }

      .stat-content {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }

      .model-value {
        font-size: 18px;
        font-weight: 500;
        color: var(--primary-text-color);
      }

      .model-value.pending {
        opacity: 0.2;
      }

      .model-label {
        font-size: 12px;
        color: var(--secondary-text-color);
      }

      .info-panel.stat-info-panel {
        margin-top: 12px;
      }

      @media (max-width: 600px) {
        .model-grid {
          grid-template-columns: repeat(2, 1fr);
          gap: 8px;
        }
      }
    `]}};k([y({attribute:!1})],Nn.prototype,`hass`,void 0),k([y({attribute:!1})],Nn.prototype,`data`,void 0),k([y({type:String})],Nn.prototype,`language`,void 0),k([b()],Nn.prototype,`_expandedStat`,void 0),Nn=k([v(`rs-analytics-model`)],Nn),_(),x(),A();var Q=class extends g{constructor(...e){super(...e),this.rooms={},this.initialRoom=``,this.controlMode=`bangbang`,this._selectedRoom=``,this._rangeStart=new Date(new Date().setHours(0,0,0,0)).getTime(),this._rangeEnd=Date.now(),this._data=null,this._chartAnchor=Date.now(),this._loading=!1,this._activeQuick=`24h`}connectedCallback(){super.connectedCallback(),this._refreshInterval=setInterval(()=>this._silentRefresh(),6e4)}disconnectedCallback(){super.disconnectedCallback(),this._refreshInterval&&=(clearInterval(this._refreshInterval),void 0)}willUpdate(e){e.has(`initialRoom`)&&this.initialRoom&&(this._selectedRoom=this.initialRoom);let t=!1;if(e.has(`rooms`)&&!this._selectedRoom){let e=Object.keys(this.rooms);e.length>0&&(this._selectedRoom=e[0],t=!0,this.dispatchEvent(new CustomEvent(`room-selected`,{detail:{areaId:e[0]},bubbles:!0,composed:!0})))}(t||e.has(`_selectedRoom`)||e.has(`_rangeStart`)||e.has(`_rangeEnd`))&&this._selectedRoom&&this._fetchData()}render(){let e=this.hass.language;return m`
      <rs-analytics-toolbar
        .hass=${this.hass}
        .rooms=${this.rooms}
        .selectedRoom=${this._selectedRoom}
        .rangeStart=${this._rangeStart}
        .rangeEnd=${this._rangeEnd}
        .activeQuick=${this._activeQuick}
        .data=${this._data}
        .language=${e}
        @room-selected=${this._onRoomSelected}
        @range-changed=${this._onRangeChanged}
      ></rs-analytics-toolbar>
      ${this._selectedRoom?this._loading?m`<div class="loading">${S(`panel.loading`,e)}</div>`:m`
              <rs-analytics-chart
                .hass=${this.hass}
                .data=${this._data}
                .rangeStart=${this._rangeStart}
                .rangeEnd=${this._rangeEnd}
                .chartAnchor=${this._chartAnchor}
                .language=${e}
                .isOutdoor=${this.rooms[this._selectedRoom]?.is_outdoor??!1}
              ></rs-analytics-chart>
              ${this.rooms[this._selectedRoom]?.is_outdoor?h:m` <rs-analytics-model
                    .hass=${this.hass}
                    .data=${this._data}
                    .language=${e}
                  ></rs-analytics-model>`}
            `:m`
            <div class="no-data">
              <ha-icon icon="mdi:chart-line" style="--mdc-icon-size: 48px; opacity: 0.4"></ha-icon>
              <p>${S(`analytics.select_room`,e)}</p>
            </div>
          `}
    `}_onRoomSelected(e){let t=e.detail.areaId;t&&t!==this._selectedRoom&&(this._selectedRoom=t,this.dispatchEvent(new CustomEvent(`room-selected`,{detail:{areaId:t},bubbles:!0,composed:!0})))}_onRangeChanged(e){let{activeQuick:t,rangeStart:n,rangeEnd:r,chartAnchor:i}=e.detail;this._activeQuick=t,this._rangeStart=n,this._rangeEnd=r,this._chartAnchor=i}_buildWsParams(){return{type:`roommind/analytics/get`,area_id:this._selectedRoom,start_ts:this._rangeStart/1e3,end_ts:this._rangeEnd/1e3}}async _fetchData(){if(this._selectedRoom){this._loading=!0,this._data=null,this._chartAnchor=this._rangeEnd;try{let e=await this.hass.callWS(this._buildWsParams());this._data=e}catch(e){console.debug(`[RoomMind] fetchData:`,e),this._data=null}finally{this._loading=!1}}}async _silentRefresh(){if(!(!this._selectedRoom||this._loading))try{let e=await this.hass.callWS(this._buildWsParams());this._data=e,this._chartAnchor=Date.now()}catch(e){console.debug(`[RoomMind] silentRefresh:`,e)}}static{this.styles=l`
    :host {
      display: block;
    }

    .no-data {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 80px 16px;
      text-align: center;
      color: var(--secondary-text-color);
    }

    .no-data p {
      font-size: 15px;
      max-width: 400px;
      line-height: 1.5;
      margin-top: 16px;
    }

    .loading {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 80px 16px;
      color: var(--secondary-text-color);
      font-size: 14px;
    }
  `}};k([y({attribute:!1})],Q.prototype,`hass`,void 0),k([y({type:Object})],Q.prototype,`rooms`,void 0),k([y()],Q.prototype,`initialRoom`,void 0),k([y()],Q.prototype,`controlMode`,void 0),k([b()],Q.prototype,`_selectedRoom`,void 0),k([b()],Q.prototype,`_rangeStart`,void 0),k([b()],Q.prototype,`_rangeEnd`,void 0),k([b()],Q.prototype,`_data`,void 0),k([b()],Q.prototype,`_chartAnchor`,void 0),k([b()],Q.prototype,`_loading`,void 0),k([b()],Q.prototype,`_activeQuick`,void 0),Q=k([v(`rs-analytics`)],Q),_(),x(),A();var Pn=`M20,11V13H8L13.5,18.5L12.08,19.92L4.16,12L12.08,4.08L13.5,5.5L8,11H20Z`,Fn=`M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z`,In=`M16,11.78L20.24,4.45L21.97,5.45L16.74,14.5L10.23,10.75L5.46,19H22V21H2V3H4V17.54L9.5,8L16,11.78Z`,Ln=`M15 13V5A3 3 0 0 0 9 5V13A5 5 0 1 0 15 13M12 4A1 1 0 0 1 13 5V8H11V5A1 1 0 0 1 12 4Z`,$=class extends g{constructor(...e){super(...e),this.narrow=!1,this.route={path:``},this.panel={},this._activeTab=`areas`,this._rooms={},this._roomsLoaded=!1,this._selectedAreaId=null,this._analyticsRoom=``,this._vacationActive=!1,this._vacationTemp=null,this._vacationUntil=null,this._hiddenRooms=[],this._showHiddenRooms=!1,this._controlMode=`bangbang`,this._climateControlActive=!0,this._presenceEnabled=!1,this._valveProtectionEnabled=!1,this._anyoneHome=!0,this._presencePersons=[],this._presenceAwayAction=`eco`,this._saveStatus=`idle`,this._roomOrder=[],this._groupByFloor=!1,this._reorderMode=!1,this._elementsLoaded=!1,this._routeApplied=!1,this._areaInfosCache=[],this._onSaveStatus=e=>{e.stopPropagation(),this._saveStatusTimeout&&clearTimeout(this._saveStatusTimeout),this._saveStatus=e.detail.status,e.detail.status===`saved`&&(this._saveStatusTimeout=setTimeout(()=>{this._saveStatus=`idle`},2e3))}}static{this.styles=l`
    :host {
      display: block;
      font-family: var(--primary-font-family, Roboto, sans-serif);
      color: var(--primary-text-color);
      background: var(--primary-background-color);
      min-height: 100vh;

      /* Round the corners of all MDC-based inputs (ha-textfield, ha-select,
         ha-entity-picker, ha-combo-box) to match the rest of the design.
         The bottom corners are rounded via inputStyles in each component. */
      --mdc-shape-small: 8px;
      --mdc-shape-medium: 8px;
      --md-filled-text-field-container-shape: 8px;
      --md-outlined-text-field-container-shape: 8px;
    }

    .toolbar {
      display: flex;
      align-items: center;
      height: 56px;
      padding: 0 12px;
      font-size: 20px;
      background-color: var(--app-header-background-color, var(--primary-background-color));
      color: var(--app-header-text-color, var(--primary-text-color));
      border-bottom: 1px solid var(--divider-color);
      box-sizing: border-box;
      position: sticky;
      top: 0;
      z-index: 4;
    }

    .toolbar .title {
      margin-left: 4px;
      font-weight: 400;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      flex: 1;
    }

    .toolbar ha-icon-button {
      color: var(--app-header-text-color, var(--primary-text-color));
    }

    .save-indicator {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-size: 13px;
      font-weight: 400;
      margin-right: 8px;
      opacity: 1;
      transition: opacity 0.3s ease;
    }

    .save-indicator.fade-out {
      opacity: 0;
    }

    .save-indicator ha-icon {
      --mdc-icon-size: 18px;
    }

    .save-indicator.saving {
      color: var(--primary-color, #03a9f4);
    }

    .save-indicator.saved {
      color: var(--success-color, #4caf50);
    }

    .save-indicator.error {
      color: var(--error-color, #d32f2f);
    }

    .tabs {
      display: flex;
      gap: 0;
      border-bottom: 1px solid var(--divider-color);
      padding: 0 16px;
      background: var(--primary-background-color);
      position: sticky;
      top: 56px;
      z-index: 3;
    }

    .tab {
      padding: 12px 24px;
      cursor: pointer;
      border: none;
      background: none;
      color: var(--secondary-text-color);
      font-size: 14px;
      font-weight: 500;
      border-bottom: 2px solid transparent;
      transition: all 0.2s ease;
      font-family: inherit;
    }

    .tab:hover {
      color: var(--primary-text-color);
    }

    .tab[active] {
      color: var(--primary-color);
      border-bottom-color: var(--primary-color);
    }

    .content {
      padding: 24px;
      max-width: 1200px;
      margin: 0 auto;
      box-sizing: border-box;
    }

    @media (max-width: 600px) {
      .content {
        padding: 16px;
      }
    }

    .placeholder {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 80px 16px;
      text-align: center;
      color: var(--secondary-text-color);
    }

    .placeholder ha-icon {
      margin-bottom: 16px;
    }

    .placeholder p {
      font-size: 15px;
      max-width: 400px;
      line-height: 1.5;
    }

    .area-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(min(360px, 100%), 1fr));
      gap: 16px;
    }

    .loading {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 80px 16px;
      color: var(--secondary-text-color);
      font-size: 14px;
    }

    .stats-separator {
      width: 1px;
      height: 28px;
      background: var(--divider-color, #444);
      margin: 0 4px;
      flex-shrink: 0;
    }

    .stats-bar {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 12px 24px;
      margin-bottom: 20px;
      padding: 12px 16px;
    }

    .stats-actions {
      display: flex;
      align-items: center;
      margin-left: auto;
      gap: 0;
    }

    .hidden-rooms-toggle {
      --mdc-icon-button-size: 36px;
      --mdc-icon-size: 20px;
      color: var(--secondary-text-color);
    }

    .hidden-rooms-panel {
      margin-bottom: 20px;
      padding: 12px 16px;
    }

    .hidden-rooms-header {
      font-size: 13px;
      font-weight: 500;
      color: var(--secondary-text-color);
      margin-bottom: 8px;
    }

    .hidden-room-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 6px 0;
    }

    .hidden-room-name {
      font-size: 14px;
      color: var(--primary-text-color);
    }

    .stat {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .stat-value {
      font-size: 20px;
      font-weight: 500;
      color: var(--primary-text-color);
      --mdc-icon-size: 22px;
      line-height: 1;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-height: 24px;
    }

    .stat-label {
      font-size: 12px;
      color: var(--secondary-text-color);
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .floor-heading {
      font-size: 14px;
      font-weight: 500;
      color: var(--secondary-text-color);
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin: 20px 0 8px 0;
    }

    .floor-heading:first-of-type {
      margin-top: 0;
    }

    .reorder-btn {
      --mdc-icon-button-size: 36px;
      --mdc-icon-size: 20px;
      color: var(--secondary-text-color);
    }

    .reorder-done {
      font-size: 14px;
      margin-left: auto;
    }
  `}connectedCallback(){super.connectedCallback(),sn().then(()=>{this._elementsLoaded=!0}),this._loadRooms(),this._refreshInterval=setInterval(()=>this._loadRooms(),5e3),this.addEventListener(`save-status`,this._onSaveStatus),this._routeApplied||=(this._applyRoute(),!0),this._boundVisibilityHandler||(this._boundVisibilityHandler=()=>{if(!document.hidden){if(!this.isConnected){window.location.reload();return}this._loadRooms(),this.requestUpdate()}},document.addEventListener(`visibilitychange`,this._boundVisibilityHandler))}disconnectedCallback(){super.disconnectedCallback(),this._refreshInterval&&=(clearInterval(this._refreshInterval),void 0),this._saveStatusTimeout&&clearTimeout(this._saveStatusTimeout),this.removeEventListener(`save-status`,this._onSaveStatus),this._boundConnectionReady&&=(this.hass?.connection?.removeEventListener(`ready`,this._boundConnectionReady),void 0)}render(){if(!this._elementsLoaded||!this.hass)return m``;let e=this.hass.language,t=!!this._selectedAreaId,n=t?this.hass?.areas?.[this._selectedAreaId]:null,r={areas:S(`panel.tab.rooms`,e),analytics:S(`tabs.analytics`,e),settings:S(`panel.tab.settings`,e)};return m`
      <div class="toolbar">
        ${t?m`<ha-icon-button
              .path=${Pn}
              @click=${this._onBackFromDetail}
            ></ha-icon-button>`:m`<ha-menu-button .hass=${this.hass} .narrow=${this.narrow}></ha-menu-button>`}
        <div class="title">
          ${t?this._rooms[this._selectedAreaId]?.display_name||n?.name||``:S(`panel.title`,e)}
        </div>
        ${this._renderSaveIndicator()}
        ${t&&this._rooms[this._selectedAreaId]?m`<ha-icon-button
                .path=${In}
                @click=${this._onGoToAnalytics}
              ></ha-icon-button
              ><ha-icon-button .path=${Fn} @click=${this._onDeleteRoom}></ha-icon-button>`:h}
        ${!t&&this._activeTab===`analytics`&&this._analyticsRoom?m`<ha-icon-button
              .path=${Ln}
              @click=${this._onGoToRoomFromAnalytics}
            ></ha-icon-button>`:h}
      </div>

      ${t?h:m`
            <div class="tabs">
              ${Object.keys(r).map(e=>m`
                  <button
                    class="tab"
                    ?active=${this._activeTab===e}
                    @click=${()=>this._onTabClicked(e)}
                  >
                    ${r[e]}
                  </button>
                `)}
            </div>
          `}

      <div class="content">${this._renderTab()}</div>
    `}_renderTab(){switch(this._activeTab){case`areas`:return this._renderAreas();case`analytics`:return m`<rs-analytics
          .hass=${this.hass}
          .rooms=${this._rooms}
          .initialRoom=${this._analyticsRoom}
          .controlMode=${this._controlMode}
          @room-selected=${this._onAnalyticsRoomSelected}
        ></rs-analytics>`;case`settings`:return this._renderSettings();default:return h}}_renderAreas(){if(this._selectedAreaId){let e=this.hass?.areas?.[this._selectedAreaId];if(e)return m`
          <rs-room-detail
            .area=${e}
            .config=${this._rooms[this._selectedAreaId]??null}
            .hass=${this.hass}
            .presenceEnabled=${this._presenceEnabled}
            .presencePersons=${this._presencePersons}
            .climateControlActive=${this._climateControlActive}
            .valveProtectionEnabled=${this._valveProtectionEnabled}
            @back-clicked=${this._onBackFromDetail}
            @room-updated=${this._onRoomUpdated}
          ></rs-room-detail>
        `;this._selectedAreaId=null}if(!this._roomsLoaded)return m`<div class="loading">${S(`panel.loading`,this.hass.language)}</div>`;let e=this._areaInfosCache,t=e.filter(e=>!this._hiddenRooms.includes(e.area.area_id)),n=e.filter(e=>this._hiddenRooms.includes(e.area.area_id));if(e.length===0)return m`
        <div class="placeholder">
          <ha-icon icon="mdi:home" style="--mdc-icon-size: 56px; opacity: 0.4"></ha-icon>
          <p>
            ${S(`panel.no_areas`,this.hass.language)}<br />${S(`panel.no_areas_hint`,this.hass.language)}
          </p>
        </div>
      `;let r=t.filter(e=>e.config).length,i=t.filter(e=>e.config?.live?.mode===`heating`).length,a=t.filter(e=>e.config?.live?.mode===`cooling`).length,o=t.filter(e=>e.config?.live?.mold_risk_level===`warning`||e.config?.live?.mold_risk_level===`critical`).length,s=this._vacationActive||this._presenceEnabled&&!this._anyoneHome||o>0,c=this.hass.language;return m`
      ${r>0||n.length>0?m`
            <ha-card class="stats-bar">
              ${r>0?m`
                    <div class="stat">
                      <span class="stat-value">${r}</span>
                      <span class="stat-label">${S(`panel.stat.rooms`,c)}</span>
                    </div>
                    <div class="stat">
                      <span class="stat-value" style="color: var(--warning-color, #ff9800)"
                        >${i}</span
                      >
                      <span class="stat-label">${S(`panel.stat.heating`,c)}</span>
                    </div>
                    <div class="stat">
                      <span class="stat-value" style="color: var(--info-color, #2196f3)"
                        >${a}</span
                      >
                      <span class="stat-label">${S(`panel.stat.cooling`,c)}</span>
                    </div>
                  `:h}
              ${s?m`<div class="stats-separator"></div>`:h}
              ${this._vacationActive?m`
                    <div class="stat">
                      <span class="stat-value" style="color: var(--success-color, #4caf50)">
                        <ha-icon icon="mdi:airplane"></ha-icon>
                      </span>
                      <span class="stat-label">${S(`panel.stat.vacation`,c)}</span>
                    </div>
                  `:h}
              ${this._presenceEnabled&&!this._anyoneHome?m`
                    <div class="stat">
                      <span class="stat-value" style="color: var(--secondary-text-color)">
                        <ha-icon icon="mdi:power"></ha-icon>
                      </span>
                      <span class="stat-label">${S(`panel.stat.away`,c)}</span>
                    </div>
                  `:h}
              ${o>0?m`
                    <div class="stat">
                      <span class="stat-value" style="color: var(--error-color, #f44336)"
                        >${o}</span
                      >
                      <span class="stat-label">${S(`panel.stat.mold`,c)}</span>
                    </div>
                  `:h}
              <span class="stats-actions">
                ${n.length>0?m`<ha-icon-button
                      class="hidden-rooms-toggle"
                      .path=${Ot}
                      @click=${()=>{this._showHiddenRooms=!this._showHiddenRooms}}
                    ></ha-icon-button>`:h}
                ${this._reorderMode?m`<ha-button class="reorder-done" @click=${this._onReorderDone}>
                      ${S(`panel.reorder_done`,c)}
                    </ha-button>`:m`<ha-icon-button
                      class="reorder-btn"
                      .path=${`M9,3L5,7H8V14H10V7H13M16,17V10H14V17H11L15,21L19,17H16Z`}
                      @click=${()=>{this._reorderMode=!0}}
                      title=${S(`panel.reorder`,c)}
                    ></ha-icon-button>`}
              </span>
            </ha-card>
          `:h}
      ${this._showHiddenRooms&&n.length>0?m`
            <ha-card class="hidden-rooms-panel">
              <div class="hidden-rooms-header">
                <span>${S(`panel.hidden_rooms`,c)} (${n.length})</span>
              </div>
              ${n.map(e=>m`
                  <div class="hidden-room-row">
                    <span class="hidden-room-name">${e.area.name}</span>
                    <ha-button @click=${()=>this._unhideRoom(e.area.area_id)}>
                      ${S(`panel.unhide`,c)}
                    </ha-button>
                  </div>
                `)}
            </ha-card>
          `:h}
      ${this._getFloorGroups(t).map(e=>m`
          ${e.name?m`<h4 class="floor-heading">${e.name}</h4>`:h}
          <div class="area-grid">
            ${e.items.map((t,n)=>m`
                <rs-area-card
                  .area=${t.area}
                  .config=${t.config}
                  .climateEntityCount=${t.climateEntityCount}
                  .tempSensorCount=${t.tempSensorCount}
                  .hass=${this.hass}
                  .controlMode=${this._controlMode}
                  .climateControlActive=${this._climateControlActive}
                  .reordering=${this._reorderMode}
                  .canMoveUp=${n>0}
                  .canMoveDown=${n<e.items.length-1}
                  @area-selected=${this._onAreaSelected}
                  @hide-room=${this._onHideRoom}
                  @move-room-up=${this._onMoveRoomUp}
                  @move-room-down=${this._onMoveRoomDown}
                ></rs-area-card>
              `)}
          </div>
        `)}
    `}_renderSettings(){return m`<rs-settings .hass=${this.hass} .rooms=${this._rooms}></rs-settings>`}_computeAreaInfos(){if(!this.hass?.areas)return[];let e=Object.values(this.hass.areas).map(e=>{let t=Ct(e.area_id,this.hass.entities,this.hass.devices).filter(e=>!e.entity_id.substring(e.entity_id.indexOf(`.`)+1).startsWith(`roommind_`)),n=t.filter(e=>e.entity_id.startsWith(`climate.`)).length,r=t.filter(e=>e.entity_id.startsWith(`sensor.`)&&this.hass.states[e.entity_id]?.attributes?.device_class===`temperature`).length;return{area:e,config:this._rooms[e.area_id]??null,climateEntityCount:n,tempSensorCount:r}}),t=new Map(this._roomOrder.map((e,t)=>[e,t]));return e.sort((e,n)=>{let r=t.get(e.area.area_id),i=t.get(n.area.area_id);if(r!==void 0&&i!==void 0)return r-i;if(r!==void 0)return-1;if(i!==void 0)return 1;let a=e.config?2:+(e.climateEntityCount>0),o=n.config?2:+(n.climateEntityCount>0);return a===o?e.area.name.localeCompare(n.area.name):o-a}),e}_getFloorGroups(e){if(!this._groupByFloor||!this.hass.floors)return[{name:``,items:e}];let t=this.hass.floors,n=this.hass.language,r=new Map,i=[];for(let t of e){let e=t.area.floor_id??null;r.has(e)||(r.set(e,[]),i.push(e)),r.get(e).push(t)}return i.sort((e,n)=>{if(e===null)return 1;if(n===null)return-1;let r=t[e],i=t[n];return r?.level!=null&&i?.level!=null?i.level-r.level:r?.level==null?i?.level==null?(r?.name??``).localeCompare(i?.name??``):1:-1}),i.map(e=>({name:e===null?S(`panel.floor_other`,n):t[e]?.name??S(`panel.floor_other`,n),items:r.get(e)}))}async _loadRooms(){if(this.hass)try{let e=await this.hass.callWS({type:`roommind/rooms/list`});this._rooms=e.rooms,this._vacationActive=e.vacation_active??!1,this._vacationTemp=e.vacation_temp??null,this._vacationUntil=e.vacation_until??null,this._hiddenRooms=e.hidden_rooms??[],this._roomOrder=e.room_order??[],this._groupByFloor=e.group_by_floor??!1,this._controlMode=e.control_mode??`bangbang`,this._climateControlActive=e.climate_control_active??!0,this._presenceEnabled=e.presence_enabled??!1,this._valveProtectionEnabled=e.valve_protection_enabled??!1,this._anyoneHome=e.anyone_home??!0,this._presencePersons=e.presence_persons??[],this._presenceAwayAction=e.presence_away_action??`eco`}catch(e){console.debug(`[RoomMind] loadRooms:`,e)}finally{this._roomsLoaded=!0}}_onBackFromDetail(){this._selectedAreaId=null,this._navigate(``)}async _onDeleteRoom(){if(!this._selectedAreaId)return;let e=this.hass?.areas?.[this._selectedAreaId];if(e&&confirm(S(`room.confirm_delete`,this.hass.language,{name:e.name})))try{await this.hass.callWS({type:`roommind/rooms/delete`,area_id:this._selectedAreaId}),this._selectedAreaId=null,this._navigate(``),this._loadRooms()}catch(e){console.debug(`[RoomMind] deleteRoom:`,e)}}_onTabClicked(e){this._activeTab=e,this._selectedAreaId=null,e===`areas`?this._navigate(``):this._navigate(`/${e}`)}_onAreaSelected(e){this._selectedAreaId=e.detail.areaId,this._navigate(`/room/${e.detail.areaId}`)}async _onHideRoom(e){let t=[...new Set([...this._hiddenRooms,e.detail.areaId])];this._hiddenRooms=t;try{await this.hass.callWS({type:`roommind/settings/save`,hidden_rooms:t})}catch(e){console.debug(`[RoomMind] hideRoom:`,e)}}async _unhideRoom(e){let t=this._hiddenRooms.filter(t=>t!==e);this._hiddenRooms=t,t.length===0&&(this._showHiddenRooms=!1);try{await this.hass.callWS({type:`roommind/settings/save`,hidden_rooms:t})}catch(e){console.debug(`[RoomMind] unhideRoom:`,e)}}_onGoToAnalytics(){this._selectedAreaId&&(this._analyticsRoom=this._selectedAreaId,this._selectedAreaId=null,this._activeTab=`analytics`,this._navigate(`/analytics/${this._analyticsRoom}`))}_onGoToRoomFromAnalytics(){this._analyticsRoom&&(this._selectedAreaId=this._analyticsRoom,this._activeTab=`areas`,this._navigate(`/room/${this._analyticsRoom}`))}_onAnalyticsRoomSelected(e){this._analyticsRoom=e.detail.areaId,this._navigate(`/analytics/${e.detail.areaId}`)}async _onMoveRoomUp(e){this._moveRoom(e.detail.areaId,-1)}async _onMoveRoomDown(e){this._moveRoom(e.detail.areaId,1)}async _moveRoom(e,t){let n=this._areaInfosCache.filter(e=>!this._hiddenRooms.includes(e.area.area_id));if(this._groupByFloor&&this.hass.floors){let r=this._getFloorGroups(n);for(let n of r){let i=n.items.map(e=>e.area.area_id),a=i.indexOf(e);if(a===-1)continue;let o=a+t;if(o<0||o>=i.length)return;[i[a],i[o]]=[i[o],i[a]];let s=r.flatMap(e=>e===n?i:e.items.map(e=>e.area.area_id));await this._saveRoomOrder(s);return}}else{let r=n.map(e=>e.area.area_id),i=r.indexOf(e);if(i===-1)return;let a=i+t;if(a<0||a>=r.length)return;[r[i],r[a]]=[r[a],r[i]],await this._saveRoomOrder(r)}}async _saveRoomOrder(e){this._roomOrder=e,this._areaInfosCache=this._computeAreaInfos();try{await this.hass.callWS({type:`roommind/settings/save`,room_order:e})}catch(e){console.debug(`[RoomMind] saveRoomOrder:`,e)}}_onReorderDone(){this._reorderMode=!1}_onRoomUpdated(){this._loadRooms()}_renderSaveIndicator(){if(this._saveStatus===`idle`)return h;let e=this.hass.language,t=this._saveStatus===`saving`?`mdi:content-save-outline`:this._saveStatus===`saved`?`mdi:check`:`mdi:alert-circle-outline`,n=this._saveStatus===`saving`?S(`settings.saving`,e):this._saveStatus===`saved`?S(`settings.saved`,e):S(`settings.error`,e);return m`
      <span class="save-indicator ${this._saveStatus}">
        <ha-icon .icon=${t}></ha-icon>
        ${n}
      </span>
    `}willUpdate(e){e.has(`route`)&&this._routeApplied&&this._applyRoute(),(e.has(`_rooms`)||e.has(`hass`))&&(this._areaInfosCache=this._computeAreaInfos())}updated(e){e.has(`hass`)&&this.hass&&!this._roomsLoaded&&this._loadRooms(),e.has(`hass`)&&this.hass?.connection&&!this._boundConnectionReady&&(this._boundConnectionReady=()=>{this._loadRooms(),this.requestUpdate()},this.hass.connection.addEventListener(`ready`,this._boundConnectionReady))}_navigate(e){history.replaceState(null,``,`/roommind${e}`),window.dispatchEvent(new Event(`location-changed`))}_applyRoute(){let e=this.route?.path??``;e.startsWith(`/room/`)?(this._activeTab=`areas`,this._selectedAreaId=decodeURIComponent(e.slice(6))):e.startsWith(`/analytics/`)?(this._activeTab=`analytics`,this._selectedAreaId=null,this._analyticsRoom=decodeURIComponent(e.slice(11))):e===`/analytics`?(this._activeTab=`analytics`,this._selectedAreaId=null,this._analyticsRoom=``):e===`/settings`?(this._activeTab=`settings`,this._selectedAreaId=null):(this._activeTab=`areas`,this._selectedAreaId=null)}};k([y({attribute:!1})],$.prototype,`hass`,void 0),k([y({type:Boolean,reflect:!0})],$.prototype,`narrow`,void 0),k([y({type:Object})],$.prototype,`route`,void 0),k([y({type:Object})],$.prototype,`panel`,void 0),k([b()],$.prototype,`_activeTab`,void 0),k([b()],$.prototype,`_rooms`,void 0),k([b()],$.prototype,`_roomsLoaded`,void 0),k([b()],$.prototype,`_selectedAreaId`,void 0),k([b()],$.prototype,`_analyticsRoom`,void 0),k([b()],$.prototype,`_vacationActive`,void 0),k([b()],$.prototype,`_vacationTemp`,void 0),k([b()],$.prototype,`_vacationUntil`,void 0),k([b()],$.prototype,`_hiddenRooms`,void 0),k([b()],$.prototype,`_showHiddenRooms`,void 0),k([b()],$.prototype,`_controlMode`,void 0),k([b()],$.prototype,`_climateControlActive`,void 0),k([b()],$.prototype,`_presenceEnabled`,void 0),k([b()],$.prototype,`_valveProtectionEnabled`,void 0),k([b()],$.prototype,`_anyoneHome`,void 0),k([b()],$.prototype,`_presencePersons`,void 0),k([b()],$.prototype,`_presenceAwayAction`,void 0),k([b()],$.prototype,`_saveStatus`,void 0),k([b()],$.prototype,`_roomOrder`,void 0),k([b()],$.prototype,`_groupByFloor`,void 0),k([b()],$.prototype,`_reorderMode`,void 0),k([b()],$.prototype,`_elementsLoaded`,void 0),$=k([v(`roommind-panel`)],$)})();